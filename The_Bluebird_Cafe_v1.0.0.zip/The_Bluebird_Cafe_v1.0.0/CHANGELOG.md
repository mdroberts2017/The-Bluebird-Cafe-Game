# Changelog — The Bluebird Cafe

## v1.0.0 — first release (2026-11-15)
- Release candidate 3 promoted unchanged, apart from the version number.

## v0.11.0-rc3 — release candidate 3
- Fix: the buttons over the café scene now respond every time. The game was rewriting their text several times a second even when nothing changed, so a click that started on the text could be lost. The screen now updates only what actually changed.
- Requests are queued when the crew is busy. Serving, clearing, ringing up and table visits wait their turn, marked with ⏳, a dashed outline and their place in line, and start automatically when someone frees up. The order menu always opens, and a ticket sent while both waitresses are busy is queued.
- Every action explains why it is waiting or unavailable, on hover and on click. For example: "Table 3's ticket is waiting in the kitchen, with 2 tickets ahead of it," or "Rita is serving T2, Jane is on a break." The service list shows each queued ticket's kitchen position.

## v0.11.0-rc2 — release candidate 2
- The wall portrait ("Daughter") is now a stylized pop-art illustration made from the photo, on a teal sunburst that matches the poster beside it.
- New ambient music: an original, cheerful 16-bar tune in F major with a bouncy two-beat bass that switches to walking, stride piano and light brushes. The tune alternates between vibraphone and clarinet, and the tempo follows the day type. A shorter, lighter room echo replaces the long tail that made the old music sound eerie.
- Fix: a guest who left before reaching the door no longer cuts through the side lot; they walk off down the sidewalk.

## v0.11.0-rc1 — release candidate
- Added a Settings window with:
  - music on/off and volume
  - sound effects on/off and volume
  - graphics quality (Low / Medium / High)
  - reduce motion
  - export, import and reset career
- Added generated sound effects: cash register, streetcar bell, griddle sizzle, fire alarm, second-line brass sting, event chime, shop-door bell, plate clatter and an inspector cue.
- Keyboard and screen-reader pass:
  - Shift+1/2/3 answers event cards
  - arrow keys pan the camera and Home resets it
  - event cards are labeled groups and the staff list is announced with energy levels
  - dialogs focus their main button when opened
  - the status line is a polite live region
- Saves now carry a version number and are checked field by field on load. The previous good save is kept as a backup. An unreadable save is set aside and the backup restored, with a notice in the morning paper.
- Added a notice when the window is narrower than 900 pixels; the game is desktop only.
- Removed the concept-art staging code. Added README, CHANGELOG, LICENSE and a reproducible source build.

## v0.10.1
- Claire renamed to Rita.

## v0.10.0
- Replaced the wall poster with an original retro comic poster drawn in code: a heroic bluebird, a chicory coffee inset and a streetcar inset.
- Added an About window with copyright, GPL notice and third-party credits.
- Added ambient New Orleans jazz generated live, with a tempo that follows the day type.
- Performance:
  - trimmed three.js build
  - WebP images
  - static scene merged from 745 to 176 draw calls
  - shared character materials
  - shadows recalculated only when needed
  - character sheets drawn one row at a time without blocking the page
  - file size cut from 1.22 MB to 0.80 MB

## v0.9.0
- Carl renamed to Bart, with blond hair.
- Sally and Bart move between kitchen stations: griddle, burners, prep, coffee, fridge and the pass. They have spatula animation frames, and a pancake flips over the griddle.
- Framed pictures on the dining-room wall.
- New Orleans touches:
  - PRYTANIA sidewalk tiles
  - a green St. Charles streetcar
  - Mardi Gras beads in the trees
  - copper gas lanterns and hanging ferns
  - pain perdu and grillades & grits on the menu
  - chicory coffee, a second-line band and Saints game day on Sundays
- License changed from MIT to GPL-3.0-or-later.

## v0.8.0
- Career mode:
  - days and day types (Red Beans Monday, Jazz Fest, Mardi Gras, hurricane, food critic)
  - *The Bluebird Bugle* reviews, reputation, karma and bank
  - food costs and overhead
  - daily goals with streak bonuses
  - supply-shop upgrades
- Shift events:
  - brass band, line cutter, Jane's breaks, grease fires, inspector warning with prep or bribe options
  - free coffee for the line
  - crew traits and energy, with staff meals
  - Sally's table visits
- Taller wall art and menu board; restroom sign no longer overlaps the window.

## v0.7.0
- Real-time 3D café built with three.js: a single street-and-interior scene with a Sims-style cutaway, camera rotation, zoom and pan.
- Characters pre-rendered from 3D figures in eight directions, with walking, sitting and carrying frames.
- Guests walk in from the sidewalk to their seats, and Sally walks out to visit the line.

## v0.6.1
- Original 2D isometric version by Michael Roberts.
