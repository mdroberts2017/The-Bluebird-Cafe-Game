#!/usr/bin/env python3
"""Assemble The Bluebird Cafe into one self-contained HTML file.

Copyright (C) 2026 Michael Roberts · GPL-3.0-or-later
Run `npm install` then `npm run build` (or `npm run three` once, then `python3 build.py`).
"""
import base64, os, sys
VERSION = 'v1.0.0'
ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, 'src')
ASSETS = os.path.join(ROOT, 'assets')
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, 'build', 'The_Bluebird_Cafe_%s.html' % VERSION)
ORDER = ('career.js', 'events.js', 'settings.js', 'audio.js', 'logic.js', 'characters.js', 'world3d.js', 'main.js')

def read(path):
    with open(path, encoding='utf-8') as f:
        return f.read()

def data_uri(name):
    with open(os.path.join(ASSETS, name), 'rb') as f:
        return 'data:image/webp;base64,' + base64.b64encode(f.read()).decode()

three = read(os.path.join(ROOT, 'build', 'three-custom.min.js'))
js = ''.join(read(os.path.join(SRC, name)) + '\n' for name in ORDER)
js = js.replace('%%RESTROOM%%', data_uri('restroom.webp')).replace('%%ART_SARAH%%', data_uri('wall-portrait.webp'))
scripts = ('<script>\n/* three.js r160 (tree-shaken build) — MIT License — Copyright © 2010-2023 three.js authors */\n'
           + three + '\n</script>\n<script>\n' + js + '</script>')
html = read(os.path.join(SRC, 'template.html')).replace('%%SCRIPTS%%', scripts)
html = html.replace('%%MURAL%%', data_uri('mural.webp')).replace('%%WORDMARK%%', data_uri('wordmark.webp'))
assert '%%' not in html, 'unreplaced placeholder'
os.makedirs(os.path.dirname(OUT), exist_ok=True)
with open(OUT, 'w', encoding='utf-8') as f:
    f.write(html)
print('wrote', OUT, len(html), 'bytes')
