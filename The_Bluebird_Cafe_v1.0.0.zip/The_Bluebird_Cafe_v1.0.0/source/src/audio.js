// ===== Ambient music: a cheerful New Orleans trad-jazz combo, generated live with Web Audio =====
// An original 16-bar tune in F major over a bouncy two-beat/walking bass, stride piano on the
// off-beats and light brushes. The lead trades between vibraphone and clarinet each chorus.
// Nothing is downloaded; the sound is synthesized in the browser.
const gMusic={ctx:null,master:null,sfxBus:null,reverb:null,playing:false,timer:null,step:0,nextTime:0,sizzle:null};
// Chords: bass root, then the piano voicing. F6 F6 D7 D7 | G7 C7 F6 C7 | F6 F7 Bb6 Bb6 | F6 D7 G7 C7
const F6=[41,57,60,62,65],D7=[38,54,57,60,62],G7=[43,59,62,65,67],C7=[36,58,60,64,67],F7=[41,57,60,63,65],Bb6=[46,58,62,65,67];
const gChart=[F6,F6,D7,D7,G7,C7,F6,C7,F6,F7,Bb6,Bb6,F6,D7,G7,C7];
// The tune: per bar, [eighth-note step, MIDI note, length in eighths].
const gTune=[
  [[0,72,2],[2,69,2],[4,65,2],[6,69,2]],
  [[0,72,3],[3,74,1],[4,72,4]],
  [[0,69,2],[2,66,1],[3,69,1],[4,72,2],[6,74,2]],
  [[0,74,6],[7,72,1]],
  [[0,71,2],[2,74,2],[4,67,2],[6,71,2]],
  [[0,70,2],[2,69,2],[4,67,2],[6,64,2]],
  [[0,65,2],[2,69,2],[4,72,2],[6,74,2]],
  [[0,72,6],[6,70,1],[7,69,1]],
  [[0,69,2],[2,72,2],[4,77,2],[6,72,2]],
  [[0,75,2],[2,74,1],[3,72,1],[4,69,4]],
  [[0,74,2],[2,77,2],[4,74,2],[6,70,2]],
  [[0,67,2],[2,70,2],[4,74,4]],
  [[0,72,2],[2,69,2],[4,67,2],[6,65,2]],
  [[0,66,2],[2,69,2],[4,74,2],[6,72,2]],
  [[0,74,2],[2,71,2],[4,67,2],[6,71,2]],
  [[0,72,2],[2,70,2],[4,64,2],[6,67,2]]
];
const midiHz=pNote=>440*Math.pow(2,(pNote-69)/12);
function musicTempo(){
  const tKind=(typeof shift!=='undefined'&&shift?shift.day.kind:gToday.kind);
  return {mardigras:132,jazzfest:128,saints:124,hurricane:104}[tKind]||116;
}
function initAudio(){
  if(gMusic.ctx)return;
  const tCtx=new (window.AudioContext||window.webkitAudioContext)();
  gMusic.ctx=tCtx;
  const tComp=tCtx.createDynamicsCompressor();tComp.threshold.value=-18;tComp.ratio.value=3;
  gMusic.master=tCtx.createGain();gMusic.master.gain.value=0;
  gMusic.master.connect(tComp);tComp.connect(tCtx.destination);
  gMusic.sfxBus=tCtx.createGain();gMusic.sfxBus.gain.value=gSettings.sfxVolume*.9;gMusic.sfxBus.connect(tComp);
  // A short generated room reverb.
  const tLength=tCtx.sampleRate*.9,tImpulse=tCtx.createBuffer(2,tLength,tCtx.sampleRate);
  for(let tCh=0;tCh<2;tCh++){const tData=tImpulse.getChannelData(tCh);for(let tI=0;tI<tLength;tI++)tData[tI]=(Math.random()*2-1)*Math.pow(1-tI/tLength,4);}
  gMusic.reverb=tCtx.createConvolver();gMusic.reverb.buffer=tImpulse;
  const tWet=tCtx.createGain();tWet.gain.value=.1;gMusic.reverb.connect(tWet);tWet.connect(gMusic.master);
  gMusic.noise=tCtx.createBuffer(1,tCtx.sampleRate,tCtx.sampleRate);
  const tNoise=gMusic.noise.getChannelData(0);for(let tI=0;tI<tNoise.length;tI++)tNoise[tI]=Math.random()*2-1;
}
function voice(pTime,pDuration,pGain,pSend){
  const tCtx=gMusic.ctx;
  const tGain=tCtx.createGain();tGain.gain.value=0;
  tGain.connect(gMusic.master);
  if(pSend){const tSend=tCtx.createGain();tSend.gain.value=pSend;tGain.connect(tSend);tSend.connect(gMusic.reverb);}
  return tGain;
}
function playBass(pNote,pTime,pBeat){
  const tCtx=gMusic.ctx;
  const tOut=voice(pTime,pBeat,0,.04);
  const tOsc=tCtx.createOscillator();tOsc.type='triangle';tOsc.frequency.value=midiHz(pNote);
  const tTone=tCtx.createOscillator();tTone.type='sine';tTone.frequency.value=midiHz(pNote)*2;
  const tToneGain=tCtx.createGain();tToneGain.gain.value=.25;tTone.connect(tToneGain);
  const tFilter=tCtx.createBiquadFilter();tFilter.type='lowpass';tFilter.frequency.value=900;
  tOsc.connect(tFilter);tToneGain.connect(tFilter);tFilter.connect(tOut);
  tOut.gain.setValueAtTime(0,pTime);tOut.gain.linearRampToValueAtTime(.45,pTime+.008);tOut.gain.exponentialRampToValueAtTime(.06,pTime+pBeat*.75);tOut.gain.linearRampToValueAtTime(0,pTime+pBeat*.95);
  tOsc.start(pTime);tTone.start(pTime);tOsc.stop(pTime+pBeat);tTone.stop(pTime+pBeat);
}
// Stride-piano chord: bright attack, quick decay.
function playChord(pNotes,pTime,pLength,pLevel){
  const tCtx=gMusic.ctx;
  const tOut=voice(pTime,pLength,0,.12);
  tOut.gain.setValueAtTime(0,pTime);tOut.gain.linearRampToValueAtTime(pLevel,pTime+.006);tOut.gain.exponentialRampToValueAtTime(pLevel*.18,pTime+pLength*.8);tOut.gain.linearRampToValueAtTime(0,pTime+pLength);
  for(const tNote of pNotes){
    for(const [tMult,tLevel,tType] of [[1,.55,'triangle'],[2,.2,'sine'],[3,.06,'sine']]){
      const tOsc=tCtx.createOscillator();tOsc.type=tType;tOsc.frequency.value=midiHz(tNote)*tMult;
      const tG=tCtx.createGain();tG.gain.value=tLevel/pNotes.length;tOsc.connect(tG);tG.connect(tOut);
      tOsc.start(pTime);tOsc.stop(pTime+pLength+.05);
    }
  }
}
function playSnare(pTime,pLevel){
  const tCtx=gMusic.ctx;
  const tSrc=tCtx.createBufferSource();tSrc.buffer=gMusic.noise;
  const tFilter=tCtx.createBiquadFilter();tFilter.type='bandpass';tFilter.frequency.value=2200;tFilter.Q.value=.8;
  const tOut=voice(pTime,.15,0,.05);tSrc.connect(tFilter);tFilter.connect(tOut);
  tOut.gain.setValueAtTime(0,pTime);tOut.gain.linearRampToValueAtTime(pLevel,pTime+.004);tOut.gain.exponentialRampToValueAtTime(.001,pTime+.14);
  tSrc.start(pTime,Math.random()*.5);tSrc.stop(pTime+.18);
}
function playRide(pTime,pLevel){
  const tCtx=gMusic.ctx;
  const tSrc=tCtx.createBufferSource();tSrc.buffer=gMusic.noise;
  const tFilter=tCtx.createBiquadFilter();tFilter.type='highpass';tFilter.frequency.value=7500;
  const tOut=voice(pTime,.2,0,.03);tSrc.connect(tFilter);tFilter.connect(tOut);
  tOut.gain.setValueAtTime(0,pTime);tOut.gain.linearRampToValueAtTime(pLevel,pTime+.002);tOut.gain.exponentialRampToValueAtTime(.001,pTime+.2);
  tSrc.start(pTime,Math.random()*.5);tSrc.stop(pTime+.22);
}
function playKick(pTime){
  const tCtx=gMusic.ctx;
  const tOsc=tCtx.createOscillator();tOsc.type='sine';
  tOsc.frequency.setValueAtTime(120,pTime);tOsc.frequency.exponentialRampToValueAtTime(55,pTime+.1);
  const tOut=voice(pTime,.2,0,0);
  tOsc.connect(tOut);tOut.gain.setValueAtTime(.22,pTime);tOut.gain.exponentialRampToValueAtTime(.001,pTime+.18);
  tOsc.start(pTime);tOsc.stop(pTime+.2);
}
// Vibraphone: pure tone with a soft overtone and a gentle shimmer.
function playVibes(pNote,pTime,pLength){
  const tCtx=gMusic.ctx;
  const tOut=voice(pTime,pLength,0,.18);
  const tTrem=tCtx.createGain();tTrem.gain.value=1;tTrem.connect(tOut);
  const tLfo=tCtx.createOscillator();tLfo.frequency.value=5;const tDepth=tCtx.createGain();tDepth.gain.value=.12;tLfo.connect(tDepth);tDepth.connect(tTrem.gain);
  for(const [tMult,tLevel] of [[1,1],[4,.12],[2,.08]]){
    const tOsc=tCtx.createOscillator();tOsc.type='sine';tOsc.frequency.value=midiHz(pNote)*tMult;
    const tG=tCtx.createGain();tG.gain.value=tLevel;tOsc.connect(tG);tG.connect(tTrem);
    tOsc.start(pTime);tOsc.stop(pTime+pLength+.6);
  }
  tOut.gain.setValueAtTime(0,pTime);tOut.gain.linearRampToValueAtTime(.12,pTime+.005);tOut.gain.exponentialRampToValueAtTime(.03,pTime+pLength);tOut.gain.exponentialRampToValueAtTime(.0008,pTime+pLength+.5);
  tLfo.start(pTime);tLfo.stop(pTime+pLength+.6);
}
// Clarinet: warm triangle tone, soft attack, light vibrato that arrives late in the note.
function playClarinet(pNote,pTime,pLength){
  const tCtx=gMusic.ctx;
  const tOsc=tCtx.createOscillator();tOsc.type='triangle';tOsc.frequency.value=midiHz(pNote);
  const tReed=tCtx.createOscillator();tReed.type='sine';tReed.frequency.value=midiHz(pNote)*3;
  const tReedGain=tCtx.createGain();tReedGain.gain.value=.18;tReed.connect(tReedGain);
  const tVib=tCtx.createOscillator();tVib.frequency.value=5.5;
  const tDepth=tCtx.createGain();tDepth.gain.setValueAtTime(0,pTime);tDepth.gain.linearRampToValueAtTime(midiHz(pNote)*.004,pTime+pLength);
  tVib.connect(tDepth);tDepth.connect(tOsc.frequency);
  const tFilter=tCtx.createBiquadFilter();tFilter.type='lowpass';tFilter.frequency.value=2400;
  const tOut=voice(pTime,pLength,0,.14);
  tOsc.connect(tFilter);tReedGain.connect(tFilter);tFilter.connect(tOut);
  tOut.gain.setValueAtTime(0,pTime);tOut.gain.linearRampToValueAtTime(.11,pTime+.03);tOut.gain.setValueAtTime(.1,pTime+pLength*.8);tOut.gain.linearRampToValueAtTime(0,pTime+pLength);
  for(const tNode of [tOsc,tReed,tVib]){tNode.start(pTime);tNode.stop(pTime+pLength+.05);}
}
// Swung eighth notes: 8 steps per bar, 16 bars per chorus.
function scheduleStep(pStep,pTime,pBeat){
  const tBarIndex=Math.floor(pStep/8)%gChart.length;
  const tChorus=Math.floor(pStep/(8*gChart.length));
  const tChord=gChart[tBarIndex],tNext=gChart[(tBarIndex+1)%gChart.length];
  const tEighth=pStep%8,tOnBeat=tEighth%2===0,tBeatNum=tEighth/2;
  if(tOnBeat){
    // First half of each chorus is a bouncy two-beat; the second half walks.
    const tRoot=tChord[0];
    let tNote;
    if(tBarIndex<8)tNote=tBeatNum===0?tRoot:tBeatNum===2?tRoot+7:null;
    else tNote=[tRoot,tRoot+(tChord[1]%12===(tRoot+4)%12?4:3),tRoot+7,tNext[0]+(tNext[0]>tRoot?-1:1)][tBeatNum];
    if(tNote!==null){while(tNote>52)tNote-=12;while(tNote<33)tNote+=12;playBass(tNote,pTime,pBeat*(tBarIndex<8?1.6:.95));}
    if(tBeatNum===0||tBeatNum===2)playKick(pTime);
    if(tBeatNum===1||tBeatNum===3){playChord(tChord.slice(1),pTime,pBeat*.55,.3);playSnare(pTime,.05);}
    playRide(pTime,.022);
  }else if(tEighth===3||tEighth===7)playRide(pTime,.014);
  // Little drum fill into the top of the tune.
  if(tBarIndex===15&&tEighth>=4)playSnare(pTime,.03+tEighth*.004);
  // Melody: vibes on even choruses, clarinet on odd ones.
  const tLead=tChorus%2?playClarinet:playVibes;
  for(const [tStart,tNote,tLength] of gTune[tBarIndex]){
    if(tStart!==tEighth)continue;
    const tShift=tChorus%4===3&&tBarIndex>=8?12:0;
    tLead(tNote+tShift,pTime,pBeat*tLength*.5*.95);
  }
}
function musicTick(){
  const tCtx=gMusic.ctx;
  const tBeat=60/musicTempo();
  while(gMusic.nextTime<tCtx.currentTime+.25){
    const tSwing=gMusic.step%2===0?tBeat*.64:tBeat*.36;
    scheduleStep(gMusic.step,gMusic.nextTime,tBeat);
    gMusic.nextTime+=tSwing;gMusic.step++;
  }
}
function startMusic(){
  initAudio();
  const tCtx=gMusic.ctx;
  if(tCtx.state==='suspended')tCtx.resume();
  if(gMusic.playing)return;
  gMusic.playing=true;
  gMusic.nextTime=tCtx.currentTime+.08;gMusic.step=0;
  gMusic.master.gain.cancelScheduledValues(tCtx.currentTime);
  gMusic.master.gain.setTargetAtTime(gSettings.musicVolume*.9,tCtx.currentTime,.4);
  gMusic.timer=setInterval(musicTick,60);
}
function stopMusic(){
  if(!gMusic.playing)return;
  gMusic.playing=false;
  clearInterval(gMusic.timer);
  const tCtx=gMusic.ctx;
  gMusic.master.gain.setTargetAtTime(0,tCtx.currentTime,.25);

}
function setMusicEnabled(pOn){
  gSettings.music=pOn;saveSettings();
  if(pOn)startMusic();else stopMusic();
  renderMusicButton();
}
function setMusicVolume(pValue){
  gSettings.musicVolume=pValue;saveSettings();
  if(gMusic.ctx&&gMusic.playing)gMusic.master.gain.setTargetAtTime(pValue*.9,gMusic.ctx.currentTime,.1);
}
function renderMusicButton(){
  const tButton=$('music');if(!tButton)return;
  tButton.setAttribute('aria-pressed',String(gSettings.music));
  tButton.textContent=gSettings.music?'♪ Music on':'♪ Music off';
  if($('setMusic'))$('setMusic').checked=gSettings.music;
}
function installMusicUI(){
  $('music').onclick=()=>setMusicEnabled(!gSettings.music);
  renderMusicButton();
  // Browsers only allow sound after a click or key press, so audio starts with the first interaction.
  const tKick=()=>{initAudio();if(gMusic.ctx.state==='suspended')gMusic.ctx.resume();if(gSettings.music)startMusic();window.removeEventListener('pointerdown',tKick);window.removeEventListener('keydown',tKick);};
  window.addEventListener('pointerdown',tKick);window.addEventListener('keydown',tKick);
  document.addEventListener('visibilitychange',()=>{
    if(!gMusic.ctx)return;
    if(document.hidden){clearInterval(gMusic.timer);gMusic.ctx.suspend();}
    else{gMusic.ctx.resume().then(()=>{if(gSettings.music&&gMusic.playing){gMusic.nextTime=gMusic.ctx.currentTime+.08;clearInterval(gMusic.timer);gMusic.timer=setInterval(musicTick,60);}});}
  });
}
// ----- Sound effects (all synthesized) -----
function applySfxVolume(){if(gMusic.sfxBus)gMusic.sfxBus.gain.setTargetAtTime(gSettings.sfxVolume*.9,gMusic.ctx.currentTime,.05);}
function fxVoice(pTime,pSend=.15){
  const tCtx=gMusic.ctx,tGain=tCtx.createGain();tGain.gain.value=0;tGain.connect(gMusic.sfxBus);
  if(pSend){const tSend=tCtx.createGain();tSend.gain.value=pSend;tGain.connect(tSend);tSend.connect(gMusic.reverb);}
  return tGain;
}
function fxTone(pFreq,pTime,pLength,pLevel,pType='sine',pSend=.15){
  const tCtx=gMusic.ctx,tOsc=tCtx.createOscillator();tOsc.type=pType;tOsc.frequency.value=pFreq;
  const tOut=fxVoice(pTime,pSend);tOsc.connect(tOut);
  tOut.gain.setValueAtTime(0,pTime);tOut.gain.linearRampToValueAtTime(pLevel,pTime+.005);tOut.gain.exponentialRampToValueAtTime(.0008,pTime+pLength);
  tOsc.start(pTime);tOsc.stop(pTime+pLength+.05);
  return tOsc;
}
function fxNoise(pTime,pLength,pLevel,pType,pFreq,pQ=1){
  const tCtx=gMusic.ctx,tSrc=tCtx.createBufferSource();tSrc.buffer=gMusic.noise;
  const tFilter=tCtx.createBiquadFilter();tFilter.type=pType;tFilter.frequency.value=pFreq;tFilter.Q.value=pQ;
  const tOut=fxVoice(pTime,.05);tSrc.connect(tFilter);tFilter.connect(tOut);
  tOut.gain.setValueAtTime(0,pTime);tOut.gain.linearRampToValueAtTime(pLevel,pTime+.004);tOut.gain.exponentialRampToValueAtTime(.0008,pTime+pLength);
  tSrc.start(pTime,Math.random()*.5);tSrc.stop(pTime+pLength+.05);
}
const gSfx={
  register:pT=>{fxNoise(pT,.08,.25,'highpass',3000);fxTone(1568,pT+.06,.5,.14);fxTone(2093,pT+.14,.7,.16);fxTone(3136,pT+.14,.4,.05);},
  bell:pT=>{for(const tO of [0,.32])for(const [tF,tL] of [[620,.13],[1530,.08],[2380,.05]])fxTone(tF,pT+tO,1.1,tL,'sine',.3);},
  alarm:pT=>{for(let tI=0;tI<6;tI++)fxTone(tI%2?660:880,pT+tI*.18,.16,.08,'square',.05);},
  sting:pT=>{[65,69,72,77].forEach((pNote,pI)=>{const tO=fxTone(midiHz(pNote),pT+pI*.07,.55,.07,'sawtooth',.3);});fxTone(midiHz(53),pT,.6,.1,'sawtooth',.2);},
  chime:pT=>{fxTone(1046,pT,.35,.09,'sine',.2);fxTone(1318,pT+.09,.45,.08,'sine',.2);},
  plates:pT=>{for(let tI=0;tI<4;tI++)fxNoise(pT+tI*.05+Math.random()*.02,.07,.12,'bandpass',3500+tI*700,4);fxTone(2600,pT+.02,.18,.03,'triangle',.05);},
  door:pT=>{fxTone(1975,pT,.6,.08,'sine',.25);fxTone(2637,pT+.05,.5,.05,'sine',.25);},
  inspector:pT=>{fxTone(392,pT,.35,.09,'triangle',.1);fxTone(311,pT+.3,.5,.09,'triangle',.1);}
};
function sfx(pName){
  if(!gSettings.sfx||!gMusic.ctx||gMusic.ctx.state!=='running'||!gSfx[pName])return;
  gSfx[pName](gMusic.ctx.currentTime+.01);
}
// Griddle sizzle: a soft looping hiss while someone is cooking.
function setSizzle(pOn){
  if(!gMusic.ctx||gMusic.ctx.state!=='running')return;
  const tWant=pOn&&gSettings.sfx;
  if(tWant&&!gMusic.sizzle){
    const tCtx=gMusic.ctx,tSrc=tCtx.createBufferSource();tSrc.buffer=gMusic.noise;tSrc.loop=true;
    const tFilter=tCtx.createBiquadFilter();tFilter.type='highpass';tFilter.frequency.value=4200;
    const tOut=fxVoice(tCtx.currentTime,0);tSrc.connect(tFilter);tFilter.connect(tOut);
    tOut.gain.setTargetAtTime(.025,tCtx.currentTime,.3);tSrc.start();
    gMusic.sizzle={src:tSrc,out:tOut};
  }else if(!tWant&&gMusic.sizzle){
    const tS=gMusic.sizzle;gMusic.sizzle=null;
    tS.out.gain.setTargetAtTime(0,gMusic.ctx.currentTime,.25);setTimeout(()=>tS.src.stop(),1200);
  }
}
