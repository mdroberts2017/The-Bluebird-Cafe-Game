// ===== Career: days, day types, reputation, upgrades and the morning paper =====
const gSaveKey='bluebird-career-v1';
const gWeekdays=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const gUpgrades=[
  {id:'griddle2',name:'Second griddle',price:900,text:'Sally cooks backed-up tickets on her own griddle, so Bart stops elbowing her.'},
  {id:'urn',name:'Coffee urn',price:450,text:'Free coffee for the line costs nothing, and counter guests stay happier.'},
  {id:'hood',name:'Hood-cleaning contract',price:350,text:'Grease builds 40% slower. Bart is devastated.'},
  {id:'shoes',name:'Comfy shoes for the crew',price:300,text:'Crew energy drains 35% slower.'},
  {id:'bench',name:'Sidewalk bench',price:250,text:'The line loses patience 20% slower.'},
  {id:'jukebox',name:'Jukebox',price:600,text:'Seated guests lose mood 25% slower. It mostly plays Fats Domino.'}
];
function freshCareer(){return {day:1,bank:0,rep:50,karma:0,upgrades:{},best:0,lastReview:null,seed:Math.floor(Math.random()*1e9),streak:0,saveVersion:2};}
// Saves carry a version number, are checked field by field on load, and the previous good save
// is kept as a backup. A save that cannot be read is set aside rather than lost.
const gSaveVersion=2,gBackupKey='bluebird-career-backup';
let gSaveNotice='';
function sanitizeCareer(pRaw){
  if(!pRaw||typeof pRaw!=='object')return null;
  const tNum=(pValue,pMin,pMax,pFallback)=>Number.isFinite(pValue)?Math.min(pMax,Math.max(pMin,pValue)):pFallback;
  const tFresh=freshCareer();
  if(!Number.isFinite(pRaw.day))return null;
  const tCareer={
    day:Math.round(tNum(pRaw.day,1,100000,1)),
    bank:Math.round(tNum(pRaw.bank,-1e6,1e9,0)),
    rep:Math.round(tNum(pRaw.rep,0,100,50)),
    karma:Math.round(tNum(pRaw.karma,-1e5,1e6,0)),
    best:Math.round(tNum(pRaw.best,0,1e9,0)),
    streak:Math.round(tNum(pRaw.streak,0,1e5,0)),
    seed:Number.isFinite(pRaw.seed)?Math.floor(Math.abs(pRaw.seed))%1e9:tFresh.seed,
    upgrades:{},lastReview:null,saveVersion:gSaveVersion
  };
  if(pRaw.upgrades&&typeof pRaw.upgrades==='object')for(const tUpgrade of gUpgrades)if(pRaw.upgrades[tUpgrade.id])tCareer.upgrades[tUpgrade.id]=true;
  const tReview=pRaw.lastReview;
  if(tReview&&typeof tReview==='object'&&typeof tReview.headline==='string'){
    tCareer.lastReview={day:Math.round(tNum(tReview.day,1,1e5,1)),weekday:gWeekdays.includes(tReview.weekday)?tReview.weekday:'',stars:Math.round(tNum(tReview.stars,1,5,3)),
      headline:tReview.headline.slice(0,160),served:Math.round(tNum(tReview.served,0,1e4,0)),lost:Math.round(tNum(tReview.lost,0,1e4,0)),cash:Math.round(tNum(tReview.cash,-1e6,1e9,0)),grade:['A','B','C'].includes(tReview.grade)?tReview.grade:null};
  }
  return tCareer;
}
function readSave(pKey){
  const tText=localStorage.getItem(pKey);
  if(tText===null)return {missing:true};
  try{const tCareer=sanitizeCareer(JSON.parse(tText));return tCareer?{career:tCareer}:{bad:tText};}catch{return {bad:tText};}
}
function loadCareer(){
  try{
    const tMain=readSave(gSaveKey);
    if(tMain.career)return tMain.career;
    if(tMain.missing)return freshCareer();
    localStorage.setItem('bluebird-career-unreadable-'+Date.now(),tMain.bad);
    const tBackup=readSave(gBackupKey);
    if(tBackup.career){gSaveNotice='Your saved career could not be read, so the previous backup was restored.';return tBackup.career;}
    gSaveNotice='Your saved career could not be read. It was set aside and a new career has begun.';
  }catch{}
  return freshCareer();
}
function saveCareer(){
  try{
    const tPrevious=localStorage.getItem(gSaveKey);
    if(tPrevious!==null&&readSave(gSaveKey).career)localStorage.setItem(gBackupKey,tPrevious);
    gCareer.saveVersion=gSaveVersion;
    localStorage.setItem(gSaveKey,JSON.stringify(gCareer));
  }catch{}
}
let gCareer=loadCareer();
function owns(pId){return !!gCareer.upgrades[pId];}
function seededRandom(pSeed){
  let tState=pSeed>>>0;
  return ()=>{tState=(tState+0x6D2B79F5)>>>0;let tT=tState;tT=Math.imul(tT^tT>>>15,tT|1);tT^=tT+Math.imul(tT^tT>>>7,tT|61);return ((tT^tT>>>14)>>>0)/4294967296;};
}
// Every day has a type. Mondays are red beans, Saturdays bring Jazz Fest crowds, every tenth day is Mardi Gras.
function dayInfo(pDay){
  const tRandom=seededRandom(pDay*9301+gCareer.seed);
  const tWeekday=gWeekdays[(pDay+1)%7];
  const tInfo={day:pDay,weekday:tWeekday,kind:'ordinary',title:'An ordinary '+tWeekday,text:'Regulars, tourists and the usual chaos.',crowd:1,patience:1,tipBonus:0,closing:150,inspector:false,band:.3,critic:false,special:null,costume:null};
  if(pDay%10===0){
    Object.assign(tInfo,{kind:'mardigras',title:'Mardi Gras morning',text:'Masks, beads and a line around the block. Tips run high and patience runs low. The inspector is coming, in costume.',crowd:1.55,patience:.85,tipBonus:.3,inspector:true,band:.8,costume:'dressed as a crawfish'});
  }else if(tWeekday==='Monday'){
    Object.assign(tInfo,{kind:'redbeans',title:'Red Beans Monday',text:'Red beans & rice is on the menu. Half of Mid-City shows up for it.',crowd:1.35,special:'redbeans'});
  }else if(tWeekday==='Saturday'){
    Object.assign(tInfo,{kind:'jazzfest',title:'Jazz Fest weekend',text:'Festival crowds with deep pockets. A brass band will definitely show up.',crowd:1.3,tipBonus:.2,band:1});
  }else if(tWeekday==='Sunday'){
    Object.assign(tInfo,{kind:'saints',title:'Saints game day',text:'Black and gold everywhere. The after-church, pre-game crowd is patient, loud and very hungry. Who Dat!',crowd:1.25,patience:1.15,tipBonus:.1});
  }else if(pDay>2&&tRandom()<.14){
    Object.assign(tInfo,{kind:'hurricane',title:'Hurricane warning',text:'Everyone wants one last breakfast before the storm. The café closes early, so serve fast.',crowd:1.1,patience:.8,closing:112,band:0});
  }else if(pDay>1&&tRandom()<.18){
    Object.assign(tInfo,{kind:'critic',title:'A food critic is in town',text:'Somewhere in today’s line is the Bugle’s restaurant critic. Keep that table happy.',critic:true});
  }
  // A daily goal pays a bonus.
  const tGoals=[
    {id:'served',target:Math.round(13*tInfo.crowd*tInfo.closing/150),text:n=>'Serve '+n+' parties'},
    {id:'noWalkouts',target:0,text:()=>'No walkouts'},
    {id:'cash',target:Math.round(330*tInfo.crowd*tInfo.closing/150/10)*10,text:n=>'Earn $'+n+' in sales and tips'},
    {id:'tips',target:Math.round(70*tInfo.crowd*(1+tInfo.tipBonus)/5)*5,text:n=>'Collect $'+n+' in tips'}
  ];
  if(tInfo.inspector)tGoals.push({id:'gradeA',target:0,text:()=>'Earn an A from the inspector'});
  tInfo.goal=tGoals[Math.floor(tRandom()*tGoals.length)];
  tInfo.goalText=tInfo.goal.text(tInfo.goal.target);
  return tInfo;
}
let gToday=dayInfo(gCareer.day);
function reputationStars(pRep){const tStars=Math.max(1,Math.min(5,Math.round(pRep/20)));return '★'.repeat(tStars)+'☆'.repeat(5-tStars);}
function buildArrivals(pDay){
  const tRandom=seededRandom(pDay.day*7919+gCareer.seed);
  const tRepFactor=1+(gCareer.rep-50)/160;
  const tCount=Math.max(10,Math.round(18*pDay.crowd*tRepFactor*pDay.closing/150));
  const tStart=12,tEnd=pDay.closing-6;
  const tTimes=[];
  for(let tI=0;tI<tCount;tI++){tTimes.push(tStart+(tEnd-tStart)*(tI+.15+tRandom()*.7)/tCount);}
  return tTimes;
}
function buildSchedule(pDay){
  const tList=[];
  const tR=Math.random;
  if(tR()<pDay.band)tList.push({at:pDay.kind==='jazzfest'?22:30+tR()*60,kind:'band'});
  if(tR()<.55)tList.push({at:38+tR()*70,kind:'cutter'});
  if(tR()<.5)tList.push({at:45+tR()*60,kind:'janeBreak'});
  return tList;
}
function goalMet(pShift){
  const tGoal=pShift.day.goal;
  switch(tGoal.id){
    case 'served':return pShift.served>=tGoal.target;
    case 'noWalkouts':return pShift.lost===0&&pShift.served>0;
    case 'cash':return pShift.cash>=tGoal.target;
    case 'tips':return pShift.tips>=tGoal.target;
    case 'gradeA':return pShift.grade==='A';
  }
  return false;
}
// The Bluebird Bugle reviews every shift.
function reviewShift(pShift){
  let tStars=3;
  const tAvgMood=pShift.paidParties?pShift.moodSum/pShift.paidParties:0;
  if(pShift.lost===0&&pShift.served>0)tStars++;
  tStars-=Math.floor(pShift.lost/2);
  if(pShift.grade==='A')tStars++;
  if(pShift.grade==='C')tStars--;
  if(tAvgMood>=.85)tStars++;
  if(pShift.bigFire)tStars--;
  if(pShift.criticResult==='rave')tStars++;
  if(pShift.criticResult==='pan'||pShift.criticResult==='walkout')tStars--;
  tStars=Math.max(1,Math.min(5,tStars));
  const tHeadlines=[
    [pShift.criticResult==='rave','Critic Calls Bluebird’s Grits “A Religious Experience”'],
    [pShift.criticResult==='walkout','Bugle Critic Gives Up on Line, Reviews the Sidewalk Instead'],
    [pShift.criticResult==='pan','Critic Still Waiting on Biscuits, Sources Say'],
    [pShift.bigFire,'Fire Marshal: Bluebird Griddle Fire “Not Decorative, Bart”'],
    [pShift.grade==='C','Inspector Finds Bluebird Griddle “Historically Significant”'],
    [pShift.lost>=4,'Bluebird Line Stretches Past Touro Infirmary; Visible From Space'],
    [pShift.day.kind==='saints'&&pShift.lost===0,'Who Dat? Bluebird Dat. Saints Fans Fed Before Kickoff'],
    [pShift.day.kind==='hurricane'&&pShift.served>0,'Bluebird Serves Grits Into the Teeth of the Storm'],
    [pShift.day.kind==='mardigras','Krewe of Breakfast Rolls Through Bluebird, Leaves Beads in the Syrup'],
    [pShift.day.kind==='redbeans','Bluebird’s Red Beans: Still Better Than Your Mama’s (Don’t Tell Her)'],
    [pShift.bandPlayed,'Brass Band Plays “Saints” For the 400th Time; Line Sways Happily'],
    [pShift.flambe,'Bart Calls Morning Flare-Up “a Flambé,” Nobody Argues'],
    [tStars>=5,'Bluebird Flies High: Not One Grumpy Customer on the Block'],
    [tStars<=1,'Bluebird Has an Off Morning; Regulars Pretend Not to Notice'],
    [pShift.grade==='A','Health Inspector Leaves Bluebird Smiling, Possibly Full'],
    [true,['Bluebird Keeps the Chicory Coming and the Grits Creamy','Another Morning, Another Line Down Prytania','Sally Runs a Tight Ship, Bart Runs a Loose Spatula','Uptown Agrees: The Pain Perdu Is Worth the Wait'][pShift.day.day%4]]
  ];
  const tHeadline=tHeadlines.find(([tWhen])=>tWhen)[1];
  return {stars:tStars,headline:tHeadline,avgMood:tAvgMood};
}
function closeCareerDay(pShift){
  const tReview=reviewShift(pShift);
  const tGoal=goalMet(pShift);
  let tRepChange=(tReview.stars-3)*3;
  if(pShift.criticResult==='rave')tRepChange+=6;
  if(pShift.criticResult==='pan'||pShift.criticResult==='walkout')tRepChange-=5;
  if(tGoal)tRepChange+=2;
  const tBonus=tGoal?50+10*Math.min(5,gCareer.streak||0):0;
  const tFoodCost=Math.round(pShift.sales*.25);
  const tOverhead=pShift.day.kind==='mardigras'?200:150;
  const tEarned=pShift.cash+tBonus-tFoodCost-tOverhead;
  gCareer.bank+=tEarned;
  gCareer.rep=Math.max(0,Math.min(100,gCareer.rep+tRepChange));
  gCareer.karma+=pShift.karma;
  gCareer.best=Math.max(gCareer.best||0,pShift.cash);
  gCareer.streak=tGoal?(gCareer.streak||0)+1:0;
  gCareer.lastReview={day:pShift.day.day,weekday:pShift.day.weekday,stars:tReview.stars,headline:tReview.headline,served:pShift.served,lost:pShift.lost,cash:pShift.cash,grade:pShift.grade};
  gCareer.day++;
  saveCareer();
  gToday=dayInfo(gCareer.day);
  return {review:tReview,goal:tGoal,bonus:tBonus,repChange:tRepChange,earned:tEarned,foodCost:tFoodCost,overhead:tOverhead};
}
function careerLine(){
  return 'Day '+gToday.day+' · '+gToday.weekday+' · '+gToday.title;
}
function renderCareerStrip(){
  const tShift=shift;
  const tGoalState=tShift&&tShift.mode!=='idle'&&goalMet(tShift)?' ✓':'';
  $('careerDay').textContent=careerLine();
  $('careerGoal').textContent='Goal · '+gToday.goalText+tGoalState;
  $('careerRep').textContent=reputationStars(gCareer.rep);
  $('careerRep').title='Reputation '+gCareer.rep+' / 100';
  $('careerBank').textContent='Bank $'+gCareer.bank.toLocaleString();
  $('careerKarma').textContent='Karma '+(gCareer.karma+(tShift?tShift.karma:0));
}
function showPaper(){
  const tLast=gCareer.lastReview;
  $('paperDate').textContent='Day '+gToday.day+' · '+gToday.weekday+' morning edition · Five cents';
  $('paperHeadline').textContent=tLast?tLast.headline:'Bluebird Cafe Throws Open Its Doors; Grits Reported “Creamy”';
  $('paperReview').textContent=tLast?('Yesterday ('+tLast.weekday+'): '+'★'.repeat(tLast.stars)+'☆'.repeat(5-tLast.stars)+' · '+tLast.served+' parties served, '+tLast.lost+' walkouts, $'+tLast.cash+' taken'+(tLast.grade?' · health grade '+tLast.grade:'')+'.'):'Our reviewer has not visited yet. Local pigeons rate the sidewalk four stars.';
  $('paperToday').textContent=gToday.title;
  $('paperTodayText').textContent=gToday.text+(gToday.special?' Today’s special: Red beans & rice, $8.':'');
  $('paperGoal').textContent='Today’s goal: '+gToday.goalText+'. Bonus $'+(50+10*Math.min(5,gCareer.streak||0))+' and a reputation bump.';
  $('paperNotice').textContent=gSaveNotice;$('paperNotice').hidden=!gSaveNotice;gSaveNotice='';
  $('paperStats').textContent='Bank $'+gCareer.bank.toLocaleString()+' · Reputation '+reputationStars(gCareer.rep)+' · Neighborhood karma '+gCareer.karma+(gCareer.streak?' · Goal streak '+gCareer.streak:'');
  if(!$('paper').open)$('paper').showModal();
}
let gResetArmed=false;
function renderShop(){
  $('shopBank').textContent='Bank $'+gCareer.bank.toLocaleString();
  $('shopItems').replaceChildren(...gUpgrades.map(pUpgrade=>{
    const tRow=document.createElement('div');tRow.className='shopItem';
    const tOwned=owns(pUpgrade.id);
    tRow.innerHTML='<div><strong></strong><small></small></div><button class="button"></button>';
    tRow.querySelector('strong').textContent=pUpgrade.name;
    tRow.querySelector('small').textContent=pUpgrade.text;
    const tBuy=tRow.querySelector('button');
    tBuy.textContent=tOwned?'Installed':'$'+pUpgrade.price;
    tBuy.disabled=tOwned||gCareer.bank<pUpgrade.price;
    if(!tOwned&&gCareer.bank>=pUpgrade.price)tBuy.classList.add('primary');
    tBuy.onclick=()=>{
      if(owns(pUpgrade.id)||gCareer.bank<pUpgrade.price)return;
      gCareer.bank-=pUpgrade.price;gCareer.upgrades[pUpgrade.id]=true;saveCareer();
      renderShop();renderCareerStrip();applyDayTo3D();
    };
    return tRow;
  }));
  gResetArmed=false;
  $('newCareer').textContent='Start a new career';
}
function showShop(){renderShop();if(!$('shop').open)$('shop').showModal();}
function installCareerUI(){
  $('paperOpen').onclick=()=>{$('paper').close();if(shift.mode!=='open')reset(true);};
  $('paperShop').onclick=()=>{$('paper').close();showShop();};
  $('shopDone').onclick=()=>{$('shop').close();showPaper();};
  $('newCareer').onclick=()=>{
    if(!gResetArmed){gResetArmed=true;$('newCareer').textContent='Tap again to erase your career';return;}
    gCareer=freshCareer();saveCareer();gToday=dayInfo(gCareer.day);
    $('shop').close();reset();showPaper();
  };
  $('careerShop').onclick=()=>{if(shift.mode!=='open')showShop();};
}
