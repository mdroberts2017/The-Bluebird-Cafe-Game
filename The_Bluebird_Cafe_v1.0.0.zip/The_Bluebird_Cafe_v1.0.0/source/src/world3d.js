// ===== 3D café world =====
// Game coordinates: x runs along the storefront, y runs from the back wall (0) to the
// sidewalk, h is height. Three.js uses (x, h, y).
const gRoomW=10.7, gRoomD=8.45, gWallH=3.0, gWallT=.2, gStubH=.42, gFloorH=.02;
const gDoorX=5.15;
const gViews={
  street:{center:[6.4,7.6,1.3],size:11.6,cut:false},
  room:{center:[5.7,4.7,.5],size:10.3,cut:true}
};
const gCam={az:Math.PI/4,turns:0,zoom:1,size:12,center:new THREE.Vector3(),pan:new THREE.Vector3(),ready:false};
let gRenderer,gScene,gCamera,gSun,gAtlasTextures=[],gAtlasRows=[];
const gActors=new Map();
const gWalls={};
let gOverhead,gRoofGroup,gCookPan,gCookGlow,gRegisterPlaque;
const gTableProps=[];
const gMatCache=new Map();
const W3=(pX,pY,pH=0)=>new THREE.Vector3(pX,pH,pY);

function gm(pColor,pRough=.86,pMetal=0){
  const tKey=pColor+'|'+pRough+'|'+pMetal;
  if(!gMatCache.has(tKey))gMatCache.set(tKey,new THREE.MeshStandardMaterial({color:pColor,roughness:pRough,metalness:pMetal}));
  return gMatCache.get(tKey);
}
function texMat(pTexture,pRough=.88,pExtra={}){return new THREE.MeshStandardMaterial({map:pTexture,roughness:pRough,...pExtra});}
function canvasTexture(pW,pH,pDraw,pRepeat=true){
  const tCanvas=document.createElement('canvas');tCanvas.width=pW;tCanvas.height=pH;
  pDraw(tCanvas.getContext('2d'),pW,pH);
  const tTex=new THREE.CanvasTexture(tCanvas);
  tTex.colorSpace=THREE.SRGBColorSpace;
  if(pRepeat){tTex.wrapS=tTex.wrapT=THREE.RepeatWrapping;}
  tTex.anisotropy=8;
  return tTex;
}
function worldUV(pGeo,pW,pH,pD,pScale=1){
  const tUV=pGeo.attributes.uv;
  const tDims=[[pD,pH],[pD,pH],[pW,pD],[pW,pD],[pW,pH],[pW,pH]];
  for(let tF=0;tF<6;tF++)for(let tV=0;tV<4;tV++){
    const tI=tF*4+tV;
    tUV.setXY(tI,tUV.getX(tI)*tDims[tF][0]/pScale,tUV.getY(tI)*tDims[tF][1]/pScale);
  }
}
function box(pParent,pX0,pY0,pH0,pX1,pY1,pH1,pMat,pShadow=true){
  const tW=Math.abs(pX1-pX0),tD=Math.abs(pY1-pY0),tH=Math.abs(pH1-pH0);
  const tGeo=new THREE.BoxGeometry(tW,tH,tD);
  worldUV(tGeo,tW,tH,tD);
  const tMesh=new THREE.Mesh(tGeo,pMat);
  tMesh.position.set((pX0+pX1)/2,(pH0+pH1)/2,(pY0+pY1)/2);
  tMesh.castShadow=pShadow;tMesh.receiveShadow=true;
  pParent.add(tMesh);
  return tMesh;
}
function cyl(pParent,pX,pY,pH0,pH1,pRTop,pMat,pRBottom=pRTop,pSegments=20){
  const tMesh=new THREE.Mesh(new THREE.CylinderGeometry(pRTop,pRBottom,pH1-pH0,pSegments),pMat);
  tMesh.position.set(pX,(pH0+pH1)/2,pY);
  tMesh.castShadow=tMesh.receiveShadow=true;
  pParent.add(tMesh);
  return tMesh;
}
// A flat picture on a wall. pFacing: 'y+', 'y-', 'x+', 'x-' (direction the picture faces).
function decal(pParent,pMat,pX,pY,pH,pWidth,pHeight,pFacing){
  const tMesh=new THREE.Mesh(new THREE.PlaneGeometry(pWidth,pHeight),pMat);
  tMesh.position.set(pX,pH,pY);
  tMesh.rotation.y={'y+':0,'y-':Math.PI,'x+':Math.PI/2,'x-':-Math.PI/2}[pFacing];
  tMesh.receiveShadow=true;
  pParent.add(tMesh);
  return tMesh;
}
function textSprite(pText,pFill,pHeight=.25,pInk='#fff5df'){
  const tTex=canvasTexture(16,16,()=>{},false);
  const tCanvas=tTex.image,tCtx=tCanvas.getContext('2d');
  tCtx.font='800 34px system-ui,sans-serif';
  const tWidth=Math.ceil(tCtx.measureText(pText).width)+30;
  tCanvas.width=tWidth;tCanvas.height=50;
  tCtx.font='800 34px system-ui,sans-serif';
  tCtx.fillStyle=pFill;
  tCtx.beginPath();tCtx.roundRect(1,1,tWidth-2,48,10);tCtx.fill();
  tCtx.fillStyle=pInk;tCtx.textAlign='center';tCtx.textBaseline='middle';tCtx.fillText(pText,tWidth/2,27);
  tTex.needsUpdate=true;
  const tSprite=new THREE.Sprite(new THREE.SpriteMaterial({map:tTex,depthTest:true,depthWrite:false,transparent:true,toneMapped:false}));
  tSprite.scale.set(pHeight*tWidth/50,pHeight,1);
  tSprite.renderOrder=20;
  tSprite.center.set(.5,0);
  return tSprite;
}
const gBubbleTextures={};
function bubbleTexture(pKind){
  if(gBubbleTextures[pKind])return gBubbleTextures[pKind];
  const tTex=canvasTexture(96,96,(pCtx)=>{
    pCtx.fillStyle='#fffaf0';pCtx.strokeStyle='#33464b';pCtx.lineWidth=3;
    pCtx.beginPath();pCtx.ellipse(48,40,40,32,0,0,7);pCtx.fill();pCtx.stroke();
    for(const [tX,tY,tR] of [[30,78,7],[22,90,4]]){pCtx.beginPath();pCtx.arc(tX,tY,tR,0,7);pCtx.fill();pCtx.stroke();}
    pCtx.lineWidth=4;
    if(pKind==='clock'){
      pCtx.strokeStyle='#9d452d';pCtx.beginPath();pCtx.arc(48,40,20,0,7);pCtx.stroke();
      pCtx.beginPath();pCtx.moveTo(48,40);pCtx.lineTo(48,26);pCtx.moveTo(48,40);pCtx.lineTo(59,46);pCtx.stroke();
    }else if(pKind==='grumpy'){
      pCtx.fillStyle='#d9a14a';pCtx.beginPath();pCtx.arc(48,40,21,0,7);pCtx.fill();
      pCtx.fillStyle='#3a2a20';pCtx.fillRect(38,32,5,6);pCtx.fillRect(53,32,5,6);
      pCtx.strokeStyle='#3a2a20';pCtx.beginPath();pCtx.arc(48,58,10,Math.PI*1.15,Math.PI*1.85);pCtx.stroke();
    }else if(pKind==='coffee'){
      pCtx.fillStyle='#f6f1e4';pCtx.strokeStyle='#5a3a26';pCtx.fillRect(32,30,26,24);pCtx.strokeRect(32,30,26,24);
      pCtx.beginPath();pCtx.arc(60,42,7,-1.5,1.5);pCtx.stroke();
      pCtx.fillStyle='#5a3a26';pCtx.fillRect(34,31,22,5);
      pCtx.strokeStyle='#9aa4a6';pCtx.lineWidth=3;for(const tX of [38,46,54]){pCtx.beginPath();pCtx.moveTo(tX,26);pCtx.quadraticCurveTo(tX-5,20,tX,14);pCtx.stroke();}
    }else if(pKind==='zzz'){
      pCtx.fillStyle='#2d5d81';pCtx.font='bold 26px Georgia';pCtx.textAlign='center';pCtx.fillText('z',34,54);pCtx.font='bold 32px Georgia';pCtx.fillText('Z',52,46);pCtx.font='bold 20px Georgia';pCtx.fillText('z',68,30);
    }else if(pKind==='star'){
      pCtx.fillStyle='#d99b2b';pCtx.font='bold 44px Georgia';pCtx.textAlign='center';pCtx.fillText('★',48,56);
    }else if(pKind==='note'){
      pCtx.fillStyle='#2d5d81';pCtx.font='bold 40px Georgia';pCtx.textAlign='center';pCtx.fillText('♪♫',48,54);
    }
  },false);
  gBubbleTextures[pKind]=tTex;
  return tTex;
}
function makeBubble(pKind){
  const tSprite=new THREE.Sprite(new THREE.SpriteMaterial({map:bubbleTexture(pKind),depthTest:true,depthWrite:false,transparent:true,toneMapped:false}));
  tSprite.scale.set(.5,.5,1);tSprite.center.set(.3,0);tSprite.renderOrder=19;
  return tSprite;
}

// ----- Textures -----
function buildTextures(){
  const tNoise=(pCtx,pW,pH,pCount,pColors,pSize=2)=>{
    for(let tI=0;tI<pCount;tI++){pCtx.fillStyle=pColors[tI%pColors.length];pCtx.fillRect((tI*137.07)%pW,(tI*239.42)%pH,pSize,pSize*.8);}
  };
  const tBrick=(pBase,pMortar,pVar)=>canvasTexture(256,256,(pCtx)=>{
    pCtx.fillStyle=pMortar;pCtx.fillRect(0,0,256,256);
    const tRows=10,tRowH=256/tRows;
    for(let tR=0;tR<tRows;tR++){
      const tOff=tR%2?0:-32;
      for(let tX=tOff;tX<256;tX+=64){
        pCtx.fillStyle=pVar[(tR*7+tX/64*3+9)%pVar.length]||pBase;
        pCtx.fillRect(tX+2,tR*tRowH+2,60,tRowH-3);
      }
    }
    tNoise(pCtx,256,256,900,['#00000010','#ffffff12']);
  });
  const tTex={};
  tTex.brickYellow=tBrick('#dba64e','#c08e3e',['#dca84f','#d9a24a','#dfae58','#d6a049','#ddaa52']);
  tTex.brickOrange=tBrick('#d7843f','#bb6d32',['#d8853f','#d27e3a','#dc8c46','#d58140']);
  tTex.corrugated=canvasTexture(128,128,(pCtx)=>{
    for(let tX=0;tX<128;tX+=13){
      const tG=pCtx.createLinearGradient(tX,0,tX+13,0);
      tG.addColorStop(0,'#5d87ad');tG.addColorStop(.5,'#88aed0');tG.addColorStop(1,'#4f789c');
      pCtx.fillStyle=tG;pCtx.fillRect(tX,0,13,128);
    }
  });
  tTex.clapboard=canvasTexture(128,128,(pCtx)=>{
    pCtx.fillStyle='#f3f1ea';pCtx.fillRect(0,0,128,128);
    for(let tY=0;tY<128;tY+=16){pCtx.fillStyle='#c9c7be';pCtx.fillRect(0,tY+13,128,3);pCtx.fillStyle='#ffffff';pCtx.fillRect(0,tY,128,3);}
  });
  tTex.stucco=canvasTexture(128,128,(pCtx)=>{pCtx.fillStyle='#dccfb1';pCtx.fillRect(0,0,128,128);tNoise(pCtx,128,128,600,['#00000012','#ffffff18']);});
  tTex.kitchenFloor=canvasTexture(256,256,(pCtx)=>{
    for(let tI=0;tI<4;tI++){const tX=tI%2,tY=tI>>1;pCtx.fillStyle=(tX+tY)%2?'#d5d6bd':'#879e8d';pCtx.fillRect(tX*128,tY*128,128,128);}
    pCtx.strokeStyle='#a69b7e80';pCtx.lineWidth=3;pCtx.strokeRect(0,0,128,128);pCtx.strokeRect(128,128,128,128);pCtx.strokeRect(0,128,128,128);pCtx.strokeRect(128,0,128,128);
    tNoise(pCtx,256,256,700,['#0000000d','#ffffff12']);
  });
  tTex.kitchenFloor.repeat.set(1/1.34,1/1.3);
  tTex.diningFloor=canvasTexture(384,384,(pCtx)=>{
    for(let tX=0;tX<3;tX++)for(let tY=0;tY<3;tY++){
      pCtx.fillStyle=(tX+tY)%3?'#dcd0ad':'#cbbb93';pCtx.fillRect(tX*128,tY*128,128,128);
      pCtx.strokeStyle='#a69b7e70';pCtx.lineWidth=3;pCtx.strokeRect(tX*128,tY*128,128,128);
    }
    tNoise(pCtx,384,384,900,['#0000000c','#ffffff14']);
  });
  tTex.diningFloor.repeat.set(1/2.01,1/1.95);
  tTex.gingham=canvasTexture(128,128,(pCtx)=>{
    pCtx.fillStyle='#789b78';pCtx.fillRect(0,0,128,128);
    for(let tI=0;tI<8;tI++){pCtx.fillStyle='#f1e6bc66';pCtx.fillRect(tI*16,0,8,128);pCtx.fillRect(0,tI*16,128,8);}
  });
  tTex.gingham.repeat.set(2,2);
  tTex.sidewalk=canvasTexture(256,256,(pCtx)=>{
    pCtx.fillStyle='#d6cfbe';pCtx.fillRect(0,0,256,256);tNoise(pCtx,256,256,2600,['#0000000e','#ffffff16','#8a7f6a14']);
    pCtx.strokeStyle='#a69d88';pCtx.lineWidth=3;pCtx.strokeRect(0,0,256,256);
  });
  tTex.sidewalk.repeat.set(1/1.4,1/1.4);
  tTex.asphalt=canvasTexture(256,256,(pCtx)=>{pCtx.fillStyle='#5e605d';pCtx.fillRect(0,0,256,256);tNoise(pCtx,256,256,4000,['#ffffff10','#0000001a','#7a7a7020'],2);});
  tTex.asphalt.repeat.set(.25,.25);
  tTex.grass=canvasTexture(256,256,(pCtx)=>{pCtx.fillStyle='#93a865';pCtx.fillRect(0,0,256,256);tNoise(pCtx,256,256,5000,['#7f9656','#a3b673','#86a05c','#b0bc7c'],3);});
  tTex.grass.repeat.set(.2,.2);
  tTex.roofTile=canvasTexture(128,128,(pCtx)=>{
    pCtx.fillStyle='#b65a37';pCtx.fillRect(0,0,128,128);
    for(let tY=0;tY<128;tY+=32)for(let tX=0;tX<128;tX+=21){const tG=pCtx.createLinearGradient(tX,0,tX+21,0);tG.addColorStop(0,'#9a4429');tG.addColorStop(.5,'#cf7048');tG.addColorStop(1,'#9a4429');pCtx.fillStyle=tG;pCtx.fillRect(tX,tY,21,28);}
  });
  tTex.shingle=canvasTexture(128,128,(pCtx)=>{
    pCtx.fillStyle='#7d7e7c';pCtx.fillRect(0,0,128,128);
    for(let tY=0;tY<128;tY+=16)for(let tX=(tY/16)%2*12;tX<128;tX+=24){pCtx.fillStyle=['#8a8b88','#73746f','#80817c'][(tX+tY)%3];pCtx.fillRect(tX,tY,22,14);}
  });
  tTex.tile=canvasTexture(128,128,(pCtx)=>{pCtx.fillStyle='#eef0e4';pCtx.fillRect(0,0,128,128);pCtx.strokeStyle='#c7cdbb';pCtx.lineWidth=2;for(let tI=0;tI<=128;tI+=32){pCtx.beginPath();pCtx.moveTo(tI,0);pCtx.lineTo(tI,128);pCtx.moveTo(0,tI);pCtx.lineTo(128,tI);pCtx.stroke();}});
  tTex.blinds=canvasTexture(64,128,(pCtx)=>{pCtx.fillStyle='#c9d3b9';pCtx.fillRect(0,0,64,128);for(let tY=0;tY<128;tY+=8){pCtx.fillStyle='#e6e8d6';pCtx.fillRect(0,tY,64,5);}},false);
  tTex.awning=canvasTexture(256,64,(pCtx)=>{for(let tX=0;tX<256;tX+=32){pCtx.fillStyle='#2f5f8a';pCtx.fillRect(tX,0,16,64);pCtx.fillStyle='#6f9cc2';pCtx.fillRect(tX+16,0,16,64);}});
  tTex.awning.repeat.set(1/1.1,1);
  tTex.valance=canvasTexture(256,64,(pCtx)=>{
    for(let tX=0;tX<256;tX+=32){pCtx.fillStyle='#2f5f8a';pCtx.fillRect(tX,0,16,40);pCtx.fillStyle='#6f9cc2';pCtx.fillRect(tX+16,0,16,40);}
    for(let tX=0;tX<256;tX+=32){pCtx.fillStyle=(tX/32)%2?'#2f5f8a':'#3f74a2';pCtx.beginPath();pCtx.arc(tX+16,40,16,0,Math.PI);pCtx.fill();}
  });
  tTex.valance.repeat.set(1/1.1,1);
  tTex.wood=canvasTexture(128,128,(pCtx)=>{pCtx.fillStyle='#82644a';pCtx.fillRect(0,0,128,128);for(let tX=0;tX<128;tX+=16){pCtx.fillStyle='#694b37';pCtx.fillRect(tX,0,2,128);}tNoise(pCtx,128,128,500,['#00000014','#ffffff10']);});
  tTex.fence=canvasTexture(128,128,(pCtx)=>{pCtx.fillStyle='#4a3f36';pCtx.fillRect(0,0,128,128);for(let tX=0;tX<128;tX+=16){pCtx.fillStyle=['#5b4d40','#544638','#615243'][tX/16%3];pCtx.fillRect(tX+1,0,14,128);}});
  tTex.signOval=canvasTexture(512,160,(pCtx)=>{
    pCtx.fillStyle='#24485d';pCtx.beginPath();pCtx.ellipse(256,80,250,76,0,0,7);pCtx.fill();
    pCtx.fillStyle='#f4e7bf';pCtx.beginPath();pCtx.ellipse(256,80,238,66,0,0,7);pCtx.fill();
    pCtx.fillStyle='#244453';pCtx.font='italic 700 62px Georgia,serif';pCtx.textAlign='center';pCtx.textBaseline='middle';pCtx.fillText('Bluebird Cafe',256,84);
  },false);
  tTex.menuBoard=canvasTexture(400,300,drawMenuBoard,false);
  tTex.open=canvasTexture(128,64,(pCtx)=>{pCtx.fillStyle='#1d2224';pCtx.fillRect(0,0,128,64);pCtx.strokeStyle='#ff6a4d';pCtx.lineWidth=4;pCtx.strokeRect(6,6,116,52);pCtx.fillStyle='#ff8a6a';pCtx.font='bold 34px system-ui';pCtx.textAlign='center';pCtx.fillText('OPEN',64,45);},false);
  // Framed pictures hung between the left-wall windows: the poster and a stylized portrait ("Daughter").
  const tFramed=(pSrc,pW,pH)=>{
    const tTex=canvasTexture(pW+32,pH+32,(pCtx,pCW,pCH)=>{
      pCtx.fillStyle='#5b3f2f';pCtx.fillRect(0,0,pCW,pCH);
      pCtx.fillStyle='#8a6446';pCtx.fillRect(4,4,pCW-8,pCH-8);
      pCtx.fillStyle='#3e2a1f';pCtx.fillRect(12,12,pCW-24,pCH-24);
      pCtx.fillStyle='#d8c9a3';pCtx.fillRect(16,16,pW,pH);
    },false);
    const tImg=new Image();
    tImg.onload=()=>{const tCtx=tTex.image.getContext('2d');tCtx.drawImage(tImg,16,16,pW,pH);tTex.needsUpdate=true;};
    tImg.src=pSrc;
    return tTex;
  };
  tTex.artSarah=tFramed('%%ART_SARAH%%',300,400);
  tTex.artPoster=canvasTexture(352,372,(pCtx)=>{
    pCtx.fillStyle='#5b3f2f';pCtx.fillRect(0,0,352,372);pCtx.fillStyle='#8a6446';pCtx.fillRect(4,4,344,364);
    pCtx.fillStyle='#3e2a1f';pCtx.fillRect(12,12,328,348);
    pCtx.save();pCtx.translate(16,16);drawPosterArt(pCtx,320,340);pCtx.restore();
  },false);
  const tImageTexture=(pImg)=>{
    const tT=new THREE.Texture(pImg);tT.colorSpace=THREE.SRGBColorSpace;tT.anisotropy=8;
    if(pImg.complete&&pImg.naturalWidth)tT.needsUpdate=true;else pImg.addEventListener('load',()=>{tT.needsUpdate=true;});
    return tT;
  };
  tTex.restroom=tImageTexture(restroomSign);
  const tMuralImage=new Image();tMuralImage.src=$('mural').src;
  tTex.mural=tImageTexture(tMuralImage);
  tTex.sky=canvasTexture(4,256,(pCtx)=>{const tG=pCtx.createLinearGradient(0,0,0,256);tG.addColorStop(0,'#3f7fcf');tG.addColorStop(.6,'#8fbbe6');tG.addColorStop(1,'#d9e6dd');pCtx.fillStyle=tG;pCtx.fillRect(0,0,4,256);},false);
  return tTex;
}
let gTex;

// ----- Walls with openings and Sims-style cutaway -----
const gWallSpecs={
  back:{along:'x',inner:0,out:-1,from:-gWallT,to:gRoomW+gWallT,normal:[0,-1],
    openings:[{a:.66,b:1.96,lo:1.23,hi:2.58,blinds:true},{a:8.12,b:9.3,lo:1.23,hi:2.58,blinds:true}]},
  front:{along:'x',inner:gRoomD,out:1,from:-gWallT,to:gRoomW+gWallT,normal:[0,1],
    openings:[{a:.75,b:4.3,lo:.5,hi:2.05,shade:true},{a:4.6,b:5.7,lo:0,hi:2.2,door:true},{a:6.0,b:9.95,lo:.5,hi:2.05,shade:true}]},
  left:{along:'y',inner:0,out:-1,from:0,to:gRoomD,normal:[-1,0],
    openings:[{a:2.5,b:3.62,lo:1.23,hi:2.58,blinds:true},{a:4.68,b:5.8,lo:1.23,hi:2.58,blinds:true},{a:6.84,b:7.96,lo:1.23,hi:2.58,blinds:true}]},
  right:{along:'y',inner:gRoomW,out:1,from:0,to:gRoomD,normal:[1,0],
    openings:[{a:.9,b:1.95,lo:1.15,hi:2.3,blinds:true},{a:2.75,b:3.8,lo:1.15,hi:2.3,blinds:true},{a:4.6,b:5.65,lo:1.15,hi:2.3,blinds:true}]}
};
function wallBox(pSpec,pGroup,pA0,pA1,pH0,pH1,pMats,pThickIn=0,pThickOut=gWallT){
  // Box spanning along-coordinate pA0..pA1, between inner face (+pThickIn inward) and outer face.
  const tIn=pSpec.inner-pSpec.out*pThickIn, tOut=pSpec.inner+pSpec.out*pThickOut;
  const tLo=Math.min(tIn,tOut), tHi=Math.max(tIn,tOut);
  const tMesh=pSpec.along==='x'?box(pGroup,pA0,tLo,pH0,pA1,tHi,pH1,gm('#000')):box(pGroup,tLo,pA0,pH0,tHi,pA1,pH1,gm('#000'));
  tMesh.material=pMats;
  return tMesh;
}
function wallMaterials(pSpec,pInner,pOuter,pEdge,pTop){
  // BoxGeometry material order: +x,-x,+y(top),-y,+z,-z ; game y is three z.
  if(pSpec.along==='x'){
    const tInnerPlusZ=pSpec.out<0;
    return [pEdge,pEdge,pTop,pEdge,tInnerPlusZ?pInner:pOuter,tInnerPlusZ?pOuter:pInner];
  }
  const tInnerPlusX=pSpec.out<0;
  return [tInnerPlusX?pInner:pOuter,tInnerPlusX?pOuter:pInner,pTop,pEdge,pEdge,pEdge];
}
function segmentsAround(pFrom,pTo,pOpenings,pLevel){
  // Along-wall spans that are solid at height pLevel.
  const tCuts=pOpenings.filter(pO=>pO.lo<=pLevel&&pO.hi>pLevel).sort((pA,pB)=>pA.a-pB.a);
  const tSpans=[];let tStart=pFrom;
  for(const tO of tCuts){if(tO.a>tStart)tSpans.push([tStart,tO.a]);tStart=Math.max(tStart,tO.b);}
  if(tStart<pTo)tSpans.push([tStart,pTo]);
  return tSpans;
}
function buildWall(pName,pSpec){
  const tFull=new THREE.Group(),tStub=new THREE.Group();
  const tExterior=pName==='front'?texMat(gTex.brickYellow):pName==='right'?texMat(gTex.brickOrange):texMat(gTex.stucco);
  const tInterior=gm(pName==='back'?'#e2e6cf':'#d7dec2',.92);
  const tEdge=gm('#d8c9a3',.8), tTop=gm('#eadfc2',.8);
  const tMats=wallMaterials(pSpec,tInterior,tExterior,tEdge,tTop);
  const tTrimMats=wallMaterials(pSpec,gm('#82644a'),gm('#82644a'),gm('#6a4f3a'),gm('#577669'));
  const tOpenings=pSpec.openings;
  // Full-height wall: solid columns plus pieces above and below each opening.
  const tPoints=[pSpec.from,pSpec.to];
  for(const tO of tOpenings)tPoints.push(tO.a,tO.b);
  tPoints.sort((pA,pB)=>pA-pB);
  for(let tI=0;tI<tPoints.length-1;tI++){
    const tA=tPoints[tI],tB=tPoints[tI+1];if(tB-tA<.001)continue;
    const tO=tOpenings.find(pO=>pO.a<=tA+.001&&pO.b>=tB-.001);
    if(!tO){wallBox(pSpec,tFull,tA,tB,0,gWallH,tMats);continue;}
    if(tO.lo>0)wallBox(pSpec,tFull,tA,tB,0,tO.lo,tMats);
    wallBox(pSpec,tFull,tA,tB,tO.hi,gWallH,tMats);
  }
  // Cut-down wall for the dining-room view.
  for(const [tA,tB] of segmentsAround(pSpec.from,pSpec.to,tOpenings,gStubH-.01))wallBox(pSpec,tStub,tA,tB,0,gStubH,tMats);
  // Wainscot and chair rail on the inside.
  const tInFrom=Math.max(pSpec.from,0),tInTo=Math.min(pSpec.to,pSpec.along==='x'?gRoomW:gRoomD);
  for(const [tA,tB] of segmentsAround(tInFrom,tInTo,tOpenings,.3)){
    wallBox(pSpec,tFull,tA,tB,0,.56,tTrimMats,.035,0);
    wallBox(pSpec,tFull,tA,tB,.56,.62,wallMaterials(pSpec,gm('#577669'),gm('#577669'),gm('#577669'),gm('#607d73')),.05,0);
    wallBox(pSpec,tStub,tA,tB,0,gStubH,tTrimMats,.035,0);
  }
  // Window frames, glass, blinds and shades.
  const tFrameMat=gm('#e8dcb8',.6),tGlass=new THREE.MeshStandardMaterial({color:'#bcd6de',roughness:.08,metalness:.1,transparent:true,opacity:.28,depthWrite:false});
  for(const tO of tOpenings){
    const tMid=(tO.a+tO.b)/2,tWidth=tO.b-tO.a;
    const tFrame=(pA0,pA1,pH0,pH1)=>wallBox(pSpec,tFull,pA0,pA1,pH0,pH1,tFrameMat,-gWallT*.35,gWallT*.65);
    if(tO.door){
      tFrame(tO.a,tO.a+.06,0,tO.hi);tFrame(tO.b-.06,tO.b,0,tO.hi);tFrame(tO.a,tO.b,tO.hi-.06,tO.hi);
      // An open glass door, swung inward.
      const tDoor=new THREE.Group();
      const tLeaf=tO.b-tO.a-.14;
      box(tDoor,0,-.03,0,tLeaf,.03,tO.hi-.08,gm('#c9ccc4',.4,.5));
      const tPane=box(tDoor,.07,-.035,.12,tLeaf-.07,.035,tO.hi-.2,tGlass,false);
      tPane.renderOrder=2;
      box(tDoor,tLeaf-.12,-.06,.95,tLeaf-.08,.06,1.05,gm('#d9ae67',.3,.6));
      const tHingeX=tO.a+.07,tHingeY=pSpec.inner;
      tDoor.position.set(tHingeX,0,tHingeY-.02);
      tDoor.rotation.y=Math.PI*.42;
      tFull.add(tDoor);
      // OPEN sign hanging in the window beside the door.
      decal(tFull,new THREE.MeshBasicMaterial({map:gTex.open,toneMapped:false}),tO.a-.55,pSpec.inner+.02,1.65,.5,.25,'y+');
      continue;
    }
    tFrame(tO.a,tO.b,tO.lo,tO.lo+.06);tFrame(tO.a,tO.b,tO.hi-.06,tO.hi);
    tFrame(tO.a,tO.a+.06,tO.lo,tO.hi);tFrame(tO.b-.06,tO.b,tO.lo,tO.hi);
    if(tWidth>2){tFrame(tMid-.03,tMid+.03,tO.lo,tO.hi);}
    const tGlassMesh=wallBox(pSpec,tFull,tO.a+.05,tO.b-.05,tO.lo+.05,tO.hi-.05,tGlass,-gWallT*.55,gWallT*.6);
    tGlassMesh.castShadow=false;tGlassMesh.renderOrder=2;
    if(tO.blinds){
      const tBlind=wallBox(pSpec,tFull,tO.a+.08,tO.b-.08,tO.lo+(tO.hi-tO.lo)*.45,tO.hi-.06,texMat(gTex.blinds,.9),.02,-.0);
      tBlind.castShadow=false;
    }
    if(tO.shade){
      wallBox(pSpec,tFull,tO.a+.08,tO.b-.08,tO.lo+(tO.hi-tO.lo)*.42,tO.hi-.06,gm('#ece2c6',.95),.04,-.01).castShadow=false;
      // Snake plants on the sill, like the street photo.
      for(let tX=tO.a+.35;tX<tO.b-.2;tX+=.75){
        const tPot=pSpec.along==='x'?[tX,pSpec.inner-.18]:[pSpec.inner-.18,tX];
        cyl(tFull,tPot[0],tPot[1],tO.lo,tO.lo+.14,.09,gm('#efe9dc',.6),.07);
        for(let tL=0;tL<5;tL++){
          const tLeaf=new THREE.Mesh(new THREE.ConeGeometry(.025,.32+tL%2*.08,4),gm(tL%2?'#4f7a45':'#6b9257'));
          tLeaf.position.set(tPot[0]+Math.cos(tL*1.3)*.04,tO.lo+.3,tPot[1]+Math.sin(tL*1.3)*.04);
          tLeaf.rotation.set(Math.sin(tL)*.25,0,Math.cos(tL*1.7)*.25);tLeaf.castShadow=true;tFull.add(tLeaf);
        }
      }
    }
  }
  return {full:tFull,stub:tStub};
}
function sideAwning(pGroup,pX,pY0,pY1,pTop){
  // Small awning on the right side wall, sloping out along +x.
  const tGeo=new THREE.PlaneGeometry(pY1-pY0,.62);
  const tMat=texMat(gTex.awning,.9,{side:THREE.DoubleSide});
  const tMesh=new THREE.Mesh(tGeo,tMat);
  tMesh.position.set(pX+.27,pTop-.2,(pY0+pY1)/2);
  tMesh.rotation.set(0,Math.PI/2,0);tMesh.rotateX(-Math.PI/2+.72);
  tMesh.castShadow=true;pGroup.add(tMesh);
  const tVal=new THREE.Mesh(new THREE.PlaneGeometry(pY1-pY0,.16),new THREE.MeshStandardMaterial({map:gTex.valance,side:THREE.DoubleSide,roughness:.9,alphaTest:.3}));
  tVal.position.set(pX+.55,pTop-.47,(pY0+pY1)/2);tVal.rotation.y=Math.PI/2;pGroup.add(tVal);
  for(const tY of [pY0+.02,pY1-.02])box(pGroup,pX,tY-.01,pTop-.42,pX+.55,tY+.01,pTop-.38,gm('#2a3c48'));
}
function buildBuilding(){
  const tBuilding=new THREE.Group();gScene.add(tBuilding);
  box(tBuilding,-gWallT,-gWallT,-.12,gRoomW+gWallT,gRoomD+gWallT,gFloorH-.005,gm('#8f8a7c'));
  const tKitchen=new THREE.Mesh(new THREE.PlaneGeometry(gRoomW,2.65),texMat(gTex.kitchenFloor,.7));
  tKitchen.rotation.x=-Math.PI/2;tKitchen.position.set(gRoomW/2,gFloorH,1.325);tKitchen.receiveShadow=true;
  { const tUV=tKitchen.geometry.attributes.uv;for(let tI=0;tI<tUV.count;tI++)tUV.setXY(tI,tUV.getX(tI)*gRoomW,tUV.getY(tI)*2.65); }
  tBuilding.add(tKitchen);
  const tDining=new THREE.Mesh(new THREE.PlaneGeometry(gRoomW,gRoomD-2.65),texMat(gTex.diningFloor,.75));
  tDining.rotation.x=-Math.PI/2;tDining.position.set(gRoomW/2,gFloorH,2.65+(gRoomD-2.65)/2);tDining.receiveShadow=true;
  { const tUV=tDining.geometry.attributes.uv;for(let tI=0;tI<tUV.count;tI++)tUV.setXY(tI,tUV.getX(tI)*gRoomW,tUV.getY(tI)*(gRoomD-2.65)); }
  tBuilding.add(tDining);
  for(const [tName,tSpec] of Object.entries(gWallSpecs)){
    const tWall=buildWall(tName,tSpec);
    tWall.spec=tSpec;gWalls[tName]=tWall;
    tBuilding.add(tWall.full,tWall.stub);
  }
  const tFront=gWalls.front.full, tBack=gWalls.back.full, tLeft=gWalls.left.full, tRight=gWalls.right.full;
  // Storefront: parapet, corrugated blue panel, oval sign and the scalloped awning.
  box(tFront,-gWallT,gRoomD,gWallH,gRoomW+gWallT,gRoomD+gWallT,3.78,texMat(gTex.brickYellow));
  box(tFront,-gWallT-.03,gRoomD-.02,3.78,gRoomW+gWallT+.03,gRoomD+gWallT+.03,3.84,gm('#c99a4a'));
  const tPanel=box(tFront,1.0,gRoomD+gWallT,2.25,9.7,gRoomD+gWallT+.04,3.62,texMat(gTex.corrugated,.6,{metalness:.25}));
  tPanel.material=[gm('#4f789c'),gm('#4f789c'),gm('#88aed0'),gm('#4f789c'),texMat(gTex.corrugated,.55,{metalness:.25}),gm('#4f789c')];
  decal(tFront,new THREE.MeshStandardMaterial({map:gTex.signOval,transparent:true,roughness:.6}),gDoorX,gRoomD+gWallT+.05,3.0,2.5,.78,'y+');
  for(const tX of [2.6,7.7]){box(tFront,tX-.02,gRoomD+gWallT,2.95,tX+.02,gRoomD+gWallT+.9,3.0,gm('#3a3d3c',.5,.4));}
  const tAwningW=gRoomW-.9;
  const tAwning=new THREE.Mesh(new THREE.PlaneGeometry(tAwningW,.86),texMat(gTex.awning,.9,{side:THREE.DoubleSide}));
  { const tUV=tAwning.geometry.attributes.uv;for(let tI=0;tI<tUV.count;tI++)tUV.setX(tI,tUV.getX(tI)*tAwningW); }
  tAwning.position.set(gRoomW/2,2.2,gRoomD+gWallT+.39);tAwning.rotation.x=-Math.PI/2+.42;tAwning.castShadow=true;tFront.add(tAwning);
  const tValance=new THREE.Mesh(new THREE.PlaneGeometry(tAwningW,.26),new THREE.MeshStandardMaterial({map:gTex.valance.clone(),side:THREE.DoubleSide,roughness:.9,alphaTest:.3}));
  tValance.material.map.repeat.set(tAwningW/1.1,1);tValance.material.map.needsUpdate=true;
  { const tUV=tValance.geometry.attributes.uv;for(let tI=0;tI<tUV.count;tI++)tUV.setX(tI,tUV.getX(tI)); }
  tValance.position.set(gRoomW/2,1.93,gRoomD+gWallT+.78);tValance.castShadow=true;tFront.add(tValance);
  for(const tX of [.46,gRoomW-.46]){box(tFront,tX-.015,gRoomD+gWallT,2.44,tX+.015,gRoomD+gWallT+.78,2.48,gm('#2a3c48'));}
  // Side wall: the mural, three window awnings and a utility box.
  decal(tRight,new THREE.MeshStandardMaterial({map:gTex.mural,transparent:true,alphaTest:.1,roughness:.9}),gRoomW+gWallT+.012,7.05,1.75,1.45,2.2,'x+');
  for(const tO of gWallSpecs.right.openings)sideAwning(tRight,gRoomW+gWallT,tO.a-.08,tO.b+.08,2.62);
  box(tRight,gRoomW+gWallT,5.95,1.15,gRoomW+gWallT+.12,6.2,1.45,gm('#8e958f',.5,.4));
  // Back wall: kitchen backsplash, hood, shelves, pots, menu board and restroom sign.
  box(tBack,3.42,0,.6,6.44,.03,1.9,texMat(gTex.tile,.4));
  box(tBack,3.42,0,1.92,6.52,.95,2.14,gm('#a9b0a6',.35,.55));
  box(tBack,3.6,.15,2.14,4.2,.75,gWallH,gm('#9aa29a',.35,.55));
  for(const tZ of [1.02,1.62]){
    box(tBack,1.49,0,tZ,3.14,.48,tZ+.06,texMat(gTex.wood));
    for(const tX of [1.8,2.6])for(let tI=0;tI<4;tI++)cyl(tBack,tX,.26,tZ+.06+tI*.03,tZ+.085+tI*.03,.17,gm(tI%2?'#ddd3b3':'#faf0d4',.5));
  }
  box(tBack,1.55,.06,2.27,3.05,.1,2.31,gm('#526e64',.4,.5));
  for(const [tX,tR,tDrop] of [[1.72,.16,.3],[2.14,.13,.36],[2.64,.18,.26]]){
    box(tBack,tX-.01,.07,2.27-tDrop,tX+.01,.09,2.27,gm('#4c615a',.4,.5));
    cyl(tBack,tX,.12,2.27-tDrop-.2,2.27-tDrop,tR,gm('#5d726b',.35,.6),tR*.9);
  }
  decal(tBack,new THREE.MeshStandardMaterial({map:gTex.menuBoard,roughness:.9}),7.32,.025,2.27,1.33,1.0,'y+');
  decal(tBack,new THREE.MeshStandardMaterial({map:gTex.restroom,roughness:.9}),10.0,.025,1.92,1.08,.84,'y+');
  decal(tLeft,new THREE.MeshStandardMaterial({map:gTex.artPoster,roughness:.85}),.025,4.15,1.72,.98,1.04,'x+');
  decal(tLeft,new THREE.MeshStandardMaterial({map:gTex.artSarah,roughness:.85}),.025,6.32,1.78,.86,1.13,'x+');
  // Roof (hidden in the dining-room view).
  gRoofGroup=new THREE.Group();tBuilding.add(gRoofGroup);
  box(gRoofGroup,-gWallT,-gWallT,gWallH,gRoomW+gWallT,gRoomD,gWallH+.1,gm('#6b655d',.95));
  const tTiles=new THREE.Mesh(new THREE.PlaneGeometry(gRoomD+gWallT,1.15),texMat(gTex.roofTile,.85,{side:THREE.DoubleSide}));
  { const tUV=tTiles.geometry.attributes.uv;for(let tI=0;tI<tUV.count;tI++)tUV.setXY(tI,tUV.getX(tI)*(gRoomD+gWallT)*.9,tUV.getY(tI)*1.15*1.6); }
  tTiles.rotation.set(0,Math.PI/2,0);tTiles.rotateX(-Math.PI/2+.42);
  tTiles.position.set(gRoomW-.2,gWallH+.26,(gRoomD-gWallT)/2);tTiles.castShadow=true;gRoofGroup.add(tTiles);
  for(const [tX,tY,tH] of [[6.0,1.0,3.8],[6.35,1.05,3.65],[3.9,.5,3.5]])cyl(gRoofGroup,tX,tY,gWallH,tH,.11,gm('#b7bab4',.4,.6));
  box(gRoofGroup,7.6,.4,gWallH+.1,8.8,1.3,gWallH+.75,gm('#c7c9c2',.5,.4));
  box(gRoofGroup,8.6,6,gWallH,9.6,6.9,gWallH+.55,gm('#aeb3ad',.5,.4));
}
function buildInterior(){
  const tGroup=new THREE.Group();gScene.add(tGroup);
  const tSteel=gm('#8a948e',.35,.55),tDark=gm('#3b4945',.6,.3);
  // Range and griddle where Sally and Bart share a station.
  box(tGroup,3.52,.27,0,6.4,1.05,.6,tSteel);
  box(tGroup,3.65,1.05,.1,6.24,1.07,.45,tDark);
  box(tGroup,3.62,.38,.6,4.95,.98,.63,gm('#4a524b',.5,.3));
  gCookGlow=box(tGroup,3.66,.42,.632,4.9,.94,.636,new THREE.MeshStandardMaterial({color:'#5a3a2a',emissive:'#ff7a2a',emissiveIntensity:0,roughness:.6}),false);
  for(const [tX,tY] of [[5.11,.5],[5.72,.5],[5.11,.86],[5.72,.86]]){
    cyl(tGroup,tX,tY,.6,.63,.15,tDark);cyl(tGroup,tX,tY,.63,.645,.08,gm('#6d766b',.4,.5));
  }
  for(let tX=3.85;tX<6.2;tX+=.45)cyl(tGroup,tX,1.09,.52,.56,.035,gm('#d1ba89',.4,.5)).rotation.x=Math.PI/2;
  gCookPan=new THREE.Group();tGroup.add(gCookPan);
  cyl(gCookPan,5.49,.72,.645,.7,.17,gm('#343c36',.4,.5),.15);
  cyl(gCookPan,5.49,.72,.7,.72,.12,gm('#d38a49',.7));
  box(gCookPan,5.62,.68,.68,5.98,.76,.7,gm('#3f4541',.4,.5));
  for(let tI=0;tI<3;tI++)cyl(gCookPan,4.1+tI*.28,.66,.636,.66,.11,gm(tI===1?'#f6efd6':'#c98d47',.7));
  gCookPan.visible=false;
  // Back prep counter with coffee maker, and the refrigerator.
  box(tGroup,1.3,.05,0,3.3,.75,.62,tSteel);
  box(tGroup,1.82,.15,.62,2.22,.5,1.02,gm('#526769',.5,.3));
  box(tGroup,1.86,.5,.62,2.18,.52,.95,gm('#b3b5a2',.4,.4));
  cyl(tGroup,2.02,.6,.62,.8,.06,gm('#403e36',.3,.2));
  box(tGroup,7.28,.26,0,8.12,1.17,1.53,gm('#e0dfc3',.45));
  box(tGroup,7.32,1.17,.05,8.08,1.18,1.49,gm('#c9d0b8',.45));
  box(tGroup,7.32,1.18,.95,8.08,1.19,.98,gm('#788f81',.45));
  box(tGroup,7.42,1.19,1.05,7.48,1.24,1.32,gm('#657c72',.3,.5));
  box(tGroup,7.42,1.19,.52,7.48,1.24,.83,gm('#657c72',.3,.5));
  // Hanging kitchen pendants.
  for(const tX of [.6,4.27,9.47]){
    box(tGroup,tX-.01,1.44,2.05,tX+.01,1.46,gWallH,gm('#617569'),false);
    const tShade=new THREE.Mesh(new THREE.ConeGeometry(.17,.14,18,1,true),new THREE.MeshStandardMaterial({color:'#a29468',side:THREE.DoubleSide,roughness:.5}));
    tShade.position.set(tX,2.0,1.45);tGroup.add(tShade);
    const tBulb=new THREE.Mesh(new THREE.SphereGeometry(.06,12,8),new THREE.MeshStandardMaterial({color:'#fff5d3',emissive:'#ffe7a8',emissiveIntensity:1.4}));
    tBulb.position.set(tX,1.93,1.45);tGroup.add(tBulb);
  }
  // Lunch counter in eight sections with the register on the end.
  for(let tI=0;tI<8;tI++){
    const tX=.85+tI*1.08;
    const tBase=box(tGroup,tX,2.03,0,tX+1.08,2.94,.58,gm('#75694d'));
    tBase.material=[gm('#665e46'),gm('#665e46'),gm('#665e46'),gm('#665e46'),gm(tI%2?'#477c6c':'#538574',.7),gm('#75694d')];
    box(tGroup,tX+.01,2.94,.48,tX+1.07,2.96,.52,gm('#bba97c',.4,.4));
    box(tGroup,tX,1.98,.58,tX+1.08,3.0,.64,gm('#eee1bc',.35));
    box(tGroup,tX,3.0,.585,tX+1.08,3.012,.635,gm('#c9cbc4',.25,.8));
    if(tI===7){
      box(tGroup,tX+.22,2.27,.64,tX+.95,2.82,.82,gm('#aeaa94',.4,.4));
      box(tGroup,tX+.27,2.29,.82,tX+.91,2.55,1.0,gm('#858d80',.4,.4));
      box(tGroup,tX+.37,2.55,.86,tX+.8,2.56,.95,gm('#213e38'));
      box(tGroup,tX+.42,2.56,.88,tX+.72,2.565,.93,new THREE.MeshStandardMaterial({color:'#b1c77c',emissive:'#7f9a4c',emissiveIntensity:.6}));
      for(let tK=0;tK<5;tK++)box(tGroup,tX+.29+tK*.115,2.6,.82,tX+.355+tK*.115,2.78,.84,gm(tK===4?'#c47746':'#ded3ad'));
      gRegisterPlaque=textSprite('Register','#244551',.24);gRegisterPlaque.position.set(tX+.62,1.32,2.52);gScene.add(gRegisterPlaque);
    }
  }
  for(const [tX,tY] of [[1.32,2.48],[4.32,2.45],[6.18,2.5]])for(let tI=0;tI<4;tI++)cyl(tGroup,tX,tY,.64+tI*.025,.66+tI*.025,.15,gm(tI===3?'#f4eedb':'#e8e1cc',.4));
  // Counter stools.
  tablePositions.forEach(([tX,tY],tIndex)=>{
    if(!isCounter(tIndex))return;
    cyl(tGroup,tX,tY,0,.03,.18,gm('#9ea3a0',.3,.7));
    cyl(tGroup,tX,tY,.03,.31,.035,gm('#b9bdb9',.25,.8));
    cyl(tGroup,tX,tY,.31,.37,.19,gm('#8f5148',.6),.17);
    gTableProps[tIndex]={food:null,dirty:null};
  });
  // Dining tables with gingham tops and four chairs each.
  tablePositions.forEach(([tX,tY],tIndex)=>{
    if(isCounter(tIndex))return;
    cyl(tGroup,tX,tY,0,.03,.24,gm('#5d4938',.6));
    cyl(tGroup,tX,tY,.03,.4,.06,gm('#694c39',.6));
    const tTop=box(tGroup,tX-.51,tY-.455,.4,tX+.51,tY+.455,.47,gm('#507754'));
    tTop.material=[gm('#41674d'),gm('#41674d'),texMat(gTex.gingham,.7),gm('#41674d'),gm('#507754'),gm('#41674d')];
    box(tGroup,tX-.04,tY-.02,.47,tX+.04,tY+.06,.55,gm('#d6d8d2',.3,.6));
    cyl(tGroup,tX+.12,tY+.02,.47,.6,.025,gm('#b2392c',.5));
    const tFood=new THREE.Group(),tDirty=new THREE.Group();
    for(const tDX of [-.27,.24]){
      cyl(tGroup,tX+tDX,tY,.47,.485,.13,gm('#f4ead0',.35),.11);
      cyl(tFood,tX+tDX,tY+.02,.485,.52,.06,gm('#c28551',.7));
      const tEgg=cyl(tFood,tX+tDX-.06,tY-.05,.485,.495,.045,gm('#fbf7ee',.5));tEgg.scale.z=.8;
      const tYolk=new THREE.Mesh(new THREE.SphereGeometry(.02,10,8),gm('#f0b52c',.4));tYolk.position.set(tX+tDX-.06,.5,tY-.05);tFood.add(tYolk);
      cyl(tDirty,tX+tDX+.02,tY+.01,.485,.495,.05,gm('#b69063',.8));
      const tNapkin=new THREE.Mesh(new THREE.IcosahedronGeometry(.045,0),gm('#f5f1e6',.9));tNapkin.position.set(tX+tDX-.05,.51,tY-.06);tDirty.add(tNapkin);
    }
    tGroup.add(tFood,tDirty);tFood.visible=tDirty.visible=false;
    gTableProps[tIndex]={food:tFood,dirty:tDirty};
    for(const [tDX,tDY] of gChairOffsets)buildChair(tGroup,tX+tDX,tY+tDY,tX,tY);
  });
}
const gChairOffsets=[[-.3,-.72],[.32,.72],[-.78,.1],[.78,-.1]];
function buildChair(pParent,pX,pY,pTableX,pTableY){
  const tChair=new THREE.Group();
  const tWood=gm('#4e3931',.7),tSeat=gm('#88654e',.7);
  for(const tDX of [-.17,.17])for(const tDZ of [-.16,.16])box(tChair,tDX-.025,tDZ-.025,0,tDX+.025,tDZ+.025,.23,tWood);
  box(tChair,-.21,-.2,.22,.21,.2,.27,tSeat);
  for(const tDX of [-.17,.17])box(tChair,tDX-.025,-.2,.27,tDX+.025,-.15,.62,tWood);
  box(tChair,-.21,-.21,.5,.21,-.15,.62,gm('#8a614b',.7));
  tChair.position.set(pX,0,pY);
  tChair.rotation.y=Math.atan2(pTableX-pX,pTableY-pY);
  pParent.add(tChair);
}
const gFlatCache=new Map();
function flatMat(pColor){if(!gFlatCache.has(pColor))gFlatCache.set(pColor,new THREE.MeshStandardMaterial({color:pColor,roughness:.95,flatShading:true}));return gFlatCache.get(pColor);}
function tree(pX,pY,pSize=1){
  const tGroup=new THREE.Group();gScene.add(tGroup);
  cyl(tGroup,pX,pY,0,2.2*pSize,.13*pSize,gm('#6f5b42',.9),.17*pSize);
  const tGreens=['#49614a','#657c4b','#789352','#8fa459','#5a7448'];
  for(let tI=0;tI<9;tI++){
    const tLeaf=new THREE.Mesh(new THREE.IcosahedronGeometry((.75+(tI%3)*.22)*pSize,1),flatMat(tGreens[tI%5]));
    const tA=tI*2.4;
    tLeaf.position.set(pX+Math.cos(tA)*.7*pSize,(2.6+(tI%4)*.42)*pSize,pY+Math.sin(tA)*.7*pSize);
    tLeaf.castShadow=tLeaf.receiveShadow=true;tGroup.add(tLeaf);
  }
  // Mardi Gras beads stay snagged in the branches all year, as along St. Charles Avenue.
  const tBeadColors=['#7a2fa0','#2f9a4f','#e6b830','#c9c9c9','#7a2fa0','#e6b830'];
  for(let tI=0;tI<9;tI++){
    const tA=tI*1.9+pX,tR=(.9+(tI%3)*.35)*pSize;
    const tTop=new THREE.Vector3(pX+Math.cos(tA)*tR,(2.55+(tI%3)*.35)*pSize,pY+Math.sin(tA)*tR);
    const tSpan=.5+(tI%2)*.3;
    const tEnd=tTop.clone().add(new THREE.Vector3(Math.cos(tA+1.6)*tSpan,-.05,Math.sin(tA+1.6)*tSpan));
    const tMid=tTop.clone().lerp(tEnd,.5);tMid.y-=.55+(tI%3)*.2;
    const tCurve=new THREE.CatmullRomCurve3([tTop,tTop.clone().lerp(tMid,.55).setY(tMid.y+.12),tMid,tEnd.clone().lerp(tMid,.55).setY(tMid.y+.12),tEnd]);
    const tBead=new THREE.Mesh(new THREE.TubeGeometry(tCurve,24,.028,6,false),gm(tBeadColors[tI%tBeadColors.length],.25,.55));
    tBead.castShadow=true;tGroup.add(tBead);
  }
}
function hipRoof(pParent,pX0,pY0,pX1,pY1,pH0,pH1,pInset,pMat){
  const tMy=(pY0+pY1)/2;
  const tA=W3(pX0,pY0,pH0),tB=W3(pX1,pY0,pH0),tC=W3(pX1,pY1,pH0),tD=W3(pX0,pY1,pH0);
  const tR0=W3(pX0+pInset,tMy,pH1),tR1=W3(pX1-pInset,tMy,pH1);
  const tTris=[[tD,tC,tR1],[tD,tR1,tR0],[tB,tA,tR0],[tB,tR0,tR1],[tC,tB,tR1],[tA,tD,tR0]];
  const tPos=[],tUV=[];
  for(const tTri of tTris)for(const tP of tTri){tPos.push(tP.x,tP.y,tP.z);tUV.push(tP.x*.8,(tP.y+tP.z)*.8);}
  const tGeo=new THREE.BufferGeometry();
  tGeo.setAttribute('position',new THREE.Float32BufferAttribute(tPos,3));
  tGeo.setAttribute('uv',new THREE.Float32BufferAttribute(tUV,2));
  tGeo.computeVertexNormals();
  const tMesh=new THREE.Mesh(tGeo,pMat);tMesh.castShadow=tMesh.receiveShadow=true;pParent.add(tMesh);
  return tMesh;
}
function buildNeighborhood(){
  const tGroup=new THREE.Group();gScene.add(tGroup);
  // Ground, sidewalk, curb, street.
  const tGround=new THREE.Mesh(new THREE.PlaneGeometry(80,60),texMat(gTex.grass,1));
  tGround.rotation.x=-Math.PI/2;tGround.position.set(6,-.01,-21.55);tGround.receiveShadow=true;
  { const tUV=tGround.geometry.attributes.uv;for(let tI=0;tI<tUV.count;tI++)tUV.setXY(tI,tUV.getX(tI)*80,tUV.getY(tI)*60); }
  tGroup.add(tGround);
  const tWalk=box(tGroup,-34,gRoomD,-.2,46,11.2,0,texMat(gTex.sidewalk,.95));
  box(tGroup,-34,11.2,-.2,46,11.38,0,gm('#bdb6a5',.9));
  const tStreet=box(tGroup,-34,11.38,-.6,46,16.6,-.15,texMat(gTex.asphalt,.95));
  for(let tX=-30;tX<44;tX+=3.2)box(tGroup,tX,13.92,-.15,tX+1.6,14.04,-.145,gm('#d8c27a',.8),false);
  box(tGroup,-34,16.6,-.6,46,18.6,0,texMat(gTex.sidewalk,.95));
  const tFar=new THREE.Mesh(new THREE.PlaneGeometry(80,30),texMat(gTex.grass.clone(),1));
  tFar.material.map.repeat.set(.2,.2);tFar.material.map.needsUpdate=true;
  { const tUV=tFar.geometry.attributes.uv;for(let tI=0;tI<tUV.count;tI++)tUV.setXY(tI,tUV.getX(tI)*80,tUV.getY(tI)*30); }
  tFar.rotation.x=-Math.PI/2;tFar.position.set(6,-.01,33.6);tGroup.add(tFar);
  // White clapboard neighbor and its green gate.
  const tClap=texMat(gTex.clapboard,.9);
  box(tGroup,-7.4,1.6,0,-.6,8.2,2.7,tClap);
  box(tGroup,-7.55,1.45,2.7,-.45,8.35,2.82,gm('#8a8b88',.95));box(tGroup,-7.6,8.3,2.6,-.4,8.4,2.95,gm('#e9e7df',.9));
  for(const tX of [-6.2,-3.6]){box(tGroup,tX,8.2,.95,tX+1.5,8.23,1.75,gm('#33464b',.4));for(let tB=tX+.1;tB<tX+1.5;tB+=.18)box(tGroup,tB,8.23,.95,tB+.03,8.25,1.75,gm('#1d2224',.4,.5));}
  box(tGroup,-2.1,8.2,0,-1.2,8.24,2.0,gm('#4f6b5a',.7));
  box(tGroup,-.6,8.0,0,-.2,8.35,2.1,texMat(gTex.fence));
  // Two-story house with dormers behind.
  box(tGroup,-5,-9.5,0,4.5,-2.2,5.2,tClap);
  box(tGroup,-5.08,-2.22,2.55,4.58,-2.12,2.7,gm('#3f6b55',.7));
  for(const tX of [-3.8,-1.2,1.4]){box(tGroup,tX,-2.2,3.1,tX+.9,-2.16,4.5,gm('#33464b',.4));box(tGroup,tX-.08,-2.18,3.02,tX+.98,-2.13,4.58,gm('#3f6b55',.7)).scale.z=.4;}
  hipRoof(tGroup,-5.5,-10,5,-1.7,5.2,7.6,2.4,texMat(gTex.shingle,.95,{side:THREE.DoubleSide}));
  for(const tX of [-2.6,1.0]){
    box(tGroup,tX,-3.9,5.6,tX+1.4,-2.8,6.8,tClap);
    box(tGroup,tX+.25,-2.79,5.85,tX+1.15,-2.76,6.55,gm('#2d3c40',.4));
    hipRoof(tGroup,tX-.15,-4.0,tX+1.55,-2.65,6.8,7.25,.7,texMat(gTex.shingle,.95,{side:THREE.DoubleSide}));
  }
  box(tGroup,8,-9,0,16,-3,3.6,gm('#a8673f',.9));
  box(tGroup,7.9,-9.1,3.6,16.1,-2.9,3.75,gm('#6b655d'));
  // Side lot: wood privacy fence and iron fence along the sidewalk.
  box(tGroup,17.6,-1,0,17.72,8.3,1.9,texMat(gTex.fence));box(tGroup,10.95,-1.12,0,17.72,-1,1.9,texMat(gTex.fence));
  box(tGroup,11.2,8.32,1.25,18.5,8.36,1.3,gm('#1d2224',.4,.5));
  box(tGroup,11.2,8.32,.08,18.5,8.36,.12,gm('#1d2224',.4,.5));
  for(let tX=11.2;tX<18.5;tX+=.16)box(tGroup,tX,8.32,0,tX+.025,8.36,1.36,gm('#1d2224',.4,.5));
  cyl(tGroup,11.6,7.6,0,.95,.3,gm('#2b2f2e',.6),.27);
  // Newspaper boxes and a parking meter, as in the photo.
  const tPaper=[['#f2f2f0','#2c5aa0'],['#b52a24','#b52a24'],['#d92f2a','#d92f2a'],['#6f8584','#5b6e6d']];
  tPaper.forEach(([tBody,tTop],tI)=>{
    const tX=12.2+tI*.72;
    box(tGroup,tX,8.55,.2,tX+.52,9.0,1.15,gm(tBody,.5,.2));
    box(tGroup,tX+.06,9.0,.65,tX+.46,9.02,1.0,gm('#cfd9d6',.2,.1));
    box(tGroup,tX-.02,8.53,1.15,tX+.54,9.02,1.22,gm(tTop,.5,.2));
    box(tGroup,tX+.2,8.7,0,tX+.32,8.85,.2,gm('#333',.5,.4));
  });
  cyl(tGroup,11.3,10.85,0,1.0,.035,gm('#555b5a',.4,.6));
  box(tGroup,11.18,10.76,1.0,11.42,10.94,1.3,gm('#3f4544',.4,.6));
  // A parked turquoise sedan.
  const tCar=new THREE.Group();tGroup.add(tCar);
  box(tCar,-4.2,11.9,.05,.4,13.4,.72,gm('#4aa3a0',.35,.3));
  box(tCar,-3.1,12.0,.72,-.7,13.3,1.3,gm('#4aa3a0',.35,.3));
  box(tCar,-3.0,11.98,.78,-.8,13.32,1.24,gm('#2c3d48',.15,.2));
  box(tCar,-4.25,12.0,.25,-4.15,13.3,.4,gm('#d9dcd6',.2,.8));box(tCar,.35,12.0,.25,.45,13.3,.4,gm('#d9dcd6',.2,.8));
  for(const tX of [-3.3,-.5])for(const tY of [11.9,13.4]){const tW=cyl(tCar,tX,tY,0,.15,.32,gm('#1b1b1c',.8));tW.rotation.x=Math.PI/2;tW.position.y=.3;}
  // Utility poles and drooping power lines across the scene.
  gOverhead=new THREE.Group();gScene.add(gOverhead);
  for(const tX of [-5.2,20]){
    cyl(gOverhead,tX,11.0,0,8.2,.13,gm('#6a5440',.9),.16);
    box(gOverhead,tX-1.1,10.94,7.6,tX+1.1,11.06,7.75,gm('#6a5440',.9));
  }
  const tWire=new THREE.LineBasicMaterial({color:'#1f2326'});
  for(const [tDX,tH,tSag] of [[-1,7.75,1.2],[0,7.75,1.4],[1,7.75,1.1],[0,8.2,.9]]){
    const tPts=[];
    for(let tI=0;tI<=40;tI++){const tT=tI/40;const tX=-5.2+tDX*.9+(25.2)*tT;tPts.push(new THREE.Vector3(tX,tH-tSag*4*tT*(1-tT),11.0+tDX*.02));}
    gOverhead.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(tPts),tWire));
  }
  { const tPts=[];for(let tI=0;tI<=20;tI++){const tT=tI/20;tPts.push(new THREE.Vector3(20-9.1*tT,7.75-1.9*tT-1.2*tT*(1-tT),11.0-2.6*tT));}
    gOverhead.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(tPts),tWire)); }
  buildNolaFlair(tGroup);
  tree(-3.2,-.9,1.1);tree(-9.4,3.2,1.25);tree(15.2,1.2,1.05);tree(19.5,-1.5,1.25);tree(-12,9.9,.9);tree(23,9.9,.95);
}

// ----- Actors (pre-rendered standees) -----
let gAtlasReady=false,gAtlasMaterials=[],gAtlasPromise=null;
let gBlobGeometry,gBlobMaterial;
function buildAtlases(){
  gAtlasRows=gDesigns.map(pDesign=>figureRows(pDesign).length);
  gBlobGeometry=new THREE.CircleGeometry(.2,20);
  gBlobMaterial=new THREE.MeshBasicMaterial({color:'#1a2a30',transparent:true,opacity:.28,depthWrite:false});
  const tLoading=$('loading');
  gAtlasPromise=renderCharacterAtlases(pFraction=>{if(tLoading)tLoading.textContent='Dressing the crew… '+Math.round(pFraction*100)+'%';}).then(pCanvases=>{
    gAtlasTextures=pCanvases.map(pCanvas=>{
      const tTex=new THREE.CanvasTexture(pCanvas);
      tTex.colorSpace=THREE.SRGBColorSpace;tTex.anisotropy=4;
      tTex.minFilter=THREE.LinearMipmapLinearFilter;
      return tTex;
    });
    // One shared material per character design keeps state changes down.
    gAtlasMaterials=gAtlasTextures.map(pTex=>new THREE.MeshBasicMaterial({map:pTex,alphaTest:.42,side:THREE.DoubleSide,toneMapped:false}));
    gAtlasReady=true;
    if(tLoading)tLoading.hidden=true;
  });
  return gAtlasPromise;
}
const gStandeeHeight=gSpriteView.height/Math.cos(gSpriteView.elevation);
function makeActor(pKey,pDesign,pX,pY){
  const tGeo=new THREE.PlaneGeometry(gSpriteView.width,gStandeeHeight);
  const tMesh=new THREE.Mesh(tGeo,gAtlasMaterials[pDesign]);
  const tShadow=new THREE.Mesh(gBlobGeometry,gBlobMaterial);
  tShadow.rotation.x=-Math.PI/2;tShadow.scale.set(1.15,.8,1);tShadow.renderOrder=1;
  gScene.add(tMesh,tShadow);
  const tActor={key:pKey,design:pDesign,mesh:tMesh,shadow:tShadow,x:pX,y:pY,facing:0,path:[],speed:3.2,pose:'stand',carry:null,walkClock:Math.random(),moving:false,used:true,goal:'',plaque:null,bubble:null,bubbleKind:null,delay:0,leaving:false,sitting:false};
  gActors.set(pKey,tActor);
  return tActor;
}
function disposeActor(pActor){
  gScene.remove(pActor.mesh,pActor.shadow);
  pActor.mesh.geometry.dispose();
  if(pActor.plaque){gScene.remove(pActor.plaque);pActor.plaque.material.map.dispose();pActor.plaque.material.dispose();}
  if(pActor.bubble){gScene.remove(pActor.bubble);pActor.bubble.material.dispose();}
  gActors.delete(pActor.key);
}
function setPlaque(pActor,pText,pColor){
  if(pActor.plaqueText===pText)return;
  if(pActor.plaque){gScene.remove(pActor.plaque);pActor.plaque.material.map.dispose();}
  pActor.plaque=pText?textSprite(pText,pColor,.24):null;
  pActor.plaqueText=pText;
  if(pActor.plaque)gScene.add(pActor.plaque);
}
function setBubble(pActor,pKind){
  if(pActor.bubbleKind===pKind)return;
  if(pActor.bubble){gScene.remove(pActor.bubble);pActor.bubble.material.dispose();pActor.bubble=null;}
  pActor.bubbleKind=pKind;
  if(pKind){pActor.bubble=makeBubble(pKind);gScene.add(pActor.bubble);}
}
function useActor(pKey,pDesign,pX,pY){
  const tActor=gActors.get(pKey)||makeActor(pKey,pDesign,pX,pY);
  tActor.used=true;
  return tActor;
}
function facingToward(pFromX,pFromY,pToX,pToY){return Math.atan2(pToX-pFromX,pToY-pFromY);}
function stepActor(pActor,pDt){
  if(pActor.delay>0){pActor.delay-=pDt;pActor.mesh.visible=pActor.shadow.visible=false;return;}
  pActor.mesh.visible=pActor.shadow.visible=true;
  pActor.moving=false;
  let tBudget=pActor.speed*pDt;
  while(pActor.path.length&&tBudget>0){
    const [tX,tY]=pActor.path[0];
    const tDX=tX-pActor.x,tDY=tY-pActor.y,tDist=Math.hypot(tDX,tDY);
    if(tDist<1e-4){pActor.path.shift();continue;}
    pActor.facing=Math.atan2(tDX,tDY);
    pActor.moving=true;
    if(tDist<=tBudget){pActor.x=tX;pActor.y=tY;tBudget-=tDist;pActor.path.shift();}
    else{pActor.x+=tDX/tDist*tBudget;pActor.y+=tDY/tDist*tBudget;tBudget=0;}
  }
}
function drawActor(pActor,pDt){
  if(pActor.delay>0)return;
  let tPose=pActor.sitting&&!pActor.path.length?'sit':'stand';
  if(pActor.moving||pActor.forceWalk){
    pActor.walkClock+=pDt;
    const tPhase=Math.floor(pActor.walkClock*8)%4;
    tPose=['walk1','stand','walk2','stand'][tPhase];
  }else if(pActor.working&&gDesigns[pActor.design].cook){
    pActor.walkClock+=pDt;
    tPose=Math.floor(pActor.walkClock*3.2)%2?'cook2':'cook1';
  }
  const tStep=Math.PI*2/gDirections;
  let tRel=pActor.facing-gCam.az;
  let tDir=Math.round(tRel/tStep)%gDirections;if(tDir<0)tDir+=gDirections;
  const tDesign=gDesigns[pActor.design];
  const tRow=frameRow(tDesign,tPose,tPose==='sit'||tPose.startsWith('cook')?null:pActor.carry);
  const tRows=gAtlasRows[pActor.design];
  const tU0=tDir/gDirections,tU1=(tDir+1)/gDirections,tV1=1-tRow/tRows,tV0=1-(tRow+1)/tRows;
  const tUV=pActor.mesh.geometry.attributes.uv;
  if(tUV.getX(0)!==tU0||tUV.getY(0)!==tV1){
    tUV.setXY(0,tU0,tV1);tUV.setXY(1,tU1,tV1);tUV.setXY(2,tU0,tV0);tUV.setXY(3,tU1,tV0);tUV.needsUpdate=true;
  }
  const tEl=gSpriteView.elevation;
  const tToward=new THREE.Vector3(Math.sin(gCam.az)*Math.cos(tEl),Math.sin(tEl),Math.cos(gCam.az)*Math.cos(tEl));
  const tShift=tPose==='sit'?.06:.3;
  pActor.mesh.position.set(pActor.x,gSpriteView.center+.01,pActor.y).addScaledVector(tToward,tShift);
  pActor.mesh.rotation.y=gCam.az;
  pActor.shadow.position.set(pActor.x,.035,pActor.y);
  pActor.shadow.visible=tPose!=='sit';
  const tHead=tPose==='sit'?1.18:1.52;
  if(pActor.plaque)pActor.plaque.position.set(pActor.x,tHead+.05,pActor.y);
  if(pActor.bubble){pActor.bubble.position.set(pActor.x,tHead+(pActor.plaque?.3:.02),pActor.y);}
}
const gAisleY=5.45, gDoorInside=[gDoorX,8.0], gDoorOutside=[gDoorX,9.35];
function seatSpot(pIndex,pSeat){
  const [tX,tY]=tablePositions[pIndex];
  if(isCounter(pIndex))return [tX,tY];
  return [tX+gChairOffsets[pSeat][0],tY+gChairOffsets[pSeat][1]];
}
function routeToSeat(pFromX,pFromY,pIndex,pSeat){
  const [tSX,tSY]=seatSpot(pIndex,pSeat);
  const tPath=[];
  if(pFromY>gRoomD-.3){tPath.push([gDoorX,Math.max(pFromY,9.2)],gDoorOutside,gDoorInside);}
  tPath.push([gDoorX,gAisleY]);
  const tLane=isCounter(pIndex)?tSX:tSX+(tSX>tablePositions[pIndex][0]?.2:-.2);
  tPath.push([tLane,gAisleY]);
  if(isCounter(pIndex))tPath.push([tSX,4.0]);
  tPath.push([tSX,tSY]);
  return tPath;
}
function queueSpot(pIndex){return [5.95+pIndex*.62,9.78];}
function syncActors(pDt){
  if(!gAtlasReady)return;
  for(const tActor of gActors.values())tActor.used=false;
  // Staff, positioned by the game logic.
  staff.forEach((pWorker,pIndex)=>{
    const tActor=useActor('staff'+pIndex,pIndex,pWorker.x,pWorker.y);
    const tDX=pWorker.x-tActor.x,tDY=pWorker.y-tActor.y;
    const tMoved=Math.hypot(tDX,tDY);
    if(tMoved>.004)tActor.facing=Math.atan2(tDX,tDY);
    else if(pIndex<2&&pWorker.atStation&&pWorker.station)tActor.facing=pWorker.stationFacing;
    else if(!pWorker.job||pWorker.job.kind==='cook'){
      tActor.facing=pIndex<2?Math.PI:pIndex===2?Math.PI*.6:-Math.PI*.6;
    }else if(pWorker.job&&pWorker.job.index!==undefined&&pWorker.job.kind!=='pay'){
      const [tTX,tTY]=tablePositions[pWorker.job.index];
      tActor.facing=isCounter(pWorker.job.index)?0:facingToward(pWorker.x,pWorker.y,tTX,tTY);
    }else if(pWorker.job&&pWorker.job.kind==='pay')tActor.facing=0;
    tActor.x=pWorker.x;tActor.y=pWorker.y;
    tActor.moving=false;
    tActor.forceWalk=tMoved>.004&&pDt>0;
    tActor.working=!!pWorker.working&&!tActor.forceWalk;
    tActor.carry=carryFor(pWorker.job);
    setPlaque(tActor,pWorker.name,pIndex<2?'#824c38':'#285749');
    setBubble(tActor,pWorker.job?.kind==='break'?'coffee':pWorker.energy<30?'zzz':null);
  });
  if(shift.inspector){
    const tElapsed=shift.time-shift.inspector.arrived;
    const [tX,tY]=inspectorPosition(tElapsed);
    const tActor=useActor('inspector',5,tX,tY);
    const tDX=tX-tActor.x,tDY=tY-tActor.y;
    if(Math.hypot(tDX,tDY)>.003)tActor.facing=Math.atan2(tDX,tDY);
    tActor.forceWalk=Math.hypot(tDX,tDY)>.003;
    tActor.x=tX;tActor.y=tY;tActor.goal='inspector';
    setPlaque(tActor,'Health inspector','#68495e');
  }
  // Sidewalk queue.
  shift.line.slice(0,11).forEach((pGuest,pIndex)=>{
    const tKey='p'+pGuest.id+'_0';
    const tFresh=!gActors.has(tKey);
    const [tQX,tQY]=queueSpot(pIndex);
    const tActor=useActor(tKey,pGuest.leadSprite,tFresh&&shift.mode==='open'?24+pIndex*.4:tQX,tQY);
    const tGoal='queue'+pIndex;
    if(tActor.goal!==tGoal){tActor.goal=tGoal;tActor.path=[[tQX,tQY]];tActor.sitting=false;tActor.speed=2.6;}
    if(!tActor.path.length)tActor.facing=-Math.PI/2;
    setBubble(tActor,shift.coffeeGlow>0?'coffee':pGuest.critic?'star':pGuest.patience/pGuest.max<.32?'clock':null);
  });
  // Parties at tables and counter seats.
  shift.tables.forEach((pTable,pIndex)=>{
    const tParty=pTable.party;
    if(!tParty)return;
    for(let tJ=0;tJ<tParty.size;tJ++){
      const tKey='p'+tParty.id+'_'+tJ;
      const tDesign=tJ===0?tParty.leadSprite:4+(tParty.id+tJ)%4;
      const tFresh=!gActors.has(tKey);
      const tActor=useActor(tKey,tDesign,gDoorOutside[0]+.3,10.0);
      const tGoal='seat'+pIndex+'_'+tJ;
      if(tActor.goal!==tGoal){
        tActor.goal=tGoal;tActor.sitting=true;tActor.speed=3.4;
        tActor.path=routeToSeat(tActor.x,tActor.y,pIndex,tJ);
        if(tFresh)tActor.delay=tJ*.32;
        setBubble(tActor,null);
      }
      if(!tActor.path.length){
        const [tTX,tTY]=tablePositions[pIndex];
        const [tSX,tSY]=seatSpot(pIndex,tJ);
        tActor.facing=isCounter(pIndex)?Math.PI:facingToward(tSX,tSY,tTX,tTY);
      }
      if(tJ===0){
        const tWaiting=['order','queued','ready','pay'].includes(pTable.state)&&!pTable.job;
        setBubble(tActor,tWaiting&&tParty.mood<.35?'grumpy':tParty.critic?'star':(isCounter(pIndex)&&pTable.state==='eating'?'coffee':null));
      }
    }
  });
  if(shift.band>0){
    [7,5,4].forEach((pDesign,pIndex)=>{
      const tKey='band'+pIndex;
      const tFresh=!gActors.has(tKey);
      const tActor=useActor(tKey,pDesign,-12-pIndex*.6,10.35);
      if(tFresh){tActor.goal='band';tActor.speed=2.4;tActor.path=[[-1.6+pIndex*.75,10.3]];}
      if(!tActor.path.length)tActor.facing=0;
      if(pIndex===0)setPlaque(tActor,'Brass band','#5a3a5a');
      setBubble(tActor,'note');
    });
  }
  // Anyone no longer placed walks off: diners leave by the door, walkouts head down the sidewalk.
  for(const tActor of [...gActors.values()]){
    if(tActor.used)continue;
    if(tActor.key.startsWith('staff')){disposeActor(tActor);continue;}
    if(!tActor.leaving){
      tActor.leaving=true;tActor.sitting=false;tActor.delay=0;setBubble(tActor,null);setPlaque(tActor,null);
      tActor.speed=2.8;
      if(tActor.goal.startsWith('queue'))tActor.path=[[tActor.x,10.6],[26,10.6]];
      else if(tActor.goal==='band')tActor.path=[[tActor.x,10.5],[-16,10.5]];
      else if(tActor.goal==='inspector')tActor.path=[[gDoorX,gAisleY],gDoorInside,gDoorOutside,[gDoorX-1,10.4],[-16,10.4]];
      // Anyone still outside (seated and then gone before reaching the door) just strolls off down the sidewalk.
      else if(tActor.y>gRoomD-.2||tActor.x>gRoomW||tActor.x<0)tActor.path=[[tActor.x,10.4],[-16,10.4]];
      else tActor.path=[[tActor.x,gAisleY],[gDoorX,gAisleY],gDoorInside,gDoorOutside,[gDoorX-1,10.4],[-16,10.4]];
    }
    if(!tActor.path.length){disposeActor(tActor);continue;}
  }
  for(const tActor of gActors.values()){
    if(!tActor.key.startsWith('staff')&&tActor.goal!=='inspector'){stepActor(tActor,pDt);tActor.forceWalk=false;}
    drawActor(tActor,pDt);
  }
}
function syncProps(){
  shift.tables.forEach((pTable,pIndex)=>{
    const tProps=gTableProps[pIndex];if(!tProps||!tProps.food)return;
    tProps.food.visible=pTable.state==='eating';
    tProps.dirty.visible=pTable.state==='dirty';
  });
  const tCooking=!!staff[1].job;
  gCookPan.visible=tCooking;
  setSizzle(shift.mode==='open'&&(staff[1].job?.kind==='cook'||staff[0].job?.kind==='cook'));
  gCookGlow.material.emissiveIntensity=tCooking?.55+Math.sin(performance.now()/90)*.15:0;
}

// ----- Camera, cutaway walls and rendering -----
function currentViewKey(){return view;}
function updateCamera(pDt,pSnap){
  const tView=gViews[currentViewKey()]||gViews.room;
  const tTargetAz=Math.PI/4+gCam.turns*Math.PI/2;
  const tK=pSnap||gSettings.reducedMotion?1:1-Math.exp(-pDt*6);
  let tDelta=tTargetAz-gCam.az;
  gCam.az+=tDelta*tK;
  const tTargetCenter=W3(tView.center[0],tView.center[1],tView.center[2]).add(gCam.pan);
  if(pSnap||!gCam.ready){gCam.center.copy(tTargetCenter);gCam.size=tView.size*gCam.zoom;gCam.ready=true;}
  gCam.center.lerp(tTargetCenter,tK);
  gCam.size+=(tView.size*gCam.zoom-gCam.size)*tK;
  const tEl=gSpriteView.elevation;
  const tDir=new THREE.Vector3(Math.sin(gCam.az)*Math.cos(tEl),Math.sin(tEl),Math.cos(gCam.az)*Math.cos(tEl));
  gCamera.position.copy(gCam.center).addScaledVector(tDir,60);
  gCamera.lookAt(gCam.center);
  const tAspect=canvas.clientWidth/Math.max(1,canvas.clientHeight);
  gCamera.top=gCam.size/2;gCamera.bottom=-gCam.size/2;gCamera.left=-gCam.size*tAspect/2;gCamera.right=gCam.size*tAspect/2;
  gCamera.updateProjectionMatrix();
  // Keep the sun's shadow box centered on what the camera sees.
  gSun.position.copy(gCam.center).add(new THREE.Vector3(-7,16,11));
  gSun.target.position.copy(gCam.center);
  // Sims-style cutaway: walls facing the camera drop to stubs indoors.
  const tCut=tView.cut;
  const tCamX=Math.sin(tTargetAz),tCamY=Math.cos(tTargetAz);
  for(const tWall of Object.values(gWalls)){
    const tFacing=tWall.spec.normal[0]*tCamX+tWall.spec.normal[1]*tCamY>.1;
    const tLow=tCut&&tFacing;
    tWall.full.visible=!tLow;tWall.stub.visible=tLow;
  }
  gRoofGroup.visible=!tCut;gOverhead.visible=!tCut;
  gRegisterPlaque.visible=tCut;
}
function resizeRenderer(pForce){
  const tW=canvas.clientWidth,tH=canvas.clientHeight;
  if(!tW||!tH)return;
  const tRatio=Math.min(window.devicePixelRatio||1,gQuality[gSettings.quality].ratio);
  if(pForce===true||canvas.width!==Math.round(tW*tRatio)||canvas.height!==Math.round(tH*tRatio)){
    gRenderer.setPixelRatio(tRatio);
    gRenderer.setSize(tW,tH,false);
  }
}
function init3D(){
  gRenderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});
  gRenderer.outputColorSpace=THREE.SRGBColorSpace;
  gRenderer.toneMapping=THREE.ACESFilmicToneMapping;
  gRenderer.toneMappingExposure=1.12;
  gRenderer.shadowMap.enabled=true;
  gRenderer.shadowMap.type=THREE.PCFSoftShadowMap;
  gRenderer.shadowMap.autoUpdate=false;
  gScene=new THREE.Scene();
  gTex=buildTextures();
  gScene.background=gTex.sky;
  gCamera=new THREE.OrthographicCamera(-10,10,6,-6,.1,200);
  gScene.add(new THREE.HemisphereLight('#e8f0ff','#b39b74',1.25));
  gSun=new THREE.DirectionalLight('#fff0d4',2.5);
  gSun.castShadow=true;gSun.shadow.mapSize.set(2048,2048);
  Object.assign(gSun.shadow.camera,{left:-17,right:17,top:17,bottom:-17,near:1,far:60});
  gSun.shadow.bias=-.0008;gSun.shadow.normalBias=.02;
  gScene.add(gSun,gSun.target);
  const tFill=new THREE.DirectionalLight('#cfe0ff',.55);tFill.position.set(12,6,-4);gScene.add(tFill);
  buildBuilding();
  buildInterior();
  buildNeighborhood();
  buildExtras();
  optimizeScene();
  resizeRenderer();
  buildAtlases();
  new ResizeObserver(resizeRenderer).observe(canvas);
}
// HTML buttons that float over tables, counter seats and the front door.
function positionPins(){
  const tVec=new THREE.Vector3();
  const tPlace=(pEl,pX,pY,pH)=>{
    tVec.set(pX,pH,pY).project(gCamera);
    const tLeft=((tVec.x+1)/2*100).toFixed(2)+'%',tTop=((1-tVec.y)/2*100).toFixed(2)+'%';
    if(pEl.style.left!==tLeft)pEl.style.left=tLeft;
    if(pEl.style.top!==tTop)pEl.style.top=tTop;
  };
  shift.tables.forEach((pTable,pIndex)=>{
    if(pins[pIndex].hidden)return;
    const [tX,tY]=tablePositions[pIndex];
    tPlace(pins[pIndex],tX,tY,isCounter(pIndex)?1.5:1.25);
  });
  if(!door.hidden)tPlace(door,gDoorX,gRoomD+1.4,2.7);
}
let gLoadingFrame=0;
function render3D(pDt){
  // While the crew is still being rendered, keep the scene alive but give the atlas work the GPU.
  if(!gAtlasReady){if(gLoadingFrame>1)return;gLoadingFrame++;}
  resizeRenderer();
  syncActors(pDt);
  syncProps();
  syncExtras();
  syncNola();
  updateCamera(pDt,false);
  updateShadows();
  gRenderer.render(gScene,gCamera);
  positionPins();
}
// Camera controls: rotate in quarter turns, zoom, and drag to pan.
function turnCamera(pDir){gCam.turns+=pDir;}
function zoomCamera(pFactor){gCam.zoom=Math.min(1.7,Math.max(.5,gCam.zoom*pFactor));}
function resetPan(){gCam.pan.set(0,0,0);}
function panCamera(pRight,pDown){
  const tStep=gCam.size*.06;
  const tRight=new THREE.Vector3(Math.cos(gCam.az),0,-Math.sin(gCam.az));
  const tForward=new THREE.Vector3(-Math.sin(gCam.az),0,-Math.cos(gCam.az));
  gCam.pan.addScaledVector(tRight,pRight*tStep).addScaledVector(tForward,-pDown*tStep);
  gCam.pan.clampLength(0,9);
}
function installCameraControls(){
  canvas.addEventListener('wheel',pEvent=>{pEvent.preventDefault();zoomCamera(Math.exp(pEvent.deltaY*.0012));},{passive:false});
  let tDrag=null;
  canvas.addEventListener('pointerdown',pEvent=>{tDrag={x:pEvent.clientX,y:pEvent.clientY};canvas.setPointerCapture(pEvent.pointerId);});
  canvas.addEventListener('pointermove',pEvent=>{
    if(!tDrag)return;
    const tScale=gCam.size/canvas.clientHeight;
    const tDX=(pEvent.clientX-tDrag.x)*tScale,tDY=(pEvent.clientY-tDrag.y)*tScale/Math.sin(gSpriteView.elevation);
    tDrag={x:pEvent.clientX,y:pEvent.clientY};
    const tRight=new THREE.Vector3(Math.cos(gCam.az),0,-Math.sin(gCam.az));
    const tForward=new THREE.Vector3(-Math.sin(gCam.az),0,-Math.cos(gCam.az));
    gCam.pan.addScaledVector(tRight,-tDX).addScaledVector(tForward,tDY);
    gCam.pan.clampLength(0,9);
  });
  const tEnd=pEvent=>{tDrag=null;};
  canvas.addEventListener('pointerup',tEnd);canvas.addEventListener('pointercancel',tEnd);
  $('turnLeft').onclick=()=>turnCamera(-1);
  $('turnRight').onclick=()=>turnCamera(1);
  $('zoomIn').onclick=()=>zoomCamera(1/1.18);
  $('zoomOut').onclick=()=>zoomCamera(1.18);
  $('recenter').onclick=()=>{resetPan();gCam.zoom=1;gCam.turns=Math.round(gCam.turns/4)*4;};
}

// ----- v0.8.0: day dressing, upgrade props, fire and the brass band -----
function drawMenuBoard(pCtx){
  pCtx.fillStyle='#c9a46a';pCtx.fillRect(0,0,400,300);pCtx.fillStyle='#2f4a40';pCtx.fillRect(12,12,376,276);
  pCtx.strokeStyle='#ffffff18';pCtx.lineWidth=2;for(let tI=0;tI<12;tI++){pCtx.beginPath();pCtx.moveTo(20+tI*31,20);pCtx.lineTo(10+tI*31,280);pCtx.stroke();}
  pCtx.textAlign='center';pCtx.fillStyle='#fff1cb';pCtx.font='bold 34px Georgia,serif';pCtx.fillText('TODAY’S MENU',200,54);
  pCtx.fillStyle='#e9d6a6';pCtx.fillRect(110,64,180,2);
  const tDay=typeof gToday!=='undefined'?gToday:null;
  const tItems=menu.filter(pDish=>!pDish.special||(tDay&&tDay.special===pDish.special));
  pCtx.font='bold '+(tItems.length>5?19:22)+'px system-ui,sans-serif';
  tItems.forEach((pDish,pIndex)=>{
    const tY=98+pIndex*(tItems.length>5?29:tItems.length>4?34:42);
    pCtx.textAlign='left';pCtx.fillStyle=pDish.special?'#ffb88a':'#f6e7c2';pCtx.fillText(pDish.name,34,tY);
    pCtx.textAlign='right';pCtx.fillStyle='#f0ce91';pCtx.fillText('$'+pDish.price,366,tY);
  });
  pCtx.textAlign='center';pCtx.fillStyle='#bfe0c8';pCtx.font='italic 18px Georgia,serif';
  pCtx.fillText(tDay&&tDay.special?'It’s Monday. You know what to order.':'Café au lait · Chicory coffee · Who Dat!',200,272);
}
let gFlipCake,gUpgradeProps={},gBunting,gFireGroup,gHurricaneSky,gNormalSky;
function buildExtras(){
  const tProps=new THREE.Group();gScene.add(tProps);
  // Second griddle between the range and the refrigerator.
  const tGriddle=new THREE.Group();tProps.add(tGriddle);
  box(tGriddle,6.45,.27,0,7.22,1.02,.6,gm('#8a948e',.35,.55));
  box(tGriddle,6.5,.36,.6,7.17,.97,.63,gm('#454d47',.5,.3));
  box(tGriddle,6.5,1.02,.1,7.17,1.04,.45,gm('#3b4945',.6,.3));
  gUpgradeProps.griddle2=tGriddle;
  // Coffee urn on the counter.
  const tUrn=new THREE.Group();tProps.add(tUrn);
  cyl(tUrn,7.55,2.42,.64,1.12,.15,gm('#c9ccc6',.25,.85),.16);
  cyl(tUrn,7.55,2.42,1.12,1.18,.1,gm('#3a3f3d',.4,.4),.15);
  box(tUrn,7.53,2.56,.74,7.57,2.64,.78,gm('#3a3f3d',.4,.4));
  for(const tX of [7.85,7.98])cyl(tUrn,tX,2.6,.64,.72,.035,gm('#f4eedb',.4));
  gUpgradeProps.urn=tUrn;
  // Sidewalk bench left of the door.
  const tBench=new THREE.Group();tProps.add(tBench);
  for(const tX of [1.55,2.95]){box(tBench,tX,9.0,0,tX+.08,9.4,.3,gm('#2c3231',.4,.6));}
  for(let tI=0;tI<3;tI++)box(tBench,1.45,9.0+tI*.14,.3,3.15,9.11+tI*.14,.34,texMat(gTex.wood));
  box(tBench,1.45,8.96,.34,3.15,9.02,.72,texMat(gTex.wood));
  gUpgradeProps.bench=tBench;
  // Jukebox in the front-left corner.
  const tJuke=new THREE.Group();tProps.add(tJuke);
  box(tJuke,.22,7.55,0,.88,8.15,1.05,gm('#7a3f2c',.5,.2));
  const tArch=new THREE.Mesh(new THREE.CylinderGeometry(.33,.33,.6,20,1,false,0,Math.PI),new THREE.MeshStandardMaterial({color:'#f2c46b',emissive:'#ff9a3c',emissiveIntensity:.7,roughness:.4}));
  tArch.rotation.z=Math.PI/2;tArch.rotation.y=Math.PI/2;tArch.position.set(.55,1.05,7.85);tJuke.add(tArch);
  box(tJuke,.9,7.65,.45,.92,8.05,.85,new THREE.MeshStandardMaterial({color:'#9ad0d6',emissive:'#5fb6c2',emissiveIntensity:.5}));
  gUpgradeProps.jukebox=tJuke;
  // Mardi Gras bunting along the parapet.
  gBunting=new THREE.Group();gWalls.front.full.add(gBunting);
  for(let tI=0;tI<26;tI++){
    const tFlag=new THREE.Mesh(new THREE.ConeGeometry(.13,.3,3),new THREE.MeshStandardMaterial({color:'#e3b33a',roughness:.7}));
    tFlag.userData.slot=tI;
    tFlag.rotation.x=Math.PI;tFlag.position.set(.15+tI*.41,3.62-Math.sin(tI*.55)*.04,gRoomD+gWallT+.08);tFlag.castShadow=true;gBunting.add(tFlag);
  }
  // Grease-fire flames on the griddle.
  gFireGroup=new THREE.Group();gScene.add(gFireGroup);
  const tFlameTex=canvasTexture(64,96,(pCtx)=>{
    const tG=pCtx.createRadialGradient(32,74,4,32,60,40);tG.addColorStop(0,'#fff6b0');tG.addColorStop(.35,'#ffb23a');tG.addColorStop(.7,'#f0521f');tG.addColorStop(1,'#f0521f00');
    pCtx.fillStyle=tG;pCtx.beginPath();pCtx.moveTo(32,2);pCtx.quadraticCurveTo(62,52,50,88);pCtx.quadraticCurveTo(32,98,14,88);pCtx.quadraticCurveTo(2,52,32,2);pCtx.fill();
  },false);
  for(let tI=0;tI<5;tI++){
    const tFlame=new THREE.Sprite(new THREE.SpriteMaterial({map:tFlameTex,transparent:true,depthWrite:false,toneMapped:false,blending:THREE.AdditiveBlending}));
    tFlame.position.set(3.85+tI*.25,.95,.68);tFlame.center.set(.5,.15);tFlame.userData.phase=tI*1.7;gFireGroup.add(tFlame);
  }
  gFireGroup.visible=false;
  gFlipCake=new THREE.Mesh(new THREE.CylinderGeometry(.075,.075,.02,16),gm('#d39a52',.7));gFlipCake.castShadow=false;gFlipCake.visible=false;gScene.add(gFlipCake);
  gNormalSky=gTex.sky;
  gHurricaneSky=canvasTexture(4,256,(pCtx)=>{const tG=pCtx.createLinearGradient(0,0,0,256);tG.addColorStop(0,'#4d5862');tG.addColorStop(1,'#a9b0ad');pCtx.fillStyle=tG;pCtx.fillRect(0,0,4,256);},false);
}
function applyDayTo3D(){
  if(!gScene||!gUpgradeProps.urn)return;
  for(const [tId,tGroup] of Object.entries(gUpgradeProps))tGroup.visible=owns(tId);
  const tDay=shift?shift.day:gToday;
  gBunting.visible=tDay.kind==='mardigras'||tDay.kind==='saints';
  const tPalette=tDay.kind==='saints'?['#16130f','#c9a24a']:['#6a2c8a','#2f8a4a','#e3b33a'];
  for(const tFlag of gBunting.children)tFlag.material.color.set(tPalette[tFlag.userData.slot%tPalette.length]);
  const tStorm=tDay.kind==='hurricane';
  gScene.background=tStorm?gHurricaneSky:gNormalSky;
  gSun.intensity=tStorm?1.1:2.5;
  gShadowDirty=true;
  const tMenu=gTex.menuBoard;drawMenuBoard(tMenu.image.getContext('2d'));tMenu.needsUpdate=true;
}
function syncExtras(){
  const tBart=staff[1];
  const tFlipping=tBart.working&&tBart.job?.kind==='cook'&&tBart.station&&tBart.station.startsWith('griddle');
  gFlipCake.visible=!!tFlipping&&!gSettings.reducedMotion;
  if(tFlipping){
    const tT=(performance.now()/1000*1.1)%1;
    const tSpot=gStations[tBart.station];
    gFlipCake.position.set(tSpot.x-.05,.66+Math.sin(tT*Math.PI)*.42,.72);
    gFlipCake.rotation.x=tT*Math.PI*2;
  }
  const tFlaming=!!shift.fire||shift.flambe>21;
  gFireGroup.visible=tFlaming;
  if(tFlaming){
    const tNow=performance.now()/1000;
    for(const tFlame of gFireGroup.children){
      const tFlicker=gSettings.reducedMotion?.85:.75+Math.sin(tNow*11+tFlame.userData.phase)*.18+Math.sin(tNow*23+tFlame.userData.phase*2)*.08;
      const tSize=shift.fire?.55:.32;
      tFlame.scale.set(tSize*.7,tSize*tFlicker*1.3,1);
    }
  }
  gCookGlow.material.emissiveIntensity=Math.max(gCookGlow.material.emissiveIntensity,tFlaming?1.4:0);
}

// ----- v0.9.0: New Orleans flair -----
let gStreetcar,gLanternFlames=[];
function buildNolaFlair(pGroup){
  // Blue-and-white street-name tiles set into the sidewalk, Belgian “split letter” style.
  const tTiles=canvasTexture(640,80,(pCtx)=>{
    pCtx.fillStyle='#f3f0e6';pCtx.fillRect(0,0,640,80);
    pCtx.strokeStyle='#c9c4b5';pCtx.lineWidth=2;for(let tX=0;tX<=640;tX+=40){pCtx.beginPath();pCtx.moveTo(tX,0);pCtx.lineTo(tX,80);pCtx.stroke();}
    pCtx.beginPath();pCtx.moveTo(0,40);pCtx.lineTo(640,40);pCtx.stroke();
    pCtx.strokeStyle='#21508f';pCtx.lineWidth=5;pCtx.strokeRect(6,6,628,68);
    pCtx.fillStyle='#21508f';pCtx.font='bold 50px Georgia,serif';pCtx.textAlign='center';pCtx.textBaseline='middle';
    const tWord='PRYTANIA';
    for(let tI=0;tI<tWord.length;tI++)pCtx.fillText(tWord[tI],70+tI*71,43);
    pCtx.fillStyle='#f3f0e6';pCtx.fillRect(0,38,640,4);
  },false);
  const tTileMesh=new THREE.Mesh(new THREE.PlaneGeometry(3.6,.45),new THREE.MeshStandardMaterial({map:tTiles,roughness:.5}));
  tTileMesh.rotation.x=-Math.PI/2;tTileMesh.position.set(16.6,.004,10.7);tTileMesh.receiveShadow=true;pGroup.add(tTileMesh);
  // Streetcar rails on the far lane and the passing green streetcar.
  for(const tY of [14.62,15.38])box(pGroup,-34,tY-.04,-.15,46,tY+.04,-.13,gm('#8d8f8b',.3,.7),false);
  gStreetcar=buildStreetcar();gScene.add(gStreetcar);
  { const tPts=[];for(let tI=0;tI<=40;tI++){const tT=tI/40;tPts.push(new THREE.Vector3(-34+80*tT,4.35-Math.sin(tT*Math.PI*8)**2*.08,15));}
    gOverhead.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(tPts),new THREE.LineBasicMaterial({color:'#1f2326'}))); }
  // Hanging ferns under the awning.
  const tFront=gWalls.front.full;
  for(const tX of [2.3,8.0]){
    box(tFront,tX-.008,gRoomD+gWallT+.55,1.62,tX+.008,gRoomD+gWallT+.57,2.2,gm('#2a2f2e',.4,.6),false);
    cyl(tFront,tX,gRoomD+gWallT+.56,1.42,1.62,.2,gm('#5a4632',.9),.14);
    for(let tI=0;tI<11;tI++){
      const tFrond=new THREE.Mesh(new THREE.ConeGeometry(.05,.5,4),gm(tI%2?'#4e7d3e':'#6c9a4f',.9));
      const tA=tI/11*Math.PI*2;
      tFrond.position.set(tX+Math.cos(tA)*.17,1.45,gRoomD+gWallT+.56+Math.sin(tA)*.17);
      tFrond.rotation.set(Math.sin(tA)*1.9,0,-Math.cos(tA)*1.9);tFrond.castShadow=true;tFront.add(tFrond);
    }
  }
  // Copper gas lanterns beside the door.
  for(const tX of [4.3,6.0]){
    box(tFront,tX-.03,gRoomD+gWallT,1.9,tX+.03,gRoomD+gWallT+.22,1.95,gm('#3b2f25',.5,.6));
    const tLantern=new THREE.Group();tFront.add(tLantern);
    box(tLantern,tX-.11,gRoomD+gWallT+.12,1.55,tX+.11,gRoomD+gWallT+.34,1.6,gm('#6b4a2c',.4,.7));
    box(tLantern,tX-.13,gRoomD+gWallT+.1,2.0,tX+.13,gRoomD+gWallT+.36,2.06,gm('#6b4a2c',.4,.7));
    const tGlass=box(tLantern,tX-.1,gRoomD+gWallT+.13,1.6,tX+.1,gRoomD+gWallT+.33,2.0,new THREE.MeshStandardMaterial({color:'#f6dfa0',transparent:true,opacity:.35,roughness:.1}),false);
    tGlass.renderOrder=2;
    const tFlame=new THREE.Mesh(new THREE.SphereGeometry(.05,10,8),new THREE.MeshStandardMaterial({color:'#ffcf6a',emissive:'#ff9d2a',emissiveIntensity:2}));
    tFlame.scale.set(.8,1.5,.8);tFlame.position.set(tX,1.76,gRoomD+gWallT+.23);tLantern.add(tFlame);gLanternFlames.push(tFlame);
  }
}
function buildStreetcar(){
  const tCar=new THREE.Group();
  const tGreen=gm('#3f5a35',.55),tCream=gm('#e9dfbf',.6),tRed=gm('#7a2a24',.5),tDark=gm('#1f2421',.4);
  const tLen=10.5,tW=1.8;
  box(tCar,-tLen/2,-tW/2,.35,tLen/2,tW/2,.95,tGreen);
  box(tCar,-tLen/2,-tW/2-.01,.9,tLen/2,tW/2+.01,.98,tRed);
  for(let tX=-tLen/2+.45;tX<tLen/2-.3;tX+=.62){
    box(tCar,tX,-tW/2-.02,1.0,tX+.48,tW/2+.02,1.72,new THREE.MeshStandardMaterial({color:'#e8d9a8',emissive:'#5a4a2a',emissiveIntensity:.25,roughness:.3}));
  }
  box(tCar,-tLen/2,-tW/2,.98,tLen/2,tW/2,1.0,tGreen);
  for(let tX=-tLen/2;tX<tLen/2;tX+=.62)box(tCar,tX,-tW/2-.03,.98,tX+.14,tW/2+.03,1.78,tGreen);
  box(tCar,-tLen/2,-tW/2,1.72,tLen/2,tW/2,1.85,tGreen);
  const tRoof=new THREE.Mesh(new THREE.CylinderGeometry(tW/2+.08,tW/2+.08,tLen+.2,24),gm('#4b5c43',.6));
  tRoof.rotation.z=Math.PI/2;tRoof.position.set(0,1.85,0);
  const tRoofHolder=new THREE.Group();tRoofHolder.scale.set(1,.3,1);tRoofHolder.position.y=1.85*(1-.3);tRoofHolder.add(tRoof);tCar.add(tRoofHolder);
  box(tCar,-tLen/2-.15,-tW/2+.1,.3,tLen/2+.15,tW/2-.1,.38,tDark);
  for(const tX of [-3.3,3.3])box(tCar,tX-.7,-.7,0,tX+.7,.7,.32,tDark);
  const tSign=canvasTexture(256,48,(pCtx)=>{pCtx.fillStyle='#111';pCtx.fillRect(0,0,256,48);pCtx.fillStyle='#ffd27a';pCtx.font='bold 30px system-ui';pCtx.textAlign='center';pCtx.fillText('ST. CHARLES',128,35);},false);
  for(const tSide of [-1,1]){
    const tPlate=new THREE.Mesh(new THREE.PlaneGeometry(1.1,.22),new THREE.MeshBasicMaterial({map:tSign,toneMapped:false}));
    tPlate.position.set(tSide*(tLen/2+.01),1.62,0);tPlate.rotation.y=tSide*Math.PI/2;tCar.add(tPlate);
  }
  const tPole=box(tCar,-.03,-.03,2.0,.03,.03,4.4,tDark);tPole.rotation.z=.55;tPole.position.x=-1.2;
  tCar.traverse(pNode=>{if(pNode.isMesh){pNode.castShadow=true;}});
  tCar.position.set(-60,-.13,15);
  return tCar;
}
let gStreetcarLastX=-99;
function syncNola(){
  const tNow=performance.now()/1000;
  const tCalm=gSettings.reducedMotion;
  // A streetcar rolls by roughly every 50 seconds (parked out of sight when motion is reduced).
  gStreetcar.visible=!tCalm;
  const tCycle=(tNow%50)/50;
  gStreetcar.position.x=-45+tCycle*100;
  const tBellX=gCam.center.x-7;
  if(!tCalm&&gStreetcarLastX<tBellX&&gStreetcar.position.x>=tBellX&&shift.mode!=='complete')sfx('bell');
  gStreetcarLastX=gStreetcar.position.x;
  for(const [tI,tFlame] of gLanternFlames.entries()){
    const tF=tCalm?1:1+Math.sin(tNow*9+tI*2)*.12+Math.sin(tNow*23+tI)*.06;
    tFlame.scale.set(.8*tF,1.5*tF,.8*tF);
  }
}

// ----- v0.10.0: performance -----
// Static meshes are merged per material so the café draws in far fewer calls.
// Anything the game changes at run time is marked userData.keep and left alone.
function geometryPieces(pMesh,pRelative){
  let tGeo=pMesh.geometry.index?pMesh.geometry.toNonIndexed():pMesh.geometry.clone();
  for(const tName of Object.keys(tGeo.attributes))if(!['position','normal','uv'].includes(tName))tGeo.deleteAttribute(tName);
  if(!tGeo.attributes.uv){const tCount=tGeo.attributes.position.count;tGeo.setAttribute('uv',new THREE.Float32BufferAttribute(new Float32Array(tCount*2),2));}
  if(!tGeo.attributes.normal)tGeo.computeVertexNormals();
  tGeo.applyMatrix4(pRelative);
  const tMaterials=Array.isArray(pMesh.material)?pMesh.material:null;
  if(!tMaterials||!tGeo.groups.length){tGeo.clearGroups();return [[tMaterials?tMaterials[0]:pMesh.material,tGeo]];}
  return tGeo.groups.map(pGroup=>{
    const tPart=new THREE.BufferGeometry();
    for(const [tName,tAttr] of Object.entries(tGeo.attributes)){
      const tSize=tAttr.itemSize;
      tPart.setAttribute(tName,new THREE.Float32BufferAttribute(tAttr.array.slice(pGroup.start*tSize,(pGroup.start+pGroup.count)*tSize),tSize));
    }
    return [tMaterials[pGroup.materialIndex],tPart];
  });
}
function mergeStatic(pRoot){
  pRoot.updateMatrixWorld(true);
  const tInverse=new THREE.Matrix4().copy(pRoot.matrixWorld).invert();
  const tBuckets=new Map(),tVictims=[];
  const tVisit=pNode=>{
    for(const tChild of [...pNode.children]){
      if(tChild.userData.keep)continue;
      if(tChild.isMesh&&!tChild.isSprite){
        const tRelative=new THREE.Matrix4().multiplyMatrices(tInverse,tChild.matrixWorld);
        for(const [tMat,tGeo] of geometryPieces(tChild,tRelative)){
          const tKey=tMat.uuid+'|'+tChild.castShadow+'|'+tChild.receiveShadow+'|'+tChild.renderOrder;
          if(!tBuckets.has(tKey))tBuckets.set(tKey,{mat:tMat,cast:tChild.castShadow,receive:tChild.receiveShadow,order:tChild.renderOrder,geos:[]});
          tBuckets.get(tKey).geos.push(tGeo);
        }
        tVictims.push(tChild);
      }
      if(tChild.isGroup||tChild.isMesh)tVisit(tChild);
    }
  };
  tVisit(pRoot);
  if(tVictims.length<2){for(const tB of tBuckets.values())tB.geos.forEach(pG=>pG.dispose());return;}
  for(const tVictim of tVictims){
    tVictim.parent.remove(tVictim);
    for(const tChild of [...tVictim.children])pRoot.attach(tChild);
    tVictim.geometry.dispose();
  }
  for(const tBucket of tBuckets.values()){
    const tMerged=THREE.mergeGeometries(tBucket.geos,false);
    tBucket.geos.forEach(pG=>pG.dispose());
    if(!tMerged)continue;
    const tMesh=new THREE.Mesh(tMerged,tBucket.mat);
    tMesh.castShadow=tBucket.cast;tMesh.receiveShadow=tBucket.receive;tMesh.renderOrder=tBucket.order;
    pRoot.add(tMesh);
  }
}
function optimizeScene(){
  // Mark run-time objects that must stay separate.
  for(const tObj of [gCookGlow,gCookPan,gBunting,gFireGroup,gFlipCake,gStreetcar,...gLanternFlames,...Object.values(gUpgradeProps)])if(tObj)tObj.userData.keep=true;
  for(const tProps of gTableProps)if(tProps&&tProps.food){tProps.food.userData.keep=true;tProps.dirty.userData.keep=true;}
  for(const tWall of Object.values(gWalls)){tWall.full.userData.keep=true;tWall.stub.userData.keep=true;}
  gRoofGroup.userData.keep=true;
  // Merge each independent group on its own.
  for(const tWall of Object.values(gWalls)){mergeStatic(tWall.full);mergeStatic(tWall.stub);}
  mergeStatic(gRoofGroup);
  for(const tGroup of Object.values(gUpgradeProps))mergeStatic(tGroup);
  mergeStatic(gStreetcar);
  for(const tChild of [...gScene.children])if(tChild.isGroup&&!tChild.userData.keep)mergeStatic(tChild);
  gShadowDirty=true;
}
let gShadowDirty=true,gShadowClock=0;
const gShadowLast={x:NaN,z:NaN,size:NaN,az:NaN,vis:''};
function updateShadows(){
  const tVis=Object.values(gWalls).map(pW=>pW.full.visible?1:0).join('')+(gRoofGroup.visible?1:0)+Object.values(gUpgradeProps).map(pG=>pG.visible?1:0).join('');
  if(Math.abs(gCam.center.x-gShadowLast.x)>.05||Math.abs(gCam.center.z-gShadowLast.z)>.05||Math.abs(gCam.size-gShadowLast.size)>.05||Math.abs(gCam.az-gShadowLast.az)>.002||tVis!==gShadowLast.vis){
    gShadowDirty=true;Object.assign(gShadowLast,{x:gCam.center.x,z:gCam.center.z,size:gCam.size,az:gCam.az,vis:tVis});
  }
  // The streetcar is the only moving shadow caster; refresh its shadow a few times a second while it is near.
  const tNow=performance.now();
  if(gStreetcar.visible&&Math.abs(gStreetcar.position.x-gCam.center.x)<24&&tNow-gShadowClock>110)gShadowDirty=true;
  if(gShadowDirty){gRenderer.shadowMap.needsUpdate=true;gShadowDirty=false;gShadowClock=tNow;}
}

// An original retro comic-poster painting: a heroic bluebird mascot on a sunburst,
// with a chicory coffee roundel and a streetcar roundel. Drawn in code; no outside art.
function drawPosterArt(pCtx,pW,pH){
  const tInk='#2a1d1a';
  const tOutline=(pWidth=5)=>{pCtx.lineWidth=pWidth;pCtx.strokeStyle=tInk;pCtx.lineJoin='round';pCtx.stroke();};
  // Sunburst
  pCtx.fillStyle='#fbe3b0';pCtx.fillRect(0,0,pW,pH);
  const tCX=pW*.5,tCY=pH*.62;
  for(let tI=0;tI<24;tI++){
    const tA0=tI/24*Math.PI*2,tA1=(tI+.5)/24*Math.PI*2;
    pCtx.fillStyle='#f6b14d';pCtx.beginPath();pCtx.moveTo(tCX,tCY);pCtx.lineTo(tCX+Math.cos(tA0)*600,tCY+Math.sin(tA0)*600);pCtx.lineTo(tCX+Math.cos(tA1)*600,tCY+Math.sin(tA1)*600);pCtx.fill();
  }
  // Clouds
  pCtx.fillStyle='#f4f1ea';
  for(const [tX,tY,tR] of [[30,330,40],[78,318,34],[120,334,30],[250,330,34],[296,316,40],[200,344,28],[160,350,30]]){pCtx.beginPath();pCtx.arc(tX,tY,tR,0,7);pCtx.fill();pCtx.lineWidth=3;pCtx.strokeStyle='#9fb3c8';pCtx.stroke();}
  // Title with a chunky drop shadow
  pCtx.save();pCtx.textAlign='center';pCtx.font='900 62px Impact,"Arial Black",sans-serif';
  const tTitle='BLUEBIRD!';
  const tArc=(pDX,pDY,pFill,pStroke)=>{
    const tR=420,tSpan=.62;
    for(let tI=0;tI<tTitle.length;tI++){
      const tA=-Math.PI/2+(tI-(tTitle.length-1)/2)*(tSpan/(tTitle.length-1));
      pCtx.save();pCtx.translate(pW/2+Math.cos(tA)*tR+pDX,tR+62+Math.sin(tA)*tR+pDY);pCtx.rotate(tA+Math.PI/2);
      if(pStroke){pCtx.lineWidth=8;pCtx.strokeStyle=pStroke;pCtx.strokeText(tTitle[tI],0,0);}
      pCtx.fillStyle=pFill;pCtx.fillText(tTitle[tI],0,0);pCtx.restore();
    }
  };
  tArc(6,6,'#5a2a1e','#5a2a1e');tArc(0,0,'#f8a23a','#c8321e');
  pCtx.restore();
  // Roundels
  const tRoundel=(pX,pY,pR,pDraw)=>{
    pCtx.save();pCtx.beginPath();pCtx.arc(pX,pY,pR,0,7);pCtx.fillStyle='#f3cf7a';pCtx.fill();pCtx.clip();pDraw();pCtx.restore();
    pCtx.beginPath();pCtx.arc(pX,pY,pR,0,7);pCtx.lineWidth=7;pCtx.strokeStyle='#c8321e';pCtx.stroke();tOutline(3);
  };
  tRoundel(52,150,42,()=>{
    for(let tI=0;tI<12;tI++){const tA=tI/12*Math.PI*2;pCtx.fillStyle=tI%2?'#f3cf7a':'#f7e2a8';pCtx.beginPath();pCtx.moveTo(52,150);pCtx.arc(52,150,60,tA,tA+Math.PI/6);pCtx.fill();}
    pCtx.fillStyle='#f6f1e4';pCtx.fillRect(34,146,32,26);pCtx.strokeStyle=tInk;pCtx.lineWidth=3;pCtx.strokeRect(34,146,32,26);
    pCtx.beginPath();pCtx.arc(68,158,7,-1.4,1.4);pCtx.stroke();pCtx.fillStyle='#6b3a1f';pCtx.fillRect(36,148,28,5);
    pCtx.strokeStyle='#8a9aa0';for(const tX of [42,50,58]){pCtx.beginPath();pCtx.moveTo(tX,140);pCtx.quadraticCurveTo(tX-6,132,tX,124);pCtx.stroke();}
  });
  tRoundel(272,272,44,()=>{
    pCtx.fillStyle='#bfe0e6';pCtx.fillRect(220,220,110,110);
    pCtx.strokeStyle='#ffffffaa';pCtx.lineWidth=3;for(let tI=0;tI<5;tI++){pCtx.beginPath();pCtx.moveTo(226,252+tI*9);pCtx.lineTo(252,252+tI*9);pCtx.stroke();}
    pCtx.fillStyle='#3f5a35';pCtx.fillRect(250,256,64,26);pCtx.fillStyle='#4b5c43';pCtx.beginPath();pCtx.ellipse(282,256,33,7,0,Math.PI,0);pCtx.fill();
    pCtx.fillStyle='#e8d9a8';for(let tX=254;tX<310;tX+=9)pCtx.fillRect(tX,260,6,9);
    pCtx.fillStyle='#7a2a24';pCtx.fillRect(250,272,64,3);pCtx.fillStyle='#222';pCtx.fillRect(258,282,10,5);pCtx.fillRect(296,282,10,5);
    pCtx.strokeStyle=tInk;pCtx.lineWidth=2;pCtx.beginPath();pCtx.moveTo(270,249);pCtx.lineTo(290,226);pCtx.stroke();
  });
  // The hero: a bluebird with a rusty breast, wings flung wide, in a confident pose.
  pCtx.save();pCtx.translate(pW*.52,pH*.6);
  // Tail
  pCtx.beginPath();pCtx.moveTo(-10,70);pCtx.lineTo(-38,128);pCtx.lineTo(-6,118);pCtx.lineTo(10,130);pCtx.lineTo(14,72);pCtx.closePath();pCtx.fillStyle='#2f5f9e';pCtx.fill();tOutline(4);
  // Wings
  for(const tSide of [-1,1]){
    pCtx.beginPath();pCtx.moveTo(tSide*30,-10);
    pCtx.quadraticCurveTo(tSide*92,-70,tSide*128,-56);
    pCtx.lineTo(tSide*104,-40);pCtx.lineTo(tSide*124,-28);pCtx.lineTo(tSide*98,-16);pCtx.lineTo(tSide*112,-2);pCtx.lineTo(tSide*84,4);
    pCtx.quadraticCurveTo(tSide*56,20,tSide*30,30);pCtx.closePath();
    pCtx.fillStyle='#3a74bd';pCtx.fill();tOutline(4);
    pCtx.beginPath();pCtx.moveTo(tSide*40,-4);pCtx.quadraticCurveTo(tSide*80,-40,tSide*112,-46);pCtx.lineWidth=3;pCtx.strokeStyle='#8fc0ea';pCtx.stroke();
  }
  // Body and breast
  pCtx.beginPath();pCtx.ellipse(0,20,46,62,0,0,7);pCtx.fillStyle='#3f7cc6';pCtx.fill();tOutline(5);
  pCtx.beginPath();pCtx.ellipse(4,30,30,42,0,0,7);pCtx.fillStyle='#e38b4a';pCtx.fill();
  pCtx.beginPath();pCtx.ellipse(6,50,20,22,0,0,7);pCtx.fillStyle='#f4e6cf';pCtx.fill();
  pCtx.beginPath();pCtx.ellipse(4,30,30,42,0,0,7);tOutline(3);
  // A little chef's neckerchief
  pCtx.beginPath();pCtx.moveTo(-18,-22);pCtx.lineTo(22,-22);pCtx.lineTo(2,4);pCtx.closePath();pCtx.fillStyle='#c8321e';pCtx.fill();tOutline(3);
  // Head
  pCtx.beginPath();pCtx.arc(0,-48,36,0,7);pCtx.fillStyle='#3f7cc6';pCtx.fill();tOutline(5);
  pCtx.beginPath();pCtx.arc(-6,-36,14,0,7);pCtx.fillStyle='#8fc0ea44';pCtx.fill();
  pCtx.beginPath();pCtx.arc(14,-54,11,0,7);pCtx.fillStyle='#ffffff';pCtx.fill();tOutline(3);
  pCtx.beginPath();pCtx.arc(17,-54,5,0,7);pCtx.fillStyle=tInk;pCtx.fill();
  pCtx.beginPath();pCtx.arc(19,-56,1.8,0,7);pCtx.fillStyle='#fff';pCtx.fill();
  pCtx.beginPath();pCtx.moveTo(30,-50);pCtx.lineTo(62,-42);pCtx.lineTo(30,-36);pCtx.closePath();pCtx.fillStyle='#f2c14e';pCtx.fill();tOutline(3);
  pCtx.beginPath();pCtx.moveTo(6,-68);pCtx.quadraticCurveTo(16,-76,26,-68);pCtx.lineWidth=4;pCtx.strokeStyle=tInk;pCtx.stroke();
  // Feet
  pCtx.strokeStyle='#e0a03a';pCtx.lineWidth=5;for(const tX of [-16,16]){pCtx.beginPath();pCtx.moveTo(tX,78);pCtx.lineTo(tX,96);pCtx.lineTo(tX-10,102);pCtx.moveTo(tX,96);pCtx.lineTo(tX+10,102);pCtx.stroke();}
  pCtx.restore();
  // Halftone dots for the comic look
  pCtx.fillStyle='#00000012';
  for(let tY=6;tY<pH;tY+=8)for(let tX=(tY/8)%2*4;tX<pW;tX+=8){pCtx.beginPath();pCtx.arc(tX,tY,1.3,0,7);pCtx.fill();}
}
