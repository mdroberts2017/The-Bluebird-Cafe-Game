// ===== Pre-rendered characters =====
// Each character is posed as a small 3D figure in an offscreen scene, rendered from
// eight directions into a sprite atlas, then shown in the café as a flat standee.
// They have a rendered 3D look but are not live 3D models during play.
const gFrameW=128, gFrameH=224;
const gSpriteView={width:.92,height:.92*gFrameH/gFrameW,center:.6,elevation:Math.PI/6};
const gDirections=8;
const gCarryKinds=['food','setting','clear'];
const gDesigns=[
  {name:'Sally',h:1.08,cook:true,skin:'#f2c7a5',hair:{style:'curly',color:'#9b4a2b'},hat:{type:'toque',color:'#fbf8f0'},glasses:true,shirt:'#e07f6b',sleeves:'short',neckerchief:'#c9312c',apron:{color:'#f5eedb',stripe:'#c9312c',bib:true,length:.36},skirt:{color:'#3e5f48'},legs:'#f2c7a5',shoes:'#2b2523',idle:'hips',staff:true},
  {name:'Bart',h:1.2,skin:'#f0c6a2',hair:{style:'short',color:'#e6c56c',fringe:true},cook:true,hat:{type:'tall-toque',color:'#fbf8f0'},shirt:'#5b84b4',sleeves:'rolled',apron:{color:'#f3ecd8',bib:true,length:.5},towel:true,pants:'#3c3f45',shoes:'#3a2a22',idle:'hips',staff:true},
  {name:'Rita',h:1.16,skin:'#f3c9a7',hair:{style:'curly',color:'#9a4b28',clip:'#e3d07a'},shirt:'#88aa72',sleeves:'short',skirt:{color:'#3c5440',hem:'#efe0b8'},apron:{color:'#2f4535',bib:false,length:.3,pocket:'#f2ead6'},legs:'#f3c9a7',shoes:'#1f1d1d',idle:'notepad',staff:true},
  {name:'Jane',h:1.16,skin:'#8a5a3c',hair:{style:'puff',color:'#1d1513',band:'#e0748a'},earrings:'#e8bf4a',shirt:'#8c4a55',sleeves:'short',skirt:{color:'#4a3a33',hem:'#efe0b8'},apron:{color:'#3a2c27',bib:false,length:.3,pocket:'#f2ead6'},legs:'#8a5a3c',shoes:'#1f1d1d',idle:'down',staff:true},
  {name:'Regular',h:1.12,stout:true,skin:'#f0c8a8',hair:{style:'short',color:'#e9e4dc'},mustache:'#efebe4',hat:{type:'flatcap',color:'#7a4a32'},shirt:'#eee3c6',jacket:'#8a4a32',suspenders:'#3b3b2a',pants:'#5d6b3a',shoes:'#3a2a22',idle:'mug'},
  {name:'Businessman',h:1.2,skin:'#f1c7a4',hair:{style:'short',color:'#2b2622'},shirt:'#f3f1ea',jacket:'#6f747b',tie:'#a3312d',pants:'#6a6f76',shoes:'#2c221d',idle:'briefcase'},
  {name:'Tourist',h:1.14,skin:'#f4cdb0',hair:{style:'bob',color:'#d8a85a'},hat:{type:'straw',color:'#e3c98b',band:'#3c3a3a'},shirt:'#f1e6c9',sleeves:'short',suspenders:'#7a4e2c',skirt:{color:'#4f8576',floral:true},legs:'#f4cdb0',shoes:'#e8dcc4',idle:'camera'},
  {name:'Local',h:1.2,skin:'#9b6a47',hair:{style:'short',color:'#241a15'},mustache:'#241a15',hat:{type:'straw',color:'#e2c487',band:'#5a3a26'},shirt:'#efe2c2',sleeves:'rolled',suspenders:'#4a2f22',pants:'#7a5a40',shoes:'#3a2a22',idle:'pockets'},
  {name:'Officer',h:1.18,skin:'#9a6847',hair:{style:'short',color:'#1f1712'},mustache:'#1f1712',hat:{type:'police',color:'#24304f'},shirt:'#7fa6cf',sleeves:'short',badge:'#e3be4b',belt:'#1d1d22',pants:'#253256',shoes:'#16161a',idle:'hips'}
];
function figureRows(pDesign){
  const tRows=[['stand',null],['walk1',null],['walk2',null],['sit',null]];
  if(pDesign.staff)for(const tKind of gCarryKinds)for(const tPose of ['stand','walk1','walk2'])tRows.push([tPose,tKind]);
  if(pDesign.cook)tRows.push(['cook1',null],['cook2',null]);
  return tRows;
}
function frameRow(pDesign,pPose,pCarry){
  if(pPose==='sit')return 3;
  if(pPose==='cook1'||pPose==='cook2')return pDesign.cook?13+(pPose==='cook2'?1:0):0;
  const tBase={stand:0,walk1:1,walk2:2}[pPose];
  if(!pCarry||!pDesign.staff)return tBase;
  return 4+gCarryKinds.indexOf(pCarry)*3+tBase;
}
function buildFigure(pDesign,pPose,pCarry){
  const gV=(pX,pY,pZ)=>new THREE.Vector3(pX,pY,pZ);
  const tGroup=new THREE.Group();
  const tCache=new Map();
  const tMat=pColor=>{
    if(pColor instanceof THREE.Texture){return new THREE.MeshStandardMaterial({map:pColor,roughness:.8});}
    if(!tCache.has(pColor))tCache.set(pColor,new THREE.MeshStandardMaterial({color:pColor,roughness:.72,metalness:0}));
    return tCache.get(pColor);
  };
  const tAdd=(pGeo,pColor,pPos,pRot,pScale)=>{
    const tMesh=new THREE.Mesh(pGeo,tMat(pColor));
    if(pPos)tMesh.position.copy(pPos);
    if(pRot)tMesh.rotation.set(pRot[0],pRot[1],pRot[2]);
    if(pScale)tMesh.scale.set(pScale[0],pScale[1],pScale[2]);
    tGroup.add(tMesh);return tMesh;
  };
  const tLimb=(pFrom,pTo,pRadius,pColor)=>{
    const tDir=new THREE.Vector3().subVectors(pTo,pFrom);
    const tLength=tDir.length();
    const tMesh=tAdd(new THREE.CapsuleGeometry(pRadius,Math.max(.001,tLength),4,10),pColor);
    tMesh.position.copy(pFrom).addScaledVector(tDir,.5);
    tMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),tDir.normalize());
    return tMesh;
  };
  const tSphere=(pR,pColor,pPos,pScale)=>tAdd(new THREE.SphereGeometry(pR,18,14),pColor,pPos,null,pScale);
  const tBox=(pW,pH,pD,pColor,pPos,pRot)=>tAdd(new THREE.BoxGeometry(pW,pH,pD),pColor,pPos,pRot);
  const tCyl=(pRTop,pRBottom,pH,pColor,pPos,pRot,pScale,pOpen)=>tAdd(new THREE.CylinderGeometry(pRTop,pRBottom,pH,22,1,!!pOpen),pColor,pPos,pRot,pScale);

  const tH=pDesign.h, tW=pDesign.stout?1.22:1;
  const tSit=pPose==='sit';
  const tWalk=pPose==='walk1'?1:pPose==='walk2'?-1:0;
  const tHipStand=tH*.43;
  const tBase=tSit?.31:tHipStand;
  const tTorsoLen=tH*.28;
  const tShoulder=tBase+tTorsoLen;
  const tHeadR=tH*.118;
  const tHeadY=tShoulder+tH*.035+tHeadR;
  const tBodyDepth=.62;
  const tTorsoTopR=.125*tW, tTorsoBottomR=(pDesign.stout?.15:.115)*tW;
  const tFrontZ=tTorsoTopR*tBodyDepth+.008;

  // Legs
  const tThigh=tHipStand*.52, tShin=tHipStand*.48;
  const tLegColor=pDesign.pants||pDesign.legs||pDesign.skin;
  for(const tSide of [-1,1]){
    const tHip=gV(tSide*.062*tW,tBase,0);
    let tKnee,tAnkle;
    if(tSit){
      tKnee=gV(tSide*.07*tW,tBase+.02,tThigh);
      tAnkle=gV(tSide*.07*tW,.06,tThigh+.04);
    }else{
      const tSwing=tSide*tWalk*.42;
      tKnee=gV(tHip.x,tBase-Math.cos(tSwing)*tThigh,Math.sin(tSwing)*tThigh);
      const tShinSwing=tSwing-(tSwing<0?.35:0);
      tAnkle=gV(tHip.x,tKnee.y-Math.cos(tShinSwing)*tShin,tKnee.z+Math.sin(tShinSwing)*tShin);
    }
    const tUpperColor=pDesign.pants?pDesign.pants:(pDesign.skirt?pDesign.legs:tLegColor);
    tLimb(tHip,tKnee,pDesign.pants?.058*tW:.045,tUpperColor);
    tLimb(tKnee,tAnkle,pDesign.pants?.052*tW:.04,pDesign.pants||pDesign.legs);
    const tShoe=tSphere(.05,pDesign.shoes,gV(tAnkle.x,Math.max(.035,tAnkle.y-.02),tAnkle.z+.035),[1,.75,1.65]);
    if(tSit)tShoe.position.y=.04;
  }
  // Skirt / apron skirt
  if(pDesign.skirt){
    const tSkirtLen=tSit?.16:tH*.24;
    let tSkirtMat=pDesign.skirt.color;
    if(pDesign.skirt.floral){
      const tCanvas=document.createElement('canvas');tCanvas.width=tCanvas.height=128;
      const tCtx=tCanvas.getContext('2d');tCtx.fillStyle=pDesign.skirt.color;tCtx.fillRect(0,0,128,128);
      for(let tI=0;tI<26;tI++){
        const tX=(tI*47)%128,tY=(tI*29)%128;
        tCtx.fillStyle=tI%2?'#f1e3c0':'#e9a3a0';
        for(let tP=0;tP<5;tP++){const tA=tP/5*Math.PI*2;tCtx.beginPath();tCtx.arc(tX+Math.cos(tA)*4,tY+Math.sin(tA)*4,3,0,7);tCtx.fill();}
        tCtx.fillStyle='#e6c25a';tCtx.beginPath();tCtx.arc(tX,tY,2,0,7);tCtx.fill();
      }
      const tTex=new THREE.CanvasTexture(tCanvas);tTex.colorSpace=THREE.SRGBColorSpace;tTex.wrapS=tTex.wrapT=THREE.RepeatWrapping;tTex.repeat.set(3,1);
      tSkirtMat=tTex;
    }
    if(tSit){
      tCyl(tTorsoBottomR*1.05,tTorsoBottomR*1.2,.12,tSkirtMat,gV(0,tBase+.02,.02),null,[1,1,1]);
      tBox(.24*tW,.05,tThigh*.85,tSkirtMat,gV(0,tBase+.04,tThigh*.45));
    }else{
      const tFlare=.2*tW;
      tCyl(tTorsoBottomR*1.02,tFlare,tSkirtLen,tSkirtMat,gV(0,tBase-tSkirtLen/2+.03,0),[tWalk*.06,0,0],[1,1,.86]);
      if(pDesign.skirt.hem)tCyl(tFlare,tFlare*1.03,.03,pDesign.skirt.hem,gV(0,tBase-tSkirtLen+.03,0),[tWalk*.06,0,0],[1,1,.86]);
    }
  }
  // Torso
  const tTorsoColor=pDesign.jacket||pDesign.shirt;
  tCyl(tTorsoTopR,tTorsoBottomR,tTorsoLen,tTorsoColor,gV(0,tBase+tTorsoLen/2,0),null,[1,1,tBodyDepth]);
  tSphere(tTorsoTopR,tTorsoColor,gV(0,tShoulder-.01,0),[1.12,.42,tBodyDepth*1.05]);
  if(pDesign.stout)tSphere(.15*tW,tTorsoColor,gV(0,tBase+tTorsoLen*.38,.03),[1,1,.85]);
  if(pDesign.jacket){
    tBox(.07,tTorsoLen*.92,.01,pDesign.shirt,gV(0,tBase+tTorsoLen*.52,tFrontZ+(pDesign.stout?.05:.003)));
  }
  if(pDesign.tie)tBox(.03,tTorsoLen*.8,.012,pDesign.tie,gV(0,tBase+tTorsoLen*.55,tFrontZ+.012));
  if(pDesign.belt||pDesign.pants)tCyl(tTorsoBottomR*1.02,tTorsoBottomR*1.02,.035,pDesign.belt||'#3a2c24',gV(0,tBase+.02,0),null,[1,1,tBodyDepth*1.05]);
  if(pDesign.suspenders){
    for(const tSide of [-1,1]){
      tBox(.022,tTorsoLen,.01,pDesign.suspenders,gV(tSide*.06*tW,tBase+tTorsoLen/2,tFrontZ+(pDesign.stout?.045:.004)));
      tBox(.022,tTorsoLen,.01,pDesign.suspenders,gV(tSide*.06*tW,tBase+tTorsoLen/2,-tFrontZ-.004));
    }
  }
  if(pDesign.badge){
    tBox(.035,.04,.01,pDesign.badge,gV(-.06,tShoulder-.07,tFrontZ+.004));
    tBox(.02,.025,.01,'#cfd7e2',gV(.07,tShoulder-.06,tFrontZ+.004));
  }
  if(pDesign.apron){
    const tApronLen=tSit?.08:pDesign.apron.length;
    if(pDesign.apron.bib)tBox(.16*tW,tTorsoLen*.62,.012,pDesign.apron.color,gV(0,tBase+tTorsoLen*.62,tFrontZ+.004));
    if(!tSit){
      const tTilt=pDesign.skirt?-.12:0, tOut=pDesign.skirt?.1:.012;
      const tApron=tBox(.26*tW,tApronLen,.012,pDesign.apron.color,gV(0,tBase-tApronLen/2+.04,tFrontZ+tOut),[tTilt,0,0]);
      if(pDesign.apron.stripe)tBox(.262*tW,.025,.014,pDesign.apron.stripe,gV(0,tBase-tApronLen+.05,tFrontZ+tOut+.012),[tTilt,0,0]);
      if(pDesign.apron.pocket)tBox(.07,.05,.014,pDesign.apron.pocket,gV(.05,tBase-.05,tFrontZ+tOut+.005),[tTilt,0,0]);
      tApron.castShadow=false;
    }
  }
  if(pDesign.neckerchief)tAdd(new THREE.ConeGeometry(.05,.08,3),pDesign.neckerchief,gV(0,tShoulder-.03,tFrontZ),[Math.PI,0,0]);
  if(pDesign.towel){
    tBox(.07,.13,.012,'#f4efe2',gV(-.1,tShoulder-.06,tFrontZ+.002));
    tBox(.071,.02,.014,'#c9312c',gV(-.1,tShoulder-.1,tFrontZ+.003));
  }
  // Neck and head
  tCyl(.04,.045,.06,pDesign.skin,gV(0,tShoulder+.02,0));
  tSphere(tHeadR,pDesign.skin,gV(0,tHeadY,0),[1,1.02,.96]);
  for(const tSide of [-1,1]){
    tSphere(.025,pDesign.skin,gV(tSide*tHeadR*.97,tHeadY-.01,0),[.6,1,1]);
    tSphere(.016,'#22181a',gV(tSide*tHeadR*.36,tHeadY+.012,tHeadR*.86),[1,1.25,.6]);
    tSphere(.006,'#ffffff',gV(tSide*tHeadR*.36+.005,tHeadY+.02,tHeadR*.9),[1,1,.6]);
    tBox(.035,.008,.01,pDesign.hair.color==='#e9e4dc'?'#d8d2c8':pDesign.hair.color,gV(tSide*tHeadR*.38,tHeadY+.05,tHeadR*.85),[-.2,0,tSide*-.12]);
    if(pDesign.earrings)tSphere(.014,pDesign.earrings,gV(tSide*tHeadR,tHeadY-.05,.01));
    if(['Sally','Rita','Jane','Tourist'].includes(pDesign.name))tSphere(.018,'#e98b7d',gV(tSide*tHeadR*.55,tHeadY-.03,tHeadR*.78),[1,.6,.5]);
  }
  tSphere(.02,pDesign.skin,gV(0,tHeadY-.015,tHeadR*.98),[1,.9,1]);
  tBox(.045,.008,.01,'#7a3a33',gV(0,tHeadY-.055,tHeadR*.9),[.15,0,0]);
  if(pDesign.mustache)tAdd(new THREE.CapsuleGeometry(.014,.06,3,8),pDesign.mustache,gV(0,tHeadY-.04,tHeadR*.94),[0,0,Math.PI/2]);
  if(pDesign.glasses){
    for(const tSide of [-1,1])tAdd(new THREE.TorusGeometry(.028,.006,6,18),'#5a2f24',gV(tSide*tHeadR*.36,tHeadY+.012,tHeadR*.95));
    tBox(.03,.006,.006,'#5a2f24',gV(0,tHeadY+.015,tHeadR*.97));
  }
  // Hair
  const tHair=pDesign.hair;
  const tCap=tAdd(new THREE.SphereGeometry(tHeadR*1.07,24,16,0,Math.PI*2,0,Math.PI*.52),tHair.color,gV(0,tHeadY+.005,-.012),[-.42,0,0]);
  tSphere(tHeadR*1.0,tHair.color,gV(0,tHeadY-.01,-.03),[1.02,1,.95]);
  if(tHair.style==='curly'){
    for(let tI=0;tI<14;tI++){
      const tA=tI/14*Math.PI*2;
      const tY=tHeadY+(tI%3-1)*.035;
      if(Math.sin(tA)>.55&&tY<tHeadY+.04)continue;
      tSphere(.048,tHair.color,gV(Math.cos(tA)*tHeadR*1.02,tY+.01,Math.sin(tA)*tHeadR*.98-.02));
    }
    for(const tX of [-.06,0,.06])tSphere(.05,tHair.color,gV(tX,tHeadY+tHeadR*.85,.02));
    if(tHair.clip)tBox(.04,.012,.012,tHair.clip,gV(-.08,tHeadY+.08,.07),[0,0,.5]);
  }else if(tHair.style==='puff'){
    tSphere(.11,tHair.color,gV(0,tHeadY+tHeadR*1.05,-.05),[1.15,.95,1.1]);
    for(let tI=0;tI<8;tI++){const tA=tI/8*Math.PI*2;tSphere(.05,tHair.color,gV(Math.cos(tA)*.1,tHeadY+tHeadR*1.1+Math.sin(tA)*.05,-.05+Math.sin(tA)*.04));}
    tAdd(new THREE.TorusGeometry(tHeadR*1.0,.012,6,24),tHair.band,gV(0,tHeadY+tHeadR*.55,-.01),[Math.PI/2-.35,0,0]);
  }else if(tHair.style==='short'&&tHair.fringe){
    for(const tX of [-.07,-.02,.035,.08])tSphere(.04,tHair.color,gV(tX,tHeadY+tHeadR*.5,tHeadR*.72),[1.1,.7,.8]);
    for(const tSide of [-1,1])tSphere(.035,tHair.color,gV(tSide*tHeadR*.92,tHeadY+.0,.0),[.6,1.4,1]);
  }else if(tHair.style==='bob'){
    for(const tSide of [-1,1])tSphere(.06,tHair.color,gV(tSide*tHeadR*.92,tHeadY-.04,-.02),[.7,1.25,1]);
  }
  tCap.castShadow=false;
  // Hats
  const tHat=pDesign.hat;
  if(tHat){
    if(tHat.type==='toque'){
      tCyl(tHeadR*.98,tHeadR*.98,.05,tHat.color,gV(0,tHeadY+tHeadR*.62,-.01));
      tSphere(tHeadR*1.1,tHat.color,gV(0,tHeadY+tHeadR*1.12,-.01),[1,.68,1]);
    }else if(tHat.type==='tall-toque'){
      tCyl(tHeadR*.98,tHeadR*.95,.06,tHat.color,gV(0,tHeadY+tHeadR*.62,-.01));
      tCyl(tHeadR*1.0,tHeadR*.9,tHeadR*1.0,tHat.color,gV(0,tHeadY+tHeadR*1.15,-.01));
      tSphere(tHeadR*1.12,tHat.color,gV(0,tHeadY+tHeadR*1.72,-.01),[1,.6,1]);
    }else if(tHat.type==='flatcap'){
      tSphere(tHeadR*1.16,tHat.color,gV(0,tHeadY+tHeadR*.5,-.01),[1,.55,1.08]);
      tBox(tHeadR*1.3,.02,tHeadR*.6,tHat.color,gV(0,tHeadY+tHeadR*.45,tHeadR*.98),[.18,0,0]);
    }else if(tHat.type==='straw'){
      tCyl(tHeadR*1.95,tHeadR*1.95,.014,tHat.color,gV(0,tHeadY+tHeadR*.55,0),[-.06,0,0]);
      tCyl(tHeadR*.92,tHeadR*1.0,tHeadR*.62,tHat.color,gV(0,tHeadY+tHeadR*.9,0));
      tCyl(tHeadR*1.005,tHeadR*1.01,.03,tHat.band,gV(0,tHeadY+tHeadR*.68,0));
    }else if(tHat.type==='police'){
      tCyl(tHeadR*1.15,tHeadR*.98,tHeadR*.55,tHat.color,gV(0,tHeadY+tHeadR*.78,0));
      tAdd(new THREE.CylinderGeometry(tHeadR*.95,tHeadR*.95,.014,20,1,false,-Math.PI/2,Math.PI),'#111318',gV(0,tHeadY+tHeadR*.5,.03),[.2,0,0]);
      tBox(.03,.035,.01,'#e3be4b',gV(0,tHeadY+tHeadR*.85,tHeadR*1.08));
    }
  }
  // Arms and hands
  const tArmColor=pDesign.jacket||pDesign.shirt;
  const tForeColor=(pDesign.jacket||pDesign.sleeves==='long')?tArmColor:pDesign.skin;
  const tShoulderY=tShoulder-.035;
  const tArm=(pSide,pElbow,pHand)=>{
    const tS=gV(pSide*.158*tW,tShoulderY,0);
    if(pDesign.sleeves==='short'||pDesign.sleeves==='rolled'){
      const tMid=new THREE.Vector3().lerpVectors(tS,pElbow,pDesign.sleeves==='short'?.55:.95);
      tLimb(tS,tMid,.042,tArmColor);tLimb(tMid,pElbow,.034,pDesign.skin);
    }else tLimb(tS,pElbow,.042,tArmColor);
    tLimb(pElbow,pHand,.032,tForeColor);
    tSphere(.034,pDesign.skin,pHand);
  };
  const tCook=pPose==='cook1'||pPose==='cook2';
  let tPose=pCarry?'carry':(tSit?'sit':tCook?pPose:pDesign.idle);
  if(tWalk&&['hips','down','pockets','camera'].includes(tPose))tPose='swing';
  const tSwing=tWalk*.16;
  const tElbowY=tShoulderY-.2;
  const tHandAt={};
  for(const tSide of [-1,1]){
    const tX=tSide*.17*tW;
    let tElbow,tHand;
    switch(tPose){
      case 'hips':tElbow=gV(tSide*.29*tW,tShoulderY-.14,-.03);tHand=gV(tSide*.15*tW,tBase+.06,.02);break;
      case 'carry':case 'sit':tElbow=gV(tSide*.18*tW,tElbowY+.02,.04);tHand=gV(tSide*.09,tElbowY+.05,.22);break;
      case 'notepad':
        tElbow=gV(tSide*.2*tW,tElbowY+.02,.05);
        tHand=tSide<0?gV(-.05,tShoulderY-.12,.17):gV(.07,tShoulderY-.14,.16);break;
      case 'mug':
        if(tSide>0){tElbow=gV(.2*tW,tElbowY+.02,.06);tHand=gV(.15*tW,tElbowY+.05,.2);}
        else{tElbow=gV(-.19*tW,tElbowY,-.01);tHand=gV(-.2*tW,tElbowY-.17,.01);}
        break;
      case 'briefcase':
        tElbow=gV(tSide*.19*tW,tElbowY,tSide>0?0:-tSwing);tHand=gV(tSide*.2*tW,tElbowY-.18,tSide>0?0:-tSwing*1.3);break;
      case 'cook1':case 'cook2':
        if(tSide>0){
          const tLift=tPose==='cook2'?.24:0;
          tElbow=gV(.21*tW,tElbowY+.04+tLift*.4,.07);tHand=gV(.13*tW,tElbowY+.08+tLift,.24);
        }else{tElbow=gV(-.2*tW,tElbowY+.02,.06);tHand=gV(-.1*tW,tElbowY+.03,.23);}
        break;
      case 'pockets':tElbow=gV(tSide*.21*tW,tElbowY+.01,-.04);tHand=gV(tSide*.15*tW,tBase-.02,.02);break;
      case 'camera':tElbow=gV(tSide*.2*tW,tElbowY+.01,.04);tHand=gV(tSide*.07,tShoulderY-.2,.14);break;
      default:tElbow=gV(tX+tSide*.02,tElbowY,-tSide*tSwing);tHand=gV(tX+tSide*.025,tElbowY-.18,-tSide*tSwing*1.4);
    }
    tArm(tSide,tElbow,tHand);
    tHandAt[tSide]=tHand;
  }
  // Props held in the idle pose
  if(!pCarry&&!tSit){
    if(tPose==='notepad'||pDesign.idle==='notepad'&&tPose!=='swing'){
      tBox(.11,.14,.015,'#f5efdc',gV(-.03,tShoulderY-.12,.19),[-.4,.2,0]);
      tBox(.008,.008,.09,'#e0b33c',gV(.07,tShoulderY-.12,.19),[.6,0,0]);
    }
    if(pDesign.idle==='mug'){
      const tP=tHandAt[1];
      tCyl(.036,.032,.07,'#f6f1e4',gV(tP.x,tP.y+.03,tP.z+.02));
      tCyl(.031,.031,.004,'#4a2b18',gV(tP.x,tP.y+.066,tP.z+.02));
    }
    if(pDesign.idle==='briefcase'){
      const tP=tHandAt[1];
      tBox(.06,.17,.22,'#7b4a2a',gV(tP.x+.01,tP.y-.1,tP.z));
      tBox(.065,.02,.05,'#c9a24a',gV(tP.x+.01,tP.y-.04,tP.z));
    }
    if(pDesign.idle==='camera'){
      tBox(.1,.065,.05,'#2b2b2e',gV(0,tShoulderY-.2,tFrontZ+.06));
      tCyl(.024,.024,.04,'#151517',gV(0,tShoulderY-.2,tFrontZ+.1),[Math.PI/2,0,0]);
      tBox(.11,.13,.05,'#8a5a32',gV(-.17*tW,tBase-.02,.0));
    }
  }
  // Spatula for kitchen work frames.
  if(tCook){
    const tP=tHandAt[1];
    const tTilt=tPose==='cook2'?-.9:.2;
    tBox(.018,.018,.16,'#3a2a22',gV(tP.x,tP.y+.01,tP.z+.08),[tTilt,0,0]);
    tBox(.07,.006,.08,'#c9ccc6',gV(tP.x,tP.y+(tPose==='cook2'?.09:-.01),tP.z+.18),[tTilt,0,0]);
  }
  // Carried items
  if(pCarry){
    const tY=(tHandAt[1].y+tHandAt[-1].y)/2+.025, tZ=.24;
    if(pCarry==='food'){
      tCyl(.12,.1,.015,'#f7f2e3',gV(0,tY,tZ));
      for(let tI=0;tI<3;tI++)tCyl(.055,.055,.018,tI===2?'#d9a04a':'#c8873c',gV(-.035,tY+.016+tI*.018,tZ));
      tCyl(.02,.02,.008,'#8a4a1c',gV(-.035,tY+.07,tZ));
      tCyl(.035,.035,.008,'#fbf7ee',gV(.05,tY+.012,tZ+.02));
      tSphere(.016,'#f0b52c',gV(.05,tY+.02,tZ+.02),[1,.6,1]);
      tBox(.07,.01,.016,'#a8452c',gV(.045,tY+.014,tZ-.045),[0,.3,0]);
    }else if(pCarry==='setting'){
      for(let tI=0;tI<3;tI++)tCyl(.09,.08,.012,'#f2ecdc',gV(0,tY+tI*.014,tZ));
      tBox(.12,.012,.16,'#2f5b58',gV(0,tY+.05,tZ),[0,.3,0]);
    }else{
      for(let tI=0;tI<3;tI++)tCyl(.09,.08,.012,'#e6e1d1',gV(0,tY+tI*.014,tZ));
      tSphere(.03,'#9b6a3d',gV(.02,tY+.045,tZ),[1,.4,1]);
      tCyl(.03,.026,.05,'#e8e2d0',gV(-.05,tY+.065,tZ-.02));
    }
  }
  tGroup.traverse(pNode=>{if(pNode.isMesh){pNode.castShadow=true;pNode.receiveShadow=true;}});
  return tGroup;
}
// One render per row: the eight directions stand side by side in front of an orthographic
// camera, so each row of the atlas costs a single draw instead of eight.
async function renderCharacterAtlases(pProgress){
  const tRenderer=new THREE.WebGLRenderer({antialias:false,alpha:true,preserveDrawingBuffer:true});
  tRenderer.setPixelRatio(1);
  tRenderer.setSize(gFrameW*gDirections,gFrameH,false);
  tRenderer.setClearColor(0x000000,0);
  tRenderer.outputColorSpace=THREE.SRGBColorSpace;
  tRenderer.toneMapping=THREE.ACESFilmicToneMapping;
  tRenderer.toneMappingExposure=1.15;
  const tScene=new THREE.Scene();
  tScene.add(new THREE.HemisphereLight('#fff6e6','#5e4c3c',1.45));
  const tKey=new THREE.DirectionalLight('#fff0d8',2.5);tKey.position.set(-2.2,4,3.2);tScene.add(tKey);
  const tFill=new THREE.DirectionalLight('#c4d8ff',.8);tFill.position.set(3,1.5,2.2);tScene.add(tFill);
  const tRim=new THREE.DirectionalLight('#ffffff',1.6);tRim.position.set(.5,2.2,-3.2);tScene.add(tRim);
  const tW=gSpriteView.width/2,tH=gSpriteView.height/2;
  const tCamera=new THREE.OrthographicCamera(-tW*gDirections,tW*gDirections,tH,-tH,.1,30);
  const tEl=gSpriteView.elevation;
  tCamera.position.set(0,gSpriteView.center+Math.sin(tEl)*10,Math.cos(tEl)*10);
  tCamera.lookAt(0,gSpriteView.center,0);
  const tJobs=[];
  const tAtlases=gDesigns.map(pDesign=>{
    const tRows=figureRows(pDesign);
    const tCanvas=document.createElement('canvas');
    tCanvas.width=gFrameW*gDirections;tCanvas.height=gFrameH*tRows.length;
    tRows.forEach((pRow,pIndex)=>tJobs.push([pDesign,pRow,pIndex,tCanvas]));
    return tCanvas;
  });
  let tSlice=performance.now();
  for(let tJ=0;tJ<tJobs.length;tJ++){
    const [tDesign,[tPose,tCarry],tRow,tCanvas]=tJobs[tJ];
    const tFigure=buildFigure(tDesign,tPose,tCarry);
    const tRowGroup=new THREE.Group();
    for(let tDir=0;tDir<gDirections;tDir++){
      const tCopy=tDir?tFigure.clone():tFigure;
      tCopy.rotation.y=tDir*Math.PI*2/gDirections;
      tCopy.position.x=(tDir-(gDirections-1)/2)*gSpriteView.width;
      tRowGroup.add(tCopy);
    }
    tScene.add(tRowGroup);
    tRenderer.render(tScene,tCamera);
    tCanvas.getContext('2d').drawImage(tRenderer.domElement,0,tRow*gFrameH);
    tScene.remove(tRowGroup);
    tFigure.traverse(pNode=>{if(pNode.isMesh){pNode.geometry.dispose();if(pNode.material.map)pNode.material.map.dispose();}});
    if(pProgress)pProgress((tJ+1)/tJobs.length);
    if(performance.now()-tSlice>40){await new Promise(pResolve=>setTimeout(pResolve,0));tSlice=performance.now();}
  }
  tRenderer.dispose();
  tRenderer.forceContextLoss();
  return tAtlases;
}
