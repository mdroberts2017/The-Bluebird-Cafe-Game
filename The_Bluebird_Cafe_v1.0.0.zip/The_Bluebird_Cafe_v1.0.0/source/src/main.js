// ===== Frame loop and input =====
const gVisitRoute=[[4.22,1.43],[9.85,1.6],[9.85,gAisleY],[gDoorX,gAisleY],gDoorInside,gDoorOutside,[5.8,9.45]];
function routePoint(pRoute,pT){
  const tLengths=[];let tTotal=0;
  for(let tI=1;tI<pRoute.length;tI++){const tL=Math.hypot(pRoute[tI][0]-pRoute[tI-1][0],pRoute[tI][1]-pRoute[tI-1][1]);tLengths.push(tL);tTotal+=tL;}
  let tLeft=Math.max(0,Math.min(1,pT))*tTotal;
  for(let tI=0;tI<tLengths.length;tI++){
    if(tLeft<=tLengths[tI]){const tF=tLengths[tI]?tLeft/tLengths[tI]:0;return [pRoute[tI][0]+(pRoute[tI+1][0]-pRoute[tI][0])*tF,pRoute[tI][1]+(pRoute[tI+1][1]-pRoute[tI][1])*tF];}
    tLeft-=tLengths[tI];
  }
  return pRoute[pRoute.length-1];
}
let gLastView=null;
// Sally and Bart move between kitchen stations instead of standing still.
const gStations={
  griddleA:{x:3.95,y:1.42,f:Math.PI,work:true},
  griddleB:{x:4.62,y:1.42,f:Math.PI,work:true},
  burners:{x:5.42,y:1.42,f:Math.PI,work:true},
  griddle2:{x:6.82,y:1.45,f:Math.PI,work:true},
  prep:{x:2.8,y:1.08,f:Math.PI,work:true},
  coffee:{x:2.02,y:1.08,f:Math.PI,work:false},
  fridge:{x:7.7,y:1.52,f:Math.PI,work:false},
  pass:{x:3.7,y:1.74,f:0,work:false},
  pass2:{x:6.1,y:1.74,f:0,work:false}
};
function pickStation(pOptions,pOther){
  const tChoices=pOptions.filter(([pKey])=>pKey!==pOther);
  let tRoll=Math.random()*tChoices.reduce((pSum,[,pWeight])=>pSum+pWeight,0);
  for(const [tKey,tWeight] of tChoices){tRoll-=tWeight;if(tRoll<=0)return tKey;}
  return tChoices[0][0];
}
function kitchenStep(pWorker,pDt){
  const tIndex=staff.indexOf(pWorker);
  if(tIndex>1)return false;
  const tJob=pWorker.job;
  if(tJob&&!['cook','scrub'].includes(tJob.kind))return false;
  const tOther=staff[1-tIndex].station;
  const tCooking=tJob&&tJob.kind==='cook';
  if(!pWorker.station||pWorker.dwell<=0||pWorker.stationMode!==(tJob?tJob.kind:'idle')){
    let tOptions;
    if(tIndex===1&&tCooking)tOptions=tJob.remaining<1.4?[['pass2',1]]:[['griddleA',3],['griddleB',3],['burners',2.5],['fridge',1],['prep',.6]];
    else if(tIndex===0&&tCooking)tOptions=[['griddle2',5],['fridge',1],['prep',.5]];
    else if(tJob&&tJob.kind==='scrub')tOptions=[['griddleA',1],['griddleB',1]];
    else if(tIndex===1)tOptions=[['prep',3],['griddleA',2.5],['coffee',1.5],['fridge',1.5],['pass',1.2]];
    else tOptions=[['griddleB',staff[1].job?3:1.5],['coffee',2.5],['pass',2],['prep',2],['fridge',.8]];
    pWorker.station=pickStation(tOptions,tOther);
    pWorker.stationMode=tJob?tJob.kind:'idle';
    pWorker.dwell=(tCooking?1.3:2.2)+Math.random()*(tCooking?1.4:2.4);
  }
  const tSpot=gStations[pWorker.station];
  const tDX=tSpot.x-pWorker.x,tDY=tSpot.y-pWorker.y,tDist=Math.hypot(tDX,tDY);
  const tStep=2.3*pDt;
  if(tDist>tStep){pWorker.x+=tDX/tDist*tStep;pWorker.y+=tDY/tDist*tStep;pWorker.atStation=false;pWorker.working=false;}
  else{
    pWorker.x=tSpot.x;pWorker.y=tSpot.y;pWorker.atStation=true;pWorker.dwell-=pDt;
    pWorker.stationFacing=tSpot.f;
    pWorker.working=tSpot.work;
  }
  pWorker.target=[tSpot.x,tSpot.y];
  return true;
}
function frame(now){
  const dt=Math.min(.1,(now-(last||now))/1000);
  last=now;
  if(!guidePaused)tick(dt);
  if(!guidePaused&&!modalOpen()&&shift.mode==='open'){
    for(const worker of staff){
      const job=worker.job;
      if(job?.kind==='visit'){
        const tProgress=1-job.remaining/job.duration;
        const tAlong=tProgress<.42?tProgress/.42:tProgress<.58?1:1-(tProgress-.58)/.42;
        [worker.x,worker.y]=routePoint(gVisitRoute,tAlong);
        worker.target=[worker.x,worker.y];
        worker.station=null;worker.working=false;
        continue;
      }
      if(kitchenStep(worker,dt))continue;
      worker.station=null;worker.working=false;worker.atStation=false;
      const path=workerPath(worker);
      const targetIndex=job?Math.max(0,Math.min(path.length-1,Math.floor((1-job.remaining/job.duration)*path.length))):0;
      const [x,y]=worker.target=path[targetIndex];
      const distance=Math.hypot(x-worker.x,y-worker.y);
      const fraction=distance?Math.min(1,dt*4.8/distance):0;
      worker.x+=(x-worker.x)*fraction;worker.y+=(y-worker.y)*fraction;
    }
  }
  else if(shift.mode==='idle'&&!guidePaused&&!careerDialogOpen()){kitchenStep(staff[0],dt);kitchenStep(staff[1],dt);}
  if(gLastView!==view){resetPan();gLastView=view;}
  const tFrozen=guidePaused||modalOpen()||shift.mode==='paused';
  render3D(tFrozen?0:dt);
  uiElapsed+=dt;
  if(uiElapsed>.16){refresh();uiElapsed=0;}
  requestAnimationFrame(frame);
}
$('start').onclick=toggle;
$('street').onclick=()=>changeView('street');
$('room').onclick=()=>changeView('room');
$('boost').onclick=visitQueue;
$('help').onclick=()=>{guidePaused=true;$('guide').showModal();};
$('about').onclick=()=>{guidePaused=true;$('aboutBox').showModal();};
$('aboutBox').onclose=()=>{guidePaused=false;};
installMusicUI();
installSettingsUI();
const gDesktopCheck=()=>{$('desktopNote').hidden=window.innerWidth>=900;};gDesktopCheck();window.addEventListener('resize',gDesktopCheck);
$('guide').onclose=()=>{guidePaused=false;};
$('again').onclick=()=>{setTimeout(()=>{reset();showPaper();},0);};
$('coffee').onclick=freeCoffee;
$('meal').onclick=staffMeal;
installCareerUI();
document.addEventListener('keydown',event=>{
  if(careerDialogOpen()||modalOpen()||event.ctrlKey||event.altKey||event.metaKey)return;
  if(event.repeat&&!event.key.startsWith('Arrow'))return;
  const tKey=event.key.toLowerCase();
  if(event.target&&['INPUT','SELECT','TEXTAREA'].includes(event.target.tagName))return;
  // Shift+1/2/3 answers the top event card.
  if(event.shiftKey&&/^Digit[1-3]$/.test(event.code)){
    const tCard=shift.events[0];
    if(tCard&&tCard.options[Number(event.code.slice(5))-1]){event.preventDefault();resolveEvent(tCard.id,Number(event.code.slice(5))-1);}
    return;
  }
  const tPan={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[event.key];
  if(tPan){event.preventDefault();panCamera(tPan[0],tPan[1]);return;}
  if(event.key==='Home'){resetPan();gCam.zoom=1;return;}
  if(/^[1-7]$/.test(event.key))tableAction(Number(event.key)-1);
  if(tKey==='v')changeView(view==='street'?'room':'street');
  if(tKey==='p'&&['open','paused'].includes(shift.mode))toggle();
  if(tKey==='c')freeCoffee();
  if(tKey==='m')staffMeal();
  if(tKey==='q')turnCamera(-1);
  if(tKey==='e')turnCamera(1);
  if(tKey==='+'||tKey==='=')zoomCamera(1/1.18);
  if(tKey==='-'||tKey==='_')zoomCamera(1.18);
});
init3D();
installCameraControls();
reset();
showPaper();
requestAnimationFrame(frame);
