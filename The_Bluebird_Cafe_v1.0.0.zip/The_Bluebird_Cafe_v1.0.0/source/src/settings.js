// ===== Settings: sound, display and career tools (saved in this browser) =====
const gSettingsStore='bluebird-settings-v2';
const gSettings={music:false,musicVolume:.55,sfx:true,sfxVolume:.6,reducedMotion:false,quality:'medium'};
(function loadSettings(){
  try{
    const tPrefersCalm=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    gSettings.reducedMotion=!!tPrefersCalm;
    const tOld=JSON.parse(localStorage.getItem('bluebird-settings-v1')||'null');
    if(tOld){gSettings.music=!!tOld.music;if(typeof tOld.volume==='number')gSettings.musicVolume=tOld.volume;}
    const tSaved=JSON.parse(localStorage.getItem(gSettingsStore)||'null');
    if(tSaved&&typeof tSaved==='object'){
      if(typeof tSaved.music==='boolean')gSettings.music=tSaved.music;
      if(typeof tSaved.sfx==='boolean')gSettings.sfx=tSaved.sfx;
      if(typeof tSaved.reducedMotion==='boolean')gSettings.reducedMotion=tSaved.reducedMotion;
      for(const tKey of ['musicVolume','sfxVolume'])if(Number.isFinite(tSaved[tKey]))gSettings[tKey]=Math.min(1,Math.max(0,tSaved[tKey]));
      if(['low','medium','high'].includes(tSaved.quality))gSettings.quality=tSaved.quality;
    }
  }catch{}
})();
function saveSettings(){try{localStorage.setItem(gSettingsStore,JSON.stringify(gSettings));}catch{}}
const gQuality={low:{ratio:1,shadow:1024},medium:{ratio:1.5,shadow:2048},high:{ratio:2,shadow:2048}};
function applyQuality(){
  if(typeof gRenderer==='undefined'||!gRenderer)return;
  const tSize=gQuality[gSettings.quality].shadow;
  if(gSun.shadow.mapSize.x!==tSize){
    gSun.shadow.mapSize.set(tSize,tSize);
    if(gSun.shadow.map){gSun.shadow.map.dispose();gSun.shadow.map=null;}
  }
  gShadowDirty=true;
  resizeRenderer(true);
}
function applyMotion(){document.body.classList.toggle('calm',gSettings.reducedMotion);}
function renderSettings(){
  $('setMusic').checked=gSettings.music;
  $('setMusicVolume').value=String(Math.round(gSettings.musicVolume*100));
  $('setSfx').checked=gSettings.sfx;
  $('setSfxVolume').value=String(Math.round(gSettings.sfxVolume*100));
  $('setMotion').checked=gSettings.reducedMotion;
  $('setQuality').value=gSettings.quality;
  $('careerNote').textContent='Day '+gCareer.day+' · Bank $'+gCareer.bank.toLocaleString()+' · Reputation '+gCareer.rep+'/100';
  $('resetCareer').textContent='Reset career…';gResetArmed=false;
  $('importNote').textContent='';
}
function exportCareer(){
  const tData={app:'The Bluebird Cafe',saveVersion:gSaveVersion,exported:new Date().toISOString(),career:gCareer};
  const tBlob=new Blob([JSON.stringify(tData,null,2)],{type:'application/json'});
  const tLink=document.createElement('a');
  tLink.href=URL.createObjectURL(tBlob);
  tLink.download='bluebird-career-day'+gCareer.day+'.json';
  document.body.append(tLink);tLink.click();tLink.remove();
  setTimeout(()=>URL.revokeObjectURL(tLink.href),2000);
  $('importNote').textContent='Career exported.';
}
function importCareer(pFile){
  const tReader=new FileReader();
  tReader.onload=()=>{
    try{
      const tData=JSON.parse(String(tReader.result));
      if(!tData||tData.app!=='The Bluebird Cafe'||!tData.career)throw new Error('not a Bluebird Cafe career file');
      const tCareer=sanitizeCareer(tData.career);
      if(!tCareer)throw new Error('the career data is incomplete');
      if(shift&&shift.mode==='open'){$('importNote').textContent='Finish or pause service before importing.';return;}
      gCareer=tCareer;saveCareer();gToday=dayInfo(gCareer.day);
      reset();renderSettings();
      $('importNote').textContent='Imported: day '+gCareer.day+', bank $'+gCareer.bank.toLocaleString()+'.';
    }catch(pError){$('importNote').textContent='Could not import that file: '+pError.message+'.';}
  };
  tReader.readAsText(pFile);
}
function installSettingsUI(){
  applyMotion();
  $('settings').onclick=()=>{guidePaused=true;renderSettings();$('settingsBox').showModal();};
  $('settingsBox').onclose=()=>{guidePaused=false;};
  $('setMusic').onchange=pEvent=>setMusicEnabled(pEvent.target.checked);
  $('setMusicVolume').oninput=pEvent=>setMusicVolume(Number(pEvent.target.value)/100);
  $('setSfx').onchange=pEvent=>{gSettings.sfx=pEvent.target.checked;saveSettings();if(gSettings.sfx)sfx('chime');};
  $('setSfxVolume').oninput=pEvent=>{gSettings.sfxVolume=Number(pEvent.target.value)/100;saveSettings();applySfxVolume();};
  $('setSfxVolume').onchange=()=>sfx('chime');
  $('setMotion').onchange=pEvent=>{gSettings.reducedMotion=pEvent.target.checked;saveSettings();applyMotion();};
  $('setQuality').onchange=pEvent=>{gSettings.quality=pEvent.target.value;saveSettings();applyQuality();};
  $('exportCareer').onclick=exportCareer;
  $('importCareerButton').onclick=()=>$('importCareer').click();
  $('importCareer').onchange=pEvent=>{const tFile=pEvent.target.files[0];if(tFile)importCareer(tFile);pEvent.target.value='';};
  $('resetCareer').onclick=()=>{
    if(shift&&shift.mode==='open'){$('importNote').textContent='Finish or pause service before resetting.';return;}
    if(!gResetArmed){gResetArmed=true;$('resetCareer').textContent='Click again to erase your career';return;}
    gCareer=freshCareer();saveCareer();gToday=dayInfo(gCareer.day);
    $('settingsBox').close();reset();showPaper();
  };
}
