// ===== In-shift events: line tools, crew traits, table visits, grease fires, inspector prep =====
let gEventSeq=0, gRenderedEvents=-1;
const gTraits={
  Sally:{trait:'Charming',note:'Table visits and queue visits work wonders'},
  Bart:{trait:'Seasoned',note:'Cooks 15% faster; the griddle gets greasy'},
  Rita:{trait:'Chatty',note:'Slower at tables, +15% tips'},
  Jane:{trait:'Speedy',note:'25% faster; takes “five-minute” breaks'}
};
function pushEvent(pCard){
  pCard.id=++gEventSeq;
  pCard.expires=shift.time+(pCard.timeout||12);
  pCard.duration=pCard.timeout||12;
  shift.events.push(pCard);
  shift.eventsVersion++;
  say(pCard.title);
  sfx(pCard.kind==='fire'?'alarm':pCard.kind==='band'?'sting':'chime');
  refresh();
}
function resolveEvent(pId,pIndex){
  const tIndex=shift.events.findIndex(pCard=>pCard.id===pId);
  if(tIndex<0)return;
  const [tCard]=shift.events.splice(tIndex,1);
  shift.eventsVersion++;
  const tOption=tCard.options[pIndex];
  if(tOption){const tMessage=tOption.act();if(tMessage)say(tMessage);}
  refresh();
}
function tickEvents(pDt){
  for(const tCard of [...shift.events])if(shift.time>=tCard.expires)resolveEvent(tCard.id,tCard.defaultIndex??-1);
  for(const tPlan of shift.schedule){
    if(tPlan.done||shift.time<tPlan.at)continue;
    tPlan.done=true;
    triggerEvent(tPlan.kind);
  }
  if(shift.band>0){shift.band=Math.max(0,shift.band-pDt);if(!shift.band)say('The brass band packs up and second-lines down the block.');}
  shift.coffeeGlow=Math.max(0,shift.coffeeGlow-pDt);
  shift.coffeeCooldown=Math.max(0,shift.coffeeCooldown-pDt);
  shift.mealCooldown=Math.max(0,shift.mealCooldown-pDt);
  shift.flambe=Math.max(0,shift.flambe-pDt);
  // Jane's deferred break starts the moment she is free.
  const tJane=staff[3];
  if(shift.janeBreakPending&&!tJane.job){shift.janeBreakPending=false;tJane.job={kind:'break',remaining:12,duration:12};say('Jane is on her “five-minute” break.');}
  // Grease fires.
  if(shift.grease>=100&&!shift.fire){
    shift.fire=true;
    pushEvent({kind:'fire',title:'Grease fire on the griddle!',text:'Bart insists it is decorative. The flames disagree.',timeout:8,defaultIndex:0,options:[
      {label:'Extinguish it',act:()=>{shift.fire=false;shift.grease=20;delayBart(4);return 'Bart smothers the fire, mourning his “seasoning.”';}},
      {label:'Let it cook',act:()=>{
        shift.fire=false;
        if(Math.random()<.6){shift.grease=55;shift.flambe=25;return 'Flambé! Plates go out with a flourish. Tips are up for a bit.';}
        shift.grease=30;shift.bigFire=true;shift.karma-=1;delayBart(8);return 'That was not decorative. Bart loses 8 seconds and his eyebrows.';
      }}
    ]});
  }
}
function delayBart(pSeconds){
  const tBart=staff[1];
  if(tBart.job)tBart.job.remaining+=pSeconds;
  else tBart.job={kind:'scrub',remaining:pSeconds,duration:pSeconds};
}
function triggerEvent(pKind){
  if(pKind==='band'){
    pushEvent({kind:'band',title:'A second-line brass band strikes up',text:'Umbrellas and handkerchiefs come out. The line loves it; Bart can’t hear the tickets over the tuba.',timeout:10,defaultIndex:0,options:[
      {label:'Let them play',act:()=>{shift.band=shift.day.kind==='jazzfest'?40:28;shift.bandPlayed=true;return 'The band strikes up “Saints.” The line sways; order mix-ups are possible.';}},
      {label:'Tip them $5 to move on',act:()=>{shift.cash-=5;return 'The band takes your $5 and plays one more song anyway, on the way out.';}}
    ]});
  }else if(pKind==='cutter'){
    if(shift.line.length<2){return;}
    pushEvent({kind:'cutter',title:'Mr. Boudreaux cuts the line',text:'“I’ve been coming here since Sally was in diapers.” The people behind him are not amused.',timeout:10,defaultIndex:0,options:[
      {label:'Let him cut',act:()=>{
        const tGuest=party(900+shift.next);tGuest.size=1;tGuest.leadSprite=4;tGuest.regular=true;
        shift.line.unshift(tGuest);
        for(const tOther of shift.line.slice(1))tOther.patience-=6;
        shift.karma+=2;return 'Mr. Boudreaux takes his place at the front. The line grumbles.';
      }},
      {label:'Send him to the back',act:()=>{
        const tGuest=party(900+shift.next);tGuest.size=1;tGuest.leadSprite=4;tGuest.regular=true;
        shift.line.push(tGuest);shift.karma-=1;return 'Mr. Boudreaux shuffles to the back, muttering about 1987.';
      }}
    ]});
  }else if(pKind==='janeBreak'){
    pushEvent({kind:'break',title:'Jane needs a five-minute break',text:'It will not be five minutes.',timeout:10,defaultIndex:0,options:[
      {label:'Let her go',act:()=>{shift.janeBreakPending=true;staff[3].energy=Math.min(100,staff[3].energy+35);return 'Jane will take her break as soon as her hands are free.';}},
      {label:'Ask her to wait',act:()=>{staff[3].energy=Math.max(0,staff[3].energy-20);return 'Jane sighs audibly and keeps going. Her energy drops.';}}
    ]});
  }else if(pKind==='inspectorWarning'){
    const tCostume=shift.day.costume?' He is '+shift.day.costume+'.':'';
    pushEvent({kind:'inspector',title:'The inspector just parked on Magazine Street!',text:'You have a few seconds before he walks in.'+tCostume,timeout:11,defaultIndex:2,options:[
      {label:'Scrub the griddle',act:()=>{shift.grease=Math.max(0,shift.grease-70);delayBart(4);return 'Bart hides his “seasoned” spatula and scrubs, under protest.';}},
      {label:'Beignets ($10)',act:()=>{shift.cash-=10;shift.bribe=Math.random()<.5?1:-1;return shift.bribe>0?'The inspector accepts a beignet “for quality control.”':'The inspector is offended. He takes the beignets anyway.';}},
      {label:'Act natural',act:()=>'Everyone acts natural. Bart whistles.'}
    ]});
  }
}
// Line tools
function freeCoffee(){
  if(shift.mode!=='open'||shift.coffeeCooldown>0||!shift.line.length)return;
  const tCost=owns('urn')?0:shift.line.length*2;
  shift.cash-=tCost;
  for(const tGuest of shift.line)tGuest.patience=Math.min(tGuest.max,tGuest.patience+20);
  shift.coffeeCooldown=35;shift.coffeeGlow=4;shift.karma+=1;
  say('Free chicory coffee for the line'+(tCost?' ($'+tCost+')':' from the urn')+'. Patience restored.');
  refresh();
}
function staffMeal(){
  if(shift.mode!=='open'||shift.mealCooldown>0)return;
  shift.cash-=8;shift.mealCooldown=60;
  for(const tWorker of staff){tWorker.energy=Math.min(100,tWorker.energy+40);tWorker.tiredNoted=false;}
  say('Staff meal: grits all around ($8). The crew’s energy is up.');
  refresh();
}
// Job speed from traits and energy.
function jobRate(pWorker,pJob){
  let tRate=1;
  if(pWorker.name==='Bart'&&pJob.kind==='cook')tRate*=1.15;
  if(pWorker.name==='Rita'&&['order','ready'].includes(pJob.kind))tRate*=.83;
  if(pWorker.name==='Jane'&&['order','ready','dirty'].includes(pJob.kind))tRate*=1.25;
  if(['break','scrub','visit'].includes(pJob.kind))return 1;
  if(pWorker.energy<15)tRate*=.6;else if(pWorker.energy<35)tRate*=.78;
  return tRate;
}
function drainEnergy(pWorker,pDt){
  const tJob=pWorker.job;
  if(tJob&&tJob.kind==='break')return;
  const tDrain=(tJob?.6:.06)*(owns('shoes')?.65:1)*(pWorker.name==='Sally'?.85:1);
  pWorker.energy=Math.max(0,pWorker.energy-tDrain*pDt);
  if(pWorker.energy<30&&!pWorker.tiredNoted){pWorker.tiredNoted=true;say(pWorker.name+' is running on fumes. A staff meal would help.');}
}
// Sally's table visits.
function chatOutcome(pTable,pIndex){
  const tParty=pTable.party;
  if(!tParty)return 'The table had already left.';
  const tName=seatName(pIndex).toLowerCase();
  const tLift=pAmount=>{tParty.mood=Math.min(1.3,tParty.mood+pAmount);};
  if(tParty.critic){tLift(.3);return 'Sally chats with the critic at '+tName+'. The critic writes something down. Sally pretends not to look.';}
  if(Math.random()<.18){tLift(.15);shift.repBonus+=1;pTable.timer+=4;return 'A food blogger at '+tName+' photographs every bite. Their eggs go cold, but the post goes viral.';}
  switch(tParty.leadSprite){
    case 4:tLift(.25);shift.karma+=2;return tParty.regular?'Mr. Boudreaux tells Sally about 1987 again. She tops off his coffee. Karma up.':'The regular at '+tName+' has nursed one cup since 1987. Sally tops it off anyway. Karma up.';
    case 8:tLift(.2);shift.karma+=2;for(const tGuest of shift.line)tGuest.patience=Math.min(tGuest.max,tGuest.patience+5);return 'Officer Broussard gets his coffee on the house, as always. The block feels safer; the line relaxes.';
    case 6:tLift(.4);return 'A tourist asks for “authentic Cajun grits.” Sally adds hot sauce and a good story. Expect a big tip.';
    case 5:tLift(.25);return 'A man in a suit asks for the Wi-Fi password. Sally tells him it is “grits4ever.” He is delighted.';
    case 7:tLift(.25);shift.grease+=8;return 'A neighbor at '+tName+' asks if Bart is single. Bart blushes; the griddle hisses.';
  }
  tLift(.25);return 'Sally checks on '+tName+'. Everyone is happy.';
}
function renderEvents(){
  if(gRenderedEvents===shift.eventsVersion){
    for(const tBar of $('events').querySelectorAll('[data-event]')){
      const tCard=shift.events.find(pCard=>pCard.id===Number(tBar.dataset.event));
      if(tCard)tBar.style.width=Math.max(0,100*(tCard.expires-shift.time)/tCard.duration)+'%';
    }
    return;
  }
  gRenderedEvents=shift.eventsVersion;
  $('events').replaceChildren(...shift.events.map(pCard=>{
    const tEl=document.createElement('div');tEl.className='event event-'+pCard.kind;
    tEl.setAttribute('role','group');tEl.setAttribute('aria-label',pCard.title);
    tEl.innerHTML='<strong></strong><p></p><div class="eventActions"></div><i class="timer"><i data-event="'+pCard.id+'"></i></i>';
    tEl.querySelector('strong').textContent=pCard.title;
    tEl.querySelector('p').textContent=pCard.text;
    pCard.options.forEach((pOption,pIndex)=>{
      const tButton=document.createElement('button');tButton.className='button'+(pIndex===pCard.defaultIndex?' primary':'');
      tButton.textContent=pOption.label;
      if(pCard===shift.events[0]){const tKbd=document.createElement('kbd');tKbd.textContent='⇧'+(pIndex+1);tButton.append(tKbd);tButton.setAttribute('aria-keyshortcuts','Shift+'+(pIndex+1));}tButton.onclick=()=>resolveEvent(pCard.id,pIndex);
      tEl.querySelector('.eventActions').append(tButton);
    });
    return tEl;
  }));
  $('events').hidden=!shift.events.length;
}
