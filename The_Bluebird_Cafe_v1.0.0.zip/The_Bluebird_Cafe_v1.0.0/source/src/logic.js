'use strict';
const $ = id => document.getElementById(id);
const canvas = $('art');
const diningTables=5;
const tablePositions = [[2,4.05],[5.1,4.25],[8.3,4.15],[3,6.75],[7.15,6.75],[3.2,3.3],[6.55,3.3]];
const isCounter=index=>index>=diningTables;
const seatName=index=>isCounter(index)?'Counter '+(index-diningTables+1):'Table '+(index+1);
const seatCode=index=>isCounter(index)?'C'+(index-diningTables+1):String(index+1);
const staff = [
  {name:'Sally', role:'Owner & chef', color:'#bd6748',home:[4.22,1.43]},
  {name:'Bart', role:'Cook', color:'#356577',home:[5.44,1.43]},
  {name:'Rita', role:'Waitress', color:'#426f63',home:[1.15,5]},
  {name:'Jane', role:'Waitress', color:'#a3585b',home:[9.35,5]}
];
for(const worker of staff){worker.energy=100;}
const menu = [
  {name:'Eggs & grits',price:9,cook:7,description:'Two eggs with creamy stone-ground grits'},
  {name:'Pain perdu',price:10,cook:8,description:'New Orleans French toast with cane syrup'},
  {name:'Bluebird breakfast',price:13,cook:11,description:'Eggs, sausage, grits and a buttermilk biscuit'},
  {name:'Biscuits & gravy',price:11,cook:9,description:'Buttermilk biscuits with peppered sausage gravy'},
  {name:'Grillades & grits',price:14,cook:12,description:'Braised beef in Creole gravy over stone-ground grits'},
  {name:'Red beans & rice',price:8,cook:5,description:'Monday special · smoked sausage, buttered rice',special:'redbeans'}
];
const dishAvailable=dish=>!dish.special||(shift&&shift.day.special===dish.special);
const restroomSign=new Image();
restroomSign.src='%%RESTROOM%%';
const policeOfficerSprite=8;
const stateLabels = {empty:'Seat party', seated:'Reading menus', order:'Open menu', queued:'Ticket queued', cooking:'Cooking', ready:'Serve plates', eating:'Eating', pay:'Ring up', dirty:'Clear table'};
const jobLabels={cook:'Cooking',order:'Taking order',ready:'Serving',pay:'Ringing up',dirty:'Clearing',chat:'Visiting table',break:'On a “five-minute” break',scrub:'Scrubbing the griddle'};
let orderTable=null, checkout=null;
let shift, view, guidePaused = false, last = 0, uiElapsed = 0;
const freshTable = () => ({state:'empty',party:null,timer:0,job:null,pending:false});
function party(id){
  const leadSprite=id%7===3?policeOfficerSprite:4+id%4;
  const day=shift?.day||gToday;
  const expectations=1-(gCareer.rep-50)/400;
  const max=Math.round((48+(id*7)%19)*day.patience*expectations+Math.min(10,Math.max(0,gCareer.karma)*.2));
  return {id,leadSprite,size:id%3===1?1:2+(id%3),patience:max,max,mood:1,items:[]};
}
function reset(open=false){
  const day=gToday;
  shift=null;
  const closing=day.closing;
  const inspectionAt=open&&(day.inspector||Math.random()<.45)?Math.min(closing-30,70+Math.random()*48):Infinity;
  shift={mode:open?'open':'idle',day,closing,arrivals:buildArrivals(day),time:0,cash:0,tips:0,served:0,lost:0,next:0,line:[],tables:tablePositions.map(freshTable),visitCooldown:0,ticket:0,inspectionAt,inspector:null,grade:null,inspectionFindings:null,
    events:[],eventsVersion:0,sales:0,pending:[],schedule:buildSchedule(day),band:0,bandPlayed:false,grease:10,fire:false,bigFire:false,flambe:0,bribe:0,karma:0,repBonus:0,coffeeCooldown:0,coffeeGlow:0,mealCooldown:0,janeBreakPending:false,moodSum:0,paidParties:0,criticResult:null,criticIndex:day.critic?2+Math.floor(Math.random()*6):-1};
  const opening=day.kind==='mardigras'?5:3;
  for(let i=0;i<opening;i++)shift.line.push(party(i));
  if(inspectionAt<Infinity)shift.schedule.push({at:Math.max(4,inspectionAt-12),kind:'inspectorWarning'});
  view='street';
  for(const worker of staff){worker.job=null;worker.target=worker.home;worker.x=worker.home[0];worker.y=worker.home[1];worker.energy=100;worker.tiredNoted=false;}
  say(open?'Seat the first party to begin service.':shift.line.length+' parties are waiting. Open the café to start breakfast service.');
  if(typeof applyDayTo3D==='function')applyDayTo3D();
  refresh();
}
function say(message){$('message').textContent=message;}
function changeView(next){view=next;refresh();}
function modalOpen(){return $('menuInset').open||$('billInset').open||$('inspectionReport').open;}
function careerDialogOpen(){return $('paper').open||$('shop').open||$('report').open||$('guide').open||$('aboutBox').open||$('settingsBox').open;}
function freeWaitress(){return staff.slice(2).find(worker=>!worker.job);}
// canStart: the staff needed for this action are free right now.
function canStart(table){
  const counter=isCounter(shift.tables.indexOf(table));
  if(shift.mode!=='open'||table.job)return false;
  if(table.state==='empty')return counter?shift.line.some(guest=>guest.size===1):!!shift.line.length;
  if(table.state==='eating')return !table.visited&&!staff[0].job;
  if(table.state==='pay'||counter)return !staff[0].job&&['order','ready','pay','dirty'].includes(table.state);
  return ['order','ready','dirty'].includes(table.state)&&!!freeWaitress();
}
// canAct: the player can ask for this action now. If the staff are busy it is queued and
// happens automatically as soon as someone is free.
function canAct(table){
  if(shift.mode!=='open'||table.job||table.pending)return false;
  if(table.state==='empty'||table.state==='eating')return canStart(table)||table.state==='eating'&&!table.visited;
  return ['order','ready','dirty','pay'].includes(table.state);
}
const actionNames={order:'take the order',ready:'serve the plates',dirty:'clear the table',pay:'ring up the bill',eating:'visit the table'};
function workerSummary(list){
  return list.map(worker=>{
    const job=worker.job;
    if(!job)return worker.name+' is free';
    const where=job.index===undefined?'':' '+(isCounter(job.index)?seatCode(job.index):'T'+seatCode(job.index));
    return worker.name+' is '+({cook:'cooking',order:'taking an order',ready:'serving',pay:'at the register',dirty:'clearing',chat:'visiting a table',break:'on a break',visit:'out with the line',scrub:'scrubbing'}[job.kind]||'busy')+where;
  }).join(', ');
}
function whoDoes(index){
  const table=shift.tables[index];
  if(table.state==='pay'||table.state==='eating'||isCounter(index))return [staff[0]];
  return staff.slice(2);
}
function blockReason(index){
  const table=shift.tables[index];
  if(shift.mode==='idle')return 'Open the café to start service.';
  if(shift.mode==='paused')return 'Service is paused.';
  if(shift.mode==='complete')return 'The shift is over.';
  if(table.pending)return 'Queued: '+actionNames[table.state]+' for '+seatName(index).toLowerCase()+' is #'+(shift.pending.indexOf(index)+1)+' in line. '+workerSummary(whoDoes(index))+'.';
  if(table.job)return seatName(index)+': already underway.';
  switch(table.state){
    case 'empty':return isCounter(index)?'No single diners are waiting for the counter.':'Nobody is waiting in line.';
    case 'seated':return seatName(index)+' is still reading the menu.';
    case 'queued':{
      const queue=shift.tables.filter(t=>t.state==='queued').sort((a,b)=>a.ticket-b.ticket);
      const ahead=queue.indexOf(table);
      return seatName(index)+'’s ticket is waiting in the kitchen'+(ahead>0?', with '+ahead+' ticket'+(ahead>1?'s':'')+' ahead of it.':', next up.')+' '+workerSummary([staff[1]])+'.';
    }
    case 'cooking':return 'The kitchen is cooking '+seatName(index).toLowerCase()+'’s order.';
    case 'eating':return table.visited?'Sally already visited. They will be ready to pay soon.':'Sally is busy. '+workerSummary([staff[0]])+'.';
  }
  return '';
}
function startAction(index){
  const table=shift.tables[index];
  if(table.state==='eating'){
    table.visited=true;
    table.job=staff[0].job={kind:'chat',index,remaining:3,duration:3};
    say('Sally heads over to visit '+seatName(index).toLowerCase()+'.');
  }else if(table.state==='pay'){
    table.job=staff[0].job={kind:'pay',index,remaining:2.2,duration:2.2};
    say('Sally is heading to the register for '+seatName(index).toLowerCase()+'.');
  }else dispatchService(index);
}
function queueAction(index){
  const table=shift.tables[index];
  table.pending=true;shift.pending.push(index);
  say('Queued: '+actionNames[table.state]+' for '+seatName(index).toLowerCase()+'. '+workerSummary(whoDoes(index))+'. It will start as soon as someone is free.');
}
// Runs queued actions in the order they were asked for, as staff free up.
function processPending(){
  for(const index of [...shift.pending]){
    const table=shift.tables[index];
    const stillWanted=table.pending&&!table.job&&['order','ready','dirty','pay','eating'].includes(table.state)&&!(table.state==='eating'&&table.visited)&&!(table.state==='order'&&table.party.items.length!==table.party.size);
    if(!stillWanted){table.pending=false;shift.pending.splice(shift.pending.indexOf(index),1);continue;}
    if(canStart(table)){
      table.pending=false;shift.pending.splice(shift.pending.indexOf(index),1);
      startAction(index);
      if(modalOpen())return;
    }
  }
}
function tableAction(index){
  const table=shift.tables[index];
  if(modalOpen())return;
  if(!canAct(table)){const reason=blockReason(index);if(reason)say(reason);flashPin(index);return;}
  view='room';
  if(table.state==='empty'){
    table.party=isCounter(index)?shift.line.splice(shift.line.findIndex(guest=>guest.size===1),1)[0]:shift.line.shift();
    table.state='seated';
    table.timer=3.2;
    say(seatName(index)+' is seated. Give them a moment to read the menu.');
    sfx('door');
  }else if(table.state==='order'){
    // The menu always opens; if nobody is free to take it, the ticket is queued when you send it.
    orderTable=index;
    updateMenu();
    $('menuInset').showModal();
  }else if(canStart(table))startAction(index);
  else queueAction(index);
  refresh();
}
function flashPin(index){
  for(const el of [pins[index],rows[index]]){el.classList.remove('nudge');void el.offsetWidth;el.classList.add('nudge');}
}
function dispatchService(index){
  const table=shift.tables[index];
  const worker=isCounter(index)?staff[0]:freeWaitress();
  const duration={order:2.4,ready:3.2,dirty:3}[table.state];
  const job={index,kind:table.state,remaining:duration,duration};
  table.job=worker.job=job;
  if(worker.name==='Rita'&&job.kind!=='dirty')table.chatty=true;
  say(worker.name+' · '+({order:'taking the order',ready:'bringing plates',dirty:'clearing dishes'}[job.kind])+' for '+seatName(index).toLowerCase()+'.');
}
const menuButtons=menu.map((dish,index)=>{
  const button=document.createElement('button');
  button.className='menuItem';
  button.innerHTML='<strong></strong><small></small><b></b>';
  button.children[1].textContent=dish.description;
  button.title='Add one '+dish.name;
  button.onclick=()=>{
    const party=shift.tables[orderTable].party;
    if(party.items.length>=party.size)return;
    party.items.push(index);
    updateMenu();
    if(party.items.length===party.size)$('sendOrder').focus();
  };
  $('menuItems').append(button);
  return button;
});
function updateMenu(){
  const party=shift.tables[orderTable].party;
  $('orderPrompt').textContent=seatName(orderTable)+' · '+party.items.length+' of '+party.size+' entrées selected. Select a dish again to add another.';
  menuButtons.forEach((button,index)=>{
    const count=party.items.filter(item=>item===index).length;
    const dish=menu[index];
    button.children[0].textContent=dish.name;
    button.children[2].textContent='$'+dish.price+(count?'  ·  ×'+count:'  ·  +');
    button.dataset.selected=String(count>0);
    button.setAttribute('aria-label','Add one '+dish.name+', $'+dish.price+', '+count+' selected');
    button.hidden=!dishAvailable(dish);
    button.disabled=button.hidden||party.items.length>=party.size;
  });
  $('sendOrder').disabled=party.items.length!==party.size;
  $('undoOrder').disabled=!party.items.length;
}
$('undoOrder').onclick=()=>{
  const items=shift.tables[orderTable].party.items;
  const index=items.pop();
  updateMenu();
  menuButtons[index].focus();
};
$('closeMenu').onclick=()=>$('menuInset').close();
$('menuInset').onclose=()=>{
  orderTable=null;
  refresh();
};
$('sendOrder').onclick=()=>{
  if(orderTable===null)return;
  const table=shift.tables[orderTable];
  if(table.job||table.pending||table.party.items.length!==table.party.size)return;
  if(canStart(table))dispatchService(orderTable);
  else queueAction(orderTable);
  $('menuInset').close();
  refresh();
};
function visitQueue(){
  const sally=staff[0];
  if(shift.mode!=='open'||shift.visitCooldown>0||sally.job||!shift.line.length)return;
  sally.job={kind:'visit',remaining:5,duration:5,returnView:view};
  shift.visitCooldown=27;
  view='street';
  say('Sally steps outside: “Where y’at, baby? Won’t be long now.”');
  refresh();
}
function showBill(job){
  const table=shift.tables[job.index];
  if(!table.party){table.job=null;staff[0].job=null;return;}
  const lines=[];
  const subtotal=table.party.items.reduce((sum,index)=>sum+menu[index].price,0);
  const bonus=shift.day.tipBonus+(table.chatty?.15:0)+(gCareer.rep-50)/400+(shift.flambe>0?.1:0);
  const tip=Math.max(0,Math.round(subtotal*.25*table.party.mood*(1+bonus)));
  checkout={index:job.index,subtotal,tip,paid:false};
  $('billTable').textContent=seatName(job.index)+' · '+table.party.size+' guests';
  menu.forEach((dish,index)=>{
    const count=table.party.items.filter(item=>item===index).length;
    if(count)lines.push([count+' × '+dish.name,dish.price*count]);
  });
  lines.push(['Subtotal',subtotal],['Tip',tip],['Total',subtotal+tip]);
  $('billLines').replaceChildren(...lines.flatMap(([name,amount])=>{
    const label=document.createElement('dt'),value=document.createElement('dd');
    label.textContent=name;value.textContent='$'+amount.toFixed(2);
    if(name==='Total')label.className=value.className='total';
    return [label,value];
  }));
  $('billInset').showModal();
}
$('collectBill').onclick=()=>{
  if(!checkout||checkout.paid)return;
  checkout.paid=true;
  shift.cash+=checkout.subtotal+checkout.tip;shift.sales+=checkout.subtotal;
  shift.tips+=checkout.tip;shift.served++;
  const table=shift.tables[checkout.index];
  shift.moodSum+=Math.min(1,table.party.mood);shift.paidParties++;
  let note='Sally collected payment for '+seatName(checkout.index).toLowerCase()+'.';
  if(table.party.critic){shift.criticResult=table.party.mood>=.7?'rave':'pan';note=shift.criticResult==='rave'?'The critic leaves smiling and humming. That’s a good sign.':'The critic leaves, frowning at a biscuit. Uh-oh.';}
  table.state='dirty';table.dirtySince=shift.time;table.party=null;table.job=null;staff[0].job=null;
  say(note);
  sfx('register');
  $('billInset').close();
};
$('closeBill').onclick=()=>$('billInset').close();
$('billInset').onclose=()=>{
  if(!checkout)return;
  shift.tables[checkout.index].job=null;
  staff[0].job=null;
  if(!checkout.paid)say('Payment is still due at '+seatName(checkout.index).toLowerCase()+'.');
  checkout=null;
  refresh();
};
function finish(worker,job){
  if(job.kind==='pay'){showBill(job);return;}
  worker.job=null;
  if(job.kind==='visit'){
    for(const guest of shift.line)guest.patience=Math.min(guest.max,guest.patience+15);
    if(view==='street')view=job.returnView;
    say('Sally greeted the queue and restored up to 15 seconds of patience.');
    return;
  }
  if(job.kind==='break'){worker.energy=Math.min(100,worker.energy+45);worker.tiredNoted=false;say('Jane is back from her break. It was fourteen minutes. She looks great.');return;}
  if(job.kind==='scrub')return;
  const table=shift.tables[job.index];
  table.job=null;
  switch(job.kind){
    case 'chat':
      say(chatOutcome(table,job.index));break;
    case 'order':
      table.state='queued';table.ticket=++shift.ticket;
      if(shift.band>0&&Math.random()<.3){table.mixup=true;}
      break;
    case 'cook':
      table.state='ready';
      shift.grease+=owns('hood')?3.5:6;
      if(table.mixup){table.mixup=false;}
      break;
    case 'ready':
      table.state='eating';table.timer=8+table.party.size;break;
    case 'dirty':
      shift.tables[job.index]=freshTable();sfx('plates');break;
  }
}
const inspectorRoute=[[5.15,9.3],[5.15,5.45],[.6,5.2],[.46,4.5],[.46,1.6],[3,1.6],[6.7,1.55],[7.9,1.65]];
const inspectionDuration=18;
function inspectorPosition(elapsed){
  const progress=Math.min(inspectorRoute.length-1,elapsed/15*(inspectorRoute.length-1));
  const index=Math.floor(progress);
  const from=inspectorRoute[index],to=inspectorRoute[Math.min(index+1,inspectorRoute.length-1)];
  return from.map((coordinate,axis)=>coordinate+(to[axis]-coordinate)*(progress-index));
}
function completeInspection(){
  const dirty=shift.tables.flatMap((seat,index)=>seat.state==='dirty'?[{name:seatName(index),overdue:shift.time-seat.dirtySince>14}]:[]);
  let demerits=dirty.reduce((sum,seat)=>sum+(seat.overdue?2:1),0);
  shift.greasy=shift.grease>=60;
  if(shift.greasy)demerits+=1;
  if(shift.bigFire)demerits+=1;
  const grades=['A','B','C'];
  let step=demerits===0?0:demerits<=2?1:2;
  step=Math.max(0,Math.min(2,step-shift.bribe));
  shift.grade=grades[step];
  shift.inspectionFindings=dirty;
  shift.inspector=null;
  say('Health inspection complete. Grade '+shift.grade+'.');
  refresh();
  showInspectionReport();
}
function showInspectionReport(){
  if(!shift.inspectionFindings||$('inspectionReport').open)return;
  const dirty=shift.inspectionFindings;
  $('inspectionGrade').textContent='Final grade '+shift.grade;
  $('inspectionKitchen').textContent=(shift.greasy?'The griddle is “seasoned” well past code. ':'The cook station passed. ')+(shift.bigFire?'Scorch marks were noted above the range. ':'')+(shift.bribe>0?'The inspector enjoyed a beignet. ':shift.bribe<0?'The inspector did not appreciate the beignets. ':'')+(shift.day.costume?'He conducted the inspection '+shift.day.costume+'.':'');
  $('inspectionDining').textContent=dirty.length?dirty.length+' dining or counter seats needed cleaning.':'Dining tables and counter seats passed the cleanup check.';
  const actions=dirty.length?dirty.map(seat=>'Clear and sanitize '+seat.name.toLowerCase()+(seat.overdue?' promptly. Cleanup was overdue.':'.')):['Continue clearing and sanitizing seats between guests.'];
  if(shift.greasy)actions.push('Scrub the griddle. “Seasoning” is not a food-safety term.');
  $('inspectionActions').replaceChildren(...actions.map(action=>{
    const item=document.createElement('li');
    item.textContent=action;
    return item;
  }));
  $('inspectionReport').showModal();
}
$('inspection').onclick=showInspectionReport;
function tick(dt){
  if(shift.mode!=='open'||modalOpen())return;
  shift.time+=dt;
  if(shift.time>=shift.inspectionAt&&!shift.grade&&!shift.inspector){
    shift.inspector={arrived:shift.time};
    say('A health inspector has arrived to check the café.');
    sfx('inspector');
  }
  if(shift.inspector&&shift.time-shift.inspector.arrived>=inspectionDuration){
    completeInspection();
    return;
  }
  shift.visitCooldown=Math.max(0,shift.visitCooldown-dt);
  tickEvents(dt);
  if(modalOpen())return;
  while(shift.next<shift.arrivals.length&&shift.time>=shift.arrivals[shift.next]){
    const guest=party(shift.next+3);
    if(shift.next===shift.criticIndex){guest.critic=true;guest.leadSprite=5;say('Psst: the party that just joined the line is the Bugle’s food critic.');}
    shift.line.push(guest);shift.next++;
  }
  if(shift.line.some(guest=>guest.patience/guest.max<.32))visitQueue();
  const drain=(shift.band>0?.5:1)*(owns('bench')?.8:1);
  for(const guest of shift.line)guest.patience-=dt*drain;
  for(const guest of shift.line)if(guest.patience<=0&&guest.critic)shift.criticResult='walkout';
  const waiting=shift.line.length;
  shift.line=shift.line.filter(guest=>guest.patience>0);
  if(waiting>shift.line.length){
    shift.lost+=waiting-shift.line.length;
    say('A waiting party left. Check the sidewalk queue.');
    if(!shift.tables.some(table=>table.party||table.job))view='street';
  }
  for(const table of shift.tables){
    if(table.state==='seated'||table.state==='eating'){
      table.timer-=dt;
      if(table.timer<=0)table.state=table.state==='seated'?'order':'pay';
    }
    if(['order','queued','ready','pay'].includes(table.state)&&!table.job){
      const moodDrain=(1+(gCareer.rep-50)/250)*(owns('jukebox')?.75:1)*(owns('urn')&&isCounter(shift.tables.indexOf(table))?.7:1);
      table.party.mood=Math.max(0,table.party.mood-dt*(table.state==='queued'?.009:.022)*moodDrain);
    }
  }
  for(const worker of staff){
    drainEnergy(worker,dt);
    const job=worker.job;
    if(!job)continue;
    if(job.kind==='cook'&&shift.fire)continue;
    const rate=(job.kind==='cook'&&worker===staff[1]&&!staff[0].job?1.65:1)*jobRate(worker,job);
    job.remaining-=dt*rate;
    if(job.remaining<=0){
      finish(worker,job);
      if(modalOpen())return;
    }
  }
  processPending();
  if(modalOpen())return;
  const startCooking=(cook)=>{
    const table=shift.tables.filter(t=>t.state==='queued').sort((a,b)=>a.ticket-b.ticket)[0];
    if(!table)return;
    const duration=Math.max(...table.party.items.map(index=>menu[index].cook))+(table.mixup?3:0);
    if(table.mixup)say('Bart: “Did they say grits, or GRITS?” The tuba ate that ticket. +3 seconds.');
    table.state='cooking';
    table.job=cook.job={kind:'cook',index:shift.tables.indexOf(table),remaining:duration,duration};
  };
  if(!staff[1].job)startCooking(staff[1]);
  // With the second griddle, Sally takes backed-up tickets when nobody is waiting on the register.
  if(owns('griddle2')&&!staff[0].job&&shift.tables.filter(t=>t.state==='queued').length>=2&&!shift.tables.some(t=>t.state==='pay'))startCooking(staff[0]);
  if(shift.time>=shift.closing&&!shift.line.length&&shift.tables.every(table=>table.state==='empty')&&!staff[0].job&&!shift.inspector)endShift();
}
function endShift(){
  shift.mode='complete';view='street';
  shift.events=[];shift.eventsVersion++;
  const day=shift.day;
  const outcome=closeCareerDay(shift);
  $('reportDay').textContent='Day '+day.day+' · '+day.weekday+' · '+day.title;
  const plural=n=>n===1?'1 party':n+' parties';
  $('result').textContent='You served '+plural(shift.served)+' and earned $'+shift.cash+' including $'+shift.tips+' in tips. '+(shift.lost?plural(shift.lost)+' left the queue.':'Nobody left the queue.')+(shift.grade?' Health inspection grade '+shift.grade+'.':'');
  $('reportHeadline').textContent=outcome.review.headline;
  $('reportStars').textContent='The Bluebird Bugle · '+'★'.repeat(outcome.review.stars)+'☆'.repeat(5-outcome.review.stars);
  $('reportGoal').textContent=(outcome.goal?'Goal met: '+day.goalText+'.'+(gCareer.streak>1?' Streak '+gCareer.streak+'!':''):'Goal missed: '+day.goalText+'. The streak resets.');
  $('reportBooks').textContent='Food cost −$'+outcome.foodCost+' · Rent & wages −$'+outcome.overhead+(outcome.bonus?' · Goal bonus +$'+outcome.bonus:'')+' · Net '+(outcome.earned<0?'−$'+(-outcome.earned):'+$'+outcome.earned);
  $('record').textContent='Reputation '+(outcome.repChange>=0?'+':'')+outcome.repChange+' ('+reputationStars(gCareer.rep)+') · Bank $'+gCareer.bank.toLocaleString()+' · Best shift $'+gCareer.best;
  say('Breakfast service is complete.');
  $('report').showModal();
}
function toggle(){
  if(shift.mode==='idle'){reset(true);return;}
  if(shift.mode==='complete'){showPaper();return;}
  shift.mode=shift.mode==='open'?'paused':'open';
  say(shift.mode==='paused'?'Service paused.':'Breakfast service is underway.');
  refresh();
}
const pins=[];
const rows=[];
const staffStatus=[];
const staffEnergy=[];
for(let i=0;i<tablePositions.length;i++){
  const pin=document.createElement('button');
  pin.className='pin';
  pin.onclick=()=>tableAction(i);
  $('pins').append(pin);pins.push(pin);
  const row=document.createElement('button');
  row.className='tablerow';
  row.innerHTML='<b>'+seatCode(i)+'</b><strong></strong><small></small>';
  row.onclick=()=>tableAction(i);
  $('tables').append(row);rows.push(row);
}
const door=document.createElement('button');
door.className='pin ready';
door.onclick=()=>{
  if(shift.mode==='idle'){toggle();return;}
  const i=shift.tables.findIndex(table=>table.state==='empty');
  if(i>=0&&shift.line.length&&shift.mode==='open')tableAction(i);
  else changeView('room');
};
$('pins').append(door);
for(const worker of staff){
  const row=document.createElement('div');
  row.className='staffrow';row.setAttribute('role','listitem');$('staff').setAttribute('role','list');
  row.innerHTML='<span><i class="dot" style="--color:'+worker.color+'"></i><strong>'+worker.name+'</strong></span><small></small><i class="energy" aria-hidden="true"><i></i></i>';
  row.title=gTraits[worker.name].trait+': '+gTraits[worker.name].note;
  $('staff').append(row);staffStatus.push(row.children[1]);staffEnergy.push(row.children[2].firstChild);
}
const queueContainer=$('queue');
// Only touch the DOM when something changed, so a click that starts on a button's text
// is not lost when the text node is replaced mid-click.
function setText(pEl,pText){if(pEl.textContent!==pText)pEl.textContent=pText;}
function setDom(pEl,pName,pValue){if(pEl.getAttribute(pName)!==pValue)pEl.setAttribute(pName,pValue);}
function refresh(){
  const minutes=Math.min(180,Math.floor(shift.time/shift.closing*180));
  setText($('clock'),shift.mode==='complete'?'Closed':(7+Math.floor(minutes/60))+':'+String(minutes%60).padStart(2,'0')+' AM');
  setText($('cash'),'$'+shift.cash);setText($('served'),shift.served);setText($('lost'),shift.lost);
  setText($('start'),{idle:'Open the café',open:'Pause',paused:'Resume',complete:'Next day'}[shift.mode]);
  setText($('caption'),shift.mode==='idle'?'Before opening':shift.mode==='paused'?'Paused':shift.mode==='complete'?'Shift complete':minutes===180?'Last orders':view==='street'?'Sidewalk queue':'Breakfast service');
  $('street').setAttribute('aria-pressed',view==='street');
  $('room').setAttribute('aria-pressed',view==='room');
  setText($('queueCount'),shift.line.length+' waiting');
  const summary=shift.line.map(guest=>[guest.size,Math.max(0,Math.ceil(100*guest.patience/guest.max)),guest]);
  queueContainer.replaceChildren(...summary.map(([size,percent,guest])=>{
    const chip=document.createElement('span');
    chip.className='chip'+(percent<30?' low':'')+(guest.critic?' critic':'');
    chip.textContent=(guest.critic?'★ ':guest.regular?'☕ ':'')+size+' · '+percent+'%';
    chip.title=(guest.critic?'Food critic · ':guest.regular?'Mr. Boudreaux · ':'')+'Party of '+size+' · '+percent+'% patience';
    return chip;
  }));
  if(!summary.length)queueContainer.textContent='No parties waiting';
  door.hidden=view!=='street'||shift.mode==='complete';
  setText(door,shift.mode==='idle'?'Open the café':shift.line.length&&shift.tables.some(t=>t.state==='empty')&&shift.mode==='open'?'Seat next party':'Go inside');
  shift.tables.forEach((table,i)=>{
    const action=canAct(table);
    const ready=canStart(table);
    const state=table.job&&table.job.kind!=='cook'?{order:'Taking order',ready:'Serving',pay:'At register',dirty:'Clearing',chat:'Sally visiting'}[table.job.kind]:stateLabels[table.state];
    let title=table.state==='empty'?(isCounter(i)?'Seat single':!shift.line.length?'Available':state):state;
    if(table.state==='eating'&&action)title='Eating · Visit';
    if(table.pending)title='⏳ '+state+' · #'+(shift.pending.indexOf(i)+1);
    else if(action&&!ready&&table.state!=='order')title=state+' · will queue';
    if(table.party?.critic&&table.state!=='empty')title='★ '+title;
    let detail=table.party?(table.state==='seated'||table.state==='order'?table.party.size+' guests':table.party.items.length+' entrées'):'';
    if(table.state==='queued'){const queue=shift.tables.filter(t=>t.state==='queued').sort((a,b)=>a.ticket-b.ticket);detail='kitchen #'+(queue.indexOf(table)+1);}
    const reason=action?(ready||table.state==='order'?'':blockReason(i)||''):blockReason(i);
    const tip=seatName(i)+' · '+title+(detail?' · '+detail:'')+(reason?'. '+reason:'');
    setDom(rows[i],'aria-disabled',String(!action));
    setText(rows[i].children[1],title);
    setText(rows[i].children[2],detail);
    setDom(rows[i],'aria-label',tip);setDom(rows[i],'title',tip);
    pins[i].hidden=view!=='room';
    setDom(pins[i],'aria-disabled',String(!action));
    setText(pins[i],seatCode(i)+' · '+title);
    setDom(pins[i],'title',tip);
    const cls='pin'+(action&&table.state==='ready'?' ready':'')+(action&&table.party?.mood<.35?' urgent':'')+(table.pending||action&&!ready&&table.state!=='order'?' waiting':'')+(pins[i].classList.contains('nudge')?' nudge':'');
    if(pins[i].className!==cls)pins[i].className=cls;
    const rowCls='tablerow'+(table.pending?' waiting':'')+(rows[i].classList.contains('nudge')?' nudge':'');
    if(rows[i].className!==rowCls)rows[i].className=rowCls;
  });
  for(const [i,worker] of staff.entries()){
    const work=worker.job;
    setText(staffStatus[i],work?work.kind==='visit'?'Visiting the queue':work.index===undefined?jobLabels[work.kind]:jobLabels[work.kind]+' · '+(isCounter(work.index)?seatCode(work.index):'T'+seatCode(work.index)):i===0&&staff[1].job?'Cooking with Bart':gTraits[worker.name].trait+' · '+worker.role);
    staffEnergy[i].style.width=Math.round(worker.energy)+'%';
    staffEnergy[i].parentNode.title='Energy '+Math.round(worker.energy)+'%';
    staffEnergy[i].className=worker.energy<30?'low':'';
    staffEnergy[i].parentNode.parentNode.setAttribute('aria-label',worker.name+', '+gTraits[worker.name].trait.toLowerCase()+' '+worker.role.toLowerCase()+'. '+staffStatus[i].textContent+'. Energy '+Math.round(worker.energy)+' percent.');
  }
  $('inspection').disabled=!shift.inspectionFindings;
  setText($('inspection'),shift.inspector?'Inspection underway':shift.grade?'Health grade · '+shift.grade:'Health grade · —');
  $('boost').disabled=shift.mode!=='open'||shift.visitCooldown>0||!!staff[0].job||!shift.line.length;
  setText($('boost'),shift.visitCooldown>0?'Queue visit · '+Math.ceil(shift.visitCooldown)+'s':'Sally · Visit the queue');
  const coffeeCost=owns('urn')?0:shift.line.length*2;
  $('coffee').disabled=shift.mode!=='open'||shift.coffeeCooldown>0||!shift.line.length;
  setText($('coffee'),shift.coffeeCooldown>0?'Coffee · '+Math.ceil(shift.coffeeCooldown)+'s':'Free coffee · '+(coffeeCost?'$'+coffeeCost:'urn'));
  $('meal').disabled=shift.mode!=='open'||shift.mealCooldown>0;
  setText($('meal'),shift.mealCooldown>0?'Staff meal · '+Math.ceil(shift.mealCooldown)+'s':'Staff meal · $8');
  $('greaseBar').style.width=Math.min(100,shift.grease)+'%';
  $('greaseBar').className=shift.grease>=80?'low':'';
  $('greaseMeter').title='Griddle grease '+Math.round(shift.grease)+'% · a fire starts at 100%';
  renderEvents();
  renderCareerStrip();
}
function carryFor(job){
  if(job?.kind==='ready')return 'food';
  if(job?.kind==='order')return 'setting';
  if(job?.kind==='dirty')return 'clear';
  return null;
}
function workerPath(worker){
  const job=worker.job;
  if(job&&job.kind==='cook'&&worker===staff[0])return [[6.82,1.45]];
  if(job&&job.kind==='break')return [[worker.home[0],5.12],[9.95,5.12],[10.2,3.4]];
  if(!job||job.kind==='cook'||job.kind==='visit'||job.kind==='scrub')return [worker.home];
  if(job.kind==='chat'&&!isCounter(job.index)){
    const [x,y]=tablePositions[job.index];
    return [[9.85,1.6],[9.85,5.12],[Math.min(9.7,x+1.32),5.12],[x+.67,y+.48]];
  }
  if(isCounter(job.index)&&job.kind!=='pay')return [[tablePositions[job.index][0],1.65]];
  if(job.kind==='pay')return [[8.85,1.6],[9.45,1.64]];
  const [x,y]=tablePositions[job.index];
  const tableStop=[x+.67,y+.48];
  const roomAisle=Math.min(9.7,x+1.32);
  const entryAisle=[roomAisle,5.12];
  return job.kind==='ready'?[[worker.home[0],3.11],[roomAisle,3.11],entryAisle,tableStop]:[entryAisle,tableStop];
}

