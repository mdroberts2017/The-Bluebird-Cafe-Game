# The Bluebird Cafe

A retro isometric diner sim set on Prytania Street, New Orleans. You play Sally, the owner-chef of a breakfast café with a line down the block. Your job is to seat parties, take orders, keep Bart's griddle from catching fire, keep Rita and Jane on their feet, charm the regulars and survive the health inspector. Then do it all again tomorrow.

**Version:** v1.0.0
**Author:** Michael Roberts · Krell Studios · [mygiantbrain.com](https://mygiantbrain.com) · [krellstudios.com](https://krellstudios.com)
**License:** GNU General Public License v3.0 or later (see `LICENSE`)

## Playing

Open `The_Bluebird_Cafe_v1.0.0.html` in a current desktop browser such as Chrome, Edge, Firefox or Safari. The game is a single file. It needs no install and no internet connection. It is designed for desktop screens 900 pixels wide or more. Tablets and phones are not supported.

Each shift is one day of a career. *The Bluebird Bugle* opens each morning with a review of yesterday's shift, today's conditions and a daily goal. The day types are:

- Red Beans Monday
- Jazz Fest Saturday
- Saints game day on Sunday
- Mardi Gras every tenth day
- hurricane warnings
- visits from a food critic

If a crew member you need is busy, a request is queued (⏳ and a dashed outline) and starts as soon as someone is free. Hover over any button to see what it is waiting for.

Good reviews raise your reputation, which brings bigger crowds and better tips. Spend your bank in the supply shop between shifts.

### Controls

| Key | Action |
|---|---|
| 1–7 | Act on table 1–5 or counter seat C1–C2 |
| Shift+1 / 2 / 3 | Pick an option on the top event card |
| C | Free coffee for the line |
| M | Staff meal |
| V | Switch between street and dining room |
| P | Pause or resume |
| Q / E | Rotate the camera |
| Arrow keys / mouse drag | Pan |
| + / − / mouse wheel | Zoom |
| Home | Reset the camera |

### Settings

The **Settings** window controls:

- ambient music and sound effects, each with a volume slider
- graphics quality: Low, Medium or High
- reduce motion

It also lets you export, import or reset your career. Settings and career progress are stored only in this browser (`localStorage`). Use **Export career** to keep a copy or move it to another browser.

## Building from source

The `source/` folder has everything needed to rebuild the HTML file. Building requires Node.js 18 or later and Python 3.8 or later.

```
cd source
npm install          # three.js 0.160.0 and esbuild 0.24.2
npm run build        # bundles the trimmed three.js, then runs build.py
```

The result is written to `source/build/The_Bluebird_Cafe_v1.0.0.html`.

| Path | Contents |
|---|---|
| `src/template.html` | Page markup and CSS |
| `src/logic.js` | Core service rules: tables, staff jobs, inspection, the bill |
| `src/career.js` | Days, day types, reviews, reputation, upgrades, saving |
| `src/events.js` | Event cards, line tools, crew traits and energy, table visits |
| `src/settings.js` | Settings window, export and import |
| `src/audio.js` | Generated jazz and sound effects (Web Audio) |
| `src/characters.js` | The characters, rendered into sprite sheets at load |
| `src/world3d.js` | The 3D café, street, camera, cutaway walls and scene optimization |
| `src/main.js` | Frame loop, kitchen animation and keyboard input |
| `three-entry.js` | The list of three.js parts the game uses (for the trimmed build) |
| `assets/` | Mural, wordmark, restroom sign and the stylized wall portrait (WebP) |

## Credits

- Game design, code direction and art direction: Michael Roberts
- three.js r160: MIT License, © 2010–2023 three.js authors
- Mural, wordmark and restroom sign artwork carried over from The Bluebird Cafe v0.6.1
- Wall portrait: Daughter (stylized illustration made from a family photo)
- The poster art, characters, buildings and music (an original tune) are generated in code by the game

The Bluebird Cafe was a real breakfast spot on Prytania Street from 1987 to 2009. This game is an affectionate tribute and is not affiliated with its former owners.
